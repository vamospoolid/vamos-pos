"use strict";
/**
 * Timezone utilities to handle differences between VPS (typically UTC)
 * and cashier computers (local Indonesian timezone: WIB UTC+7, WITA UTC+8, or WIT UTC+9).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTimezoneOffsetHours = exports.getTimezoneOffsetMs = exports.refreshTimezoneCache = exports.initializeTimezoneFromVenue = void 0;
const db_1 = require("../database/db");
const logger_1 = require("./logger");
// In-memory cache so every call does NOT hit the DB
let _cachedOffsetMs = null;
// ─── DB initialiser (call once at startup, VPS only) ─────────────────────────
/**
 * Reads `timezoneOffset` from the first active Venue record and caches it.
 * Safe to call multiple times — re-reads on each call to pick up venue edits.
 */
const initializeTimezoneFromVenue = async () => {
    if (process.env.IS_LOCAL_ELECTRON === 'true')
        return; // local mode: always uses system clock
    try {
        const venue = await db_1.prisma.venue.findFirst({ where: { deletedAt: null } });
        if (venue != null && typeof venue.timezoneOffset === 'number') {
            _cachedOffsetMs = venue.timezoneOffset * 60 * 60 * 1000;
            logger_1.logger.info(`🕐 [Timezone] Venue timezone loaded: UTC+${venue.timezoneOffset} (${_cachedOffsetMs / 3600000}h)`);
        }
    }
    catch (err) {
        logger_1.logger.warn(`⚠️ [Timezone] Could not read venue timezone from DB, using env fallback. ${err.message}`);
    }
};
exports.initializeTimezoneFromVenue = initializeTimezoneFromVenue;
/**
 * Call this after the admin saves Venue settings so the cache is immediately updated.
 */
const refreshTimezoneCache = async () => {
    _cachedOffsetMs = null; // Clear cache
    await (0, exports.initializeTimezoneFromVenue)(); // Re-read from DB
};
exports.refreshTimezoneCache = refreshTimezoneCache;
// ─── Accessors ────────────────────────────────────────────────────────────────
/**
 * Returns the timezone offset in milliseconds.
 *
 * - Local Electron (cashier PC): uses the PC's actual OS timezone offset (live, no caching)
 * - VPS / cloud:                 uses the cached value from Venue.timezoneOffset in the DB
 *   Fallback: VENUE_TIMEZONE env var → 8 (WITA) if nothing else is available
 */
const getTimezoneOffsetMs = () => {
    if (process.env.IS_LOCAL_ELECTRON === 'true') {
        return -new Date().getTimezoneOffset() * 60 * 1000;
    }
    if (_cachedOffsetMs !== null)
        return _cachedOffsetMs;
    const tz = parseFloat(process.env.VENUE_TIMEZONE || '8');
    return (isNaN(tz) ? 8 : tz) * 60 * 60 * 1000;
};
exports.getTimezoneOffsetMs = getTimezoneOffsetMs;
/**
 * Returns the timezone offset in hours.
 */
const getTimezoneOffsetHours = () => {
    return (0, exports.getTimezoneOffsetMs)() / (60 * 60 * 1000);
};
exports.getTimezoneOffsetHours = getTimezoneOffsetHours;
