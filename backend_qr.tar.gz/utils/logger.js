"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hardwareLogger = exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
// ── Pastikan folder logs/ ada sebelum winston menulis ────────────────────────
const logsDir = path_1.default.join(process.cwd(), 'logs');
if (!fs_1.default.existsSync(logsDir)) {
    fs_1.default.mkdirSync(logsDir, { recursive: true });
}
// ── Format untuk file: timestamp lengkap + JSON ──────────────────────────────
const fileFormat = winston_1.default.format.combine(winston_1.default.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston_1.default.format.errors({ stack: true }), // sertakan stack trace jika ada Error
winston_1.default.format.json());
// ── Format untuk console: ringkas dan berwarna ───────────────────────────────
const consoleFormat = winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.timestamp({ format: 'HH:mm:ss' }), winston_1.default.format.printf(({ timestamp, level, message }) => {
    return `[${timestamp}] ${level}: ${message}`;
}));
exports.logger = winston_1.default.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    transports: [
        // ── Console (selalu aktif) ───────────────────────────────────────────
        new winston_1.default.transports.Console({
            format: consoleFormat,
        }),
        // ── File: error saja → logs/error.log ───────────────────────────────
        // Rotasi otomatis: max 10MB per file, simpan 14 file terakhir (~140MB max)
        new winston_1.default.transports.File({
            filename: path_1.default.join(logsDir, 'error.log'),
            level: 'error',
            format: fileFormat,
            maxsize: 10 * 1024 * 1024, // 10 MB
            maxFiles: 14,
            tailable: true,
        }),
        // ── File: semua level → logs/combined.log ───────────────────────────
        // Rotasi otomatis: max 20MB per file, simpan 7 file terakhir (~140MB max)
        new winston_1.default.transports.File({
            filename: path_1.default.join(logsDir, 'combined.log'),
            format: fileFormat,
            maxsize: 20 * 1024 * 1024, // 20 MB
            maxFiles: 7,
            tailable: true,
        }),
    ],
    // Jangan crash jika logger sendiri error (misal disk penuh)
    exitOnError: false,
});
// ── Helper: log event hardware dengan format khusus ──────────────────────────
exports.hardwareLogger = {
    relay: (msg) => exports.logger.info(`[RELAY] ${msg}`),
    relayError: (msg) => exports.logger.error(`[RELAY] ${msg}`),
    wa: (msg) => exports.logger.info(`[WA] ${msg}`),
    waError: (msg) => exports.logger.error(`[WA] ${msg}`),
};
