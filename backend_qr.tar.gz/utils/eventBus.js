"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventBus = void 0;
const events_1 = require("events");
/**
 * Global Event Bus untuk komunikasi antar modul tanpa dependency sirkular.
 */
class EventBus extends events_1.EventEmitter {
}
exports.eventBus = new EventBus();
