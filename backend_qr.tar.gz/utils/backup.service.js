"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupService = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const logger_1 = require("./logger");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
// ── Folder penyimpanan backup ─────────────────────────────────────────────────
const BACKUP_DIR = path_1.default.join(process.cwd(), 'backups');
const KEEP_MONTHS = 6; // simpan backup 6 bulan terakhir
// Pastikan folder backups/ ada
if (!fs_1.default.existsSync(BACKUP_DIR)) {
    fs_1.default.mkdirSync(BACKUP_DIR, { recursive: true });
}
function parseDbUrl(url) {
    try {
        // Format: postgresql://user:password@host:port/database?schema=public
        const match = url.match(/postgresql?:\/\/([^:]+):([^@]*)@([^:]+):(\d+)\/([^?]+)/);
        if (!match)
            return null;
        return {
            user: match[1],
            password: match[2],
            host: match[3],
            port: match[4],
            database: match[5],
        };
    }
    catch {
        return null;
    }
}
// ─────────────────────────────────────────────────────────────────────────────
class BackupService {
    /**
     * Jalankan pg_dump dan simpan ke file .sql di folder backups/.
     * Nama file: backup-YYYY-MM-DD_HH-mm.sql
     *
     * Return: path file backup yang dibuat, atau null jika gagal.
     */
    static async runBackup() {
        const dbUrl = process.env.DATABASE_URL;
        if (!dbUrl) {
            const msg = 'DATABASE_URL tidak ditemukan di environment variables.';
            logger_1.logger.error(`❌ Backup gagal: ${msg}`);
            return { success: false, file: null, message: msg };
        }
        const creds = parseDbUrl(dbUrl);
        if (!creds) {
            const msg = 'Format DATABASE_URL tidak valid, tidak bisa parse credentials.';
            logger_1.logger.error(`❌ Backup gagal: ${msg}`);
            return { success: false, file: null, message: msg };
        }
        // Format nama file dengan tanggal + jam agar tidak overwrite
        const now = new Date();
        const dateStr = now.toISOString().slice(0, 16).replace('T', '_').replace(':', '-');
        const fileName = `backup-${dateStr}.sql`;
        const filePath = path_1.default.join(BACKUP_DIR, fileName);
        // pg_dump command — PGPASSWORD di-set via env agar tidak perlu file .pgpass
        const pgDumpCmd = [
            `set PGPASSWORD=${creds.password}`, // Windows: set env dulu
            `&&`,
            `pg_dump`,
            `-h ${creds.host}`,
            `-p ${creds.port}`,
            `-U ${creds.user}`,
            `-d ${creds.database}`,
            `--no-password`,
            `--format=plain`,
            `--encoding=UTF8`,
            `-f "${filePath}"`,
        ].join(' ');
        logger_1.logger.info(`💾 Memulai backup database → ${fileName} ...`);
        try {
            await execAsync(pgDumpCmd, {
                timeout: 5 * 60 * 1000, // timeout 5 menit
                shell: 'cmd.exe', // Windows shell
            });
            const stat = fs_1.default.statSync(filePath);
            const sizeMB = (stat.size / (1024 * 1024)).toFixed(2);
            logger_1.logger.info(`✅ Backup selesai: ${fileName} (${sizeMB} MB)`);
            // Cleanup backup lama
            await BackupService.cleanupOldBackups();
            return {
                success: true,
                file: fileName,
                message: `Backup berhasil: ${fileName} (${sizeMB} MB)`,
            };
        }
        catch (err) {
            const errMsg = err.stderr || err.message || 'Unknown error';
            logger_1.logger.error(`❌ Backup gagal: ${errMsg}`);
            // Hapus file kosong/rusak jika ada
            if (fs_1.default.existsSync(filePath)) {
                try {
                    fs_1.default.unlinkSync(filePath);
                }
                catch (_) { }
            }
            return {
                success: false,
                file: null,
                message: `Backup gagal: ${errMsg}`,
            };
        }
    }
    /**
     * Hapus file backup yang lebih tua dari KEEP_MONTHS bulan.
     * Hanya hapus file dengan pola backup-*.sql
     */
    static async cleanupOldBackups() {
        try {
            const files = fs_1.default.readdirSync(BACKUP_DIR)
                .filter(f => f.startsWith('backup-') && f.endsWith('.sql'));
            const cutoff = new Date();
            cutoff.setMonth(cutoff.getMonth() - KEEP_MONTHS);
            let deleted = 0;
            for (const file of files) {
                const filePath = path_1.default.join(BACKUP_DIR, file);
                const stat = fs_1.default.statSync(filePath);
                if (stat.mtime < cutoff) {
                    fs_1.default.unlinkSync(filePath);
                    deleted++;
                    logger_1.logger.info(`🗑️ Backup lama dihapus: ${file}`);
                }
            }
            return deleted;
        }
        catch (err) {
            logger_1.logger.warn(`⚠️ Cleanup backup gagal: ${err.message}`);
            return 0;
        }
    }
    /**
     * Daftar semua file backup yang ada, diurutkan dari terbaru.
     */
    static listBackups() {
        try {
            const files = fs_1.default.readdirSync(BACKUP_DIR)
                .filter(f => f.startsWith('backup-') && f.endsWith('.sql'));
            return files
                .map(name => {
                const stat = fs_1.default.statSync(path_1.default.join(BACKUP_DIR, name));
                return {
                    name,
                    sizeMB: (stat.size / (1024 * 1024)).toFixed(2),
                    createdAt: stat.mtime,
                };
            })
                .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        }
        catch {
            return [];
        }
    }
    /**
     * Restore database dari file .sql yang ada di folder backups/.
     * Ini akan MENGHAPUS SEMUA DATA saat ini dan menggantinya dengan isi dari backup.
     */
    static async restoreBackup(fileName) {
        const dbUrl = process.env.DATABASE_URL;
        if (!dbUrl) {
            return { success: false, message: 'DATABASE_URL tidak ditemukan.' };
        }
        const creds = parseDbUrl(dbUrl);
        if (!creds) {
            return { success: false, message: 'Format DATABASE_URL tidak valid.' };
        }
        const filePath = path_1.default.join(BACKUP_DIR, fileName);
        if (!fs_1.default.existsSync(filePath)) {
            return { success: false, message: `File backup ${fileName} tidak ditemukan.` };
        }
        logger_1.logger.info(`🔄 Memulai restore database dari → ${fileName} ...`);
        try {
            // 1. Drop schema public & re-create (Hati-hati: ini akan menghapus semua tabel)
            const dropCmd = [
                `set PGPASSWORD=${creds.password}`,
                `&&`,
                `psql`,
                `-h ${creds.host}`,
                `-p ${creds.port}`,
                `-U ${creds.user}`,
                `-d ${creds.database}`,
                `-c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"`
            ].join(' ');
            await execAsync(dropCmd, { shell: 'cmd.exe' });
            logger_1.logger.info(`🧹 Schema public berhasil di-reset.`);
            // 2. Restore data dari file SQL
            const psqlCmd = [
                `set PGPASSWORD=${creds.password}`,
                `&&`,
                `psql`,
                `-h ${creds.host}`,
                `-p ${creds.port}`,
                `-U ${creds.user}`,
                `-d ${creds.database}`,
                `-f "${filePath}"`
            ].join(' ');
            await execAsync(psqlCmd, {
                timeout: 10 * 60 * 1000, // 10 menit
                shell: 'cmd.exe',
            });
            logger_1.logger.info(`✅ Restore database selesai: ${fileName}`);
            return {
                success: true,
                message: `Restore berhasil dari file ${fileName}. Sistem telah kembali ke state backup.`,
            };
        }
        catch (err) {
            const errMsg = err.stderr || err.message || 'Unknown error';
            logger_1.logger.error(`❌ Restore gagal: ${errMsg}`);
            return {
                success: false,
                message: `Restore gagal: ${errMsg}`,
            };
        }
    }
}
exports.BackupService = BackupService;
