"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = __importDefault(require("path"));
const child_process_1 = require("child_process");
let mainWindow = null;
let serverProcess = null;
let tray = null;
function startServer() {
    // Jalankan backend (Bridge) sebagai child process
    const serverPath = path_1.default.join(__dirname, 'server.js');
    serverProcess = (0, child_process_1.fork)(serverPath);
    serverProcess.on('error', (err) => {
        console.error('Failed to start server process:', err);
    });
}
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1280,
        height: 800,
        title: "Vamos POS - Billiard Management",
        icon: path_1.default.join(__dirname, '../public/logo.png'), // Pastikan ada logo
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
        },
        backgroundColor: '#0a0a0a'
    });
    // Buka website POS langsung
    mainWindow.loadURL('https://pos.vamospool.id');
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
    // Hilangkan menu default
    electron_1.Menu.setApplicationMenu(null);
}
// Tray icon agar aplikasi bisa jalan di background
function createTray() {
    tray = new electron_1.Tray(path_1.default.join(__dirname, '../public/logo.png'));
    const contextMenu = electron_1.Menu.buildFromTemplate([
        { label: 'Show App', click: () => { mainWindow?.show(); } },
        { label: 'Restart Bridge', click: () => {
                serverProcess?.kill();
                startServer();
            } },
        { type: 'separator' },
        { label: 'Exit', click: () => {
                electron_1.app.isQuitting = true;
                electron_1.app.quit();
            } }
    ]);
    tray.setToolTip('Vamos POS Bridge');
    tray.setContextMenu(contextMenu);
}
electron_1.app.on('ready', () => {
    startServer();
    createWindow();
    // createTray();
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        serverProcess?.kill();
        electron_1.app.quit();
    }
});
electron_1.app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});
// Pastikan proses backend mati saat aplikasi ditutup
electron_1.app.on('before-quit', () => {
    serverProcess?.kill();
});
