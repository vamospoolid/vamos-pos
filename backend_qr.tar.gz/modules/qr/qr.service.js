"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QRService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const socket_1 = require("../../socket");
const product_service_1 = require("../products/product.service");
class QRService {
    static async findTableFlexible(tableId) {
        let table = await db_1.prisma.table.findUnique({ where: { id: tableId } });
        if (!table) {
            const isShortNumber = /^\d{1,3}$/.test(tableId.trim());
            const channelNum = isShortNumber ? parseInt(tableId.trim(), 10) : null;
            table = await db_1.prisma.table.findFirst({
                where: {
                    deletedAt: null,
                    OR: [
                        { id: { startsWith: tableId.slice(0, 8) } },
                        { name: { contains: tableId, mode: 'insensitive' } },
                        ...(channelNum !== null ? [{ relayChannel: channelNum }] : [])
                    ]
                }
            });
        }
        if (!table) {
            table = await db_1.prisma.table.findFirst({
                where: { deletedAt: null },
                orderBy: { relayChannel: 'asc' }
            });
        }
        return table;
    }
    static async getMenuForTable(tableId) {
        const table = await this.findTableFlexible(tableId);
        if (!table)
            throw new errors_1.AppError('Table not found', 404);
        const venue = await db_1.prisma.venue.findFirst();
        const isRecipeSystemEnabled = venue?.isRecipeSystemEnabled || false;
        const allProducts = await db_1.prisma.product.findMany({
            where: { deletedAt: null },
            include: { recipes: true },
            orderBy: { name: 'asc' }
        });
        const availableProducts = allProducts.filter(p => {
            if (isRecipeSystemEnabled && p.recipes && p.recipes.length > 0)
                return true;
            return p.stock > 0 || allProducts.length <= 10;
        });
        const session = await db_1.prisma.session.findFirst({
            where: { tableId: table.id, status: 'ACTIVE' },
            include: { orders: { include: { product: true } } }
        });
        return { table, products: availableProducts.length > 0 ? availableProducts : allProducts, activeSession: session };
    }
    static async createOrderForTable(tableId, cart) {
        const table = await this.findTableFlexible(tableId);
        if (!table)
            throw new errors_1.AppError('Table not found', 404);
        let session = await db_1.prisma.session.findFirst({
            where: { tableId: table.id, status: 'ACTIVE' },
            include: { table: true }
        });
        if (!session) {
            session = await db_1.prisma.session.create({
                data: {
                    tableId: table.id,
                    status: 'ACTIVE',
                    billingType: 'FNB_ONLY',
                    customerName: `QR ${table.name}`,
                },
                include: { table: true }
            });
        }
        const ordersCreated = [];
        for (const item of cart) {
            const product = await db_1.prisma.product.findUnique({ where: { id: item.productId } });
            if (!product)
                continue;
            await product_service_1.ProductService.validateStock(product.id, item.quantity);
            const checkExisting = await db_1.prisma.order.findFirst({
                where: { sessionId: session.id, productId: item.productId, kdsStatus: 'PENDING' }
            });
            let order;
            if (checkExisting) {
                order = await db_1.prisma.order.update({
                    where: { id: checkExisting.id },
                    data: {
                        quantity: checkExisting.quantity + item.quantity,
                        total: (checkExisting.quantity + item.quantity) * product.price
                    }
                });
            }
            else {
                order = await db_1.prisma.order.create({
                    data: {
                        sessionId: session.id,
                        productId: item.productId,
                        quantity: item.quantity,
                        price: product.price,
                        total: product.price * item.quantity,
                        kdsStatus: 'PENDING'
                    }
                });
            }
            const sessionDesc = session.customerName ? session.customerName : (session.table ? `Meja ${session.table.name}` : `Walk-In (${session.id.substring(0, 6)})`);
            await product_service_1.ProductService.updateStock(product.id, -item.quantity, 'SALE', `QR Order - ${sessionDesc}`);
            ordersCreated.push(order);
        }
        const fnbTotal = await db_1.prisma.order.aggregate({
            where: { sessionId: session.id },
            _sum: { total: true }
        });
        await db_1.prisma.session.update({
            where: { id: session.id },
            data: {
                fnbAmount: fnbTotal._sum.total || 0,
                totalAmount: (fnbTotal._sum.total || 0) + (session.tableAmount || 0)
            }
        });
        (0, socket_1.getIO)().emit('orders:updated');
        (0, socket_1.getIO)().emit('sessions:updated');
        (0, socket_1.getIO)().emit('kds:updated');
        return ordersCreated;
    }
}
exports.QRService = QRService;
