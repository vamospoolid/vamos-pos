"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOrder = exports.getMenu = void 0;
const qr_service_1 = require("./qr.service");
const catchAsync_1 = require("../../utils/catchAsync");
exports.getMenu = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { tableId } = req.params;
    const result = await qr_service_1.QRService.getMenuForTable(tableId);
    res.json({ success: true, data: result });
});
exports.createOrder = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { tableId } = req.params;
    const { cart } = req.body; // Array of { productId, quantity }
    const result = await qr_service_1.QRService.createOrderForTable(tableId, cart);
    res.json({ success: true, data: result });
});
