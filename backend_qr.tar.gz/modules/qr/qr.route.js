"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const qr_controller_1 = require("./qr.controller");
const router = (0, express_1.Router)();
router.get('/menu/:tableId', qr_controller_1.getMenu);
router.post('/order/:tableId', qr_controller_1.createOrder);
exports.default = router;
