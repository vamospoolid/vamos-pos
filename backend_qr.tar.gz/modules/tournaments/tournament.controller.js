"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.purgeParticipants = exports.removeParticipant = exports.reshuffleBracket = exports.resetBracket = exports.deleteTournament = exports.finishTournament = exports.updateMatchPlayers = exports.updateMatchResult = exports.generateBracket = exports.updateParticipant = exports.updateParticipantStatus = exports.registerParticipant = exports.updateTournament = exports.getTournamentById = exports.getTournaments = exports.createTournament = void 0;
const tournament_service_1 = require("./tournament.service");
const catchAsync_1 = require("../../utils/catchAsync");
const socket_1 = require("../../socket");
const errors_1 = require("../../utils/errors");
exports.createTournament = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const tournament = await tournament_service_1.TournamentService.createTournament(req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.status(201).json({ success: true, data: tournament });
});
exports.getTournaments = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const tournaments = await tournament_service_1.TournamentService.getTournaments();
    res.json({ success: true, data: tournaments });
});
exports.getTournamentById = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const tournament = await tournament_service_1.TournamentService.getTournamentById(id);
    if (!tournament)
        throw new errors_1.AppError('Tournament not found', 404);
    res.json({ success: true, data: tournament });
});
exports.updateTournament = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const tournament = await tournament_service_1.TournamentService.updateTournament(id, req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: tournament });
});
exports.registerParticipant = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { memberId, name, handicap, paymentMethod, status, paymentNotes } = req.body;
    const pt = await tournament_service_1.TournamentService.registerParticipant(id, req.user.id, memberId, name, handicap, paymentNotes, status, paymentMethod);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: pt });
});
exports.updateParticipantStatus = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id, participantId } = req.params;
    const { paymentStatus, paymentMethod } = req.body;
    const pt = await tournament_service_1.TournamentService.updateParticipantStatus(id, participantId, paymentStatus, req.user.id, paymentMethod);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: pt });
});
exports.updateParticipant = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id, participantId } = req.params;
    const pt = await tournament_service_1.TournamentService.updateParticipant(id, participantId, req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: pt });
});
exports.generateBracket = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const br = await tournament_service_1.TournamentService.generateBracket(id);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: br });
});
exports.updateMatchResult = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { matchId } = req.params;
    const dt = await tournament_service_1.TournamentService.updateMatchResult(matchId, req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.updateMatchPlayers = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { matchId } = req.params;
    const dt = await tournament_service_1.TournamentService.updateMatchPlayers(matchId, req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.finishTournament = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const dt = await tournament_service_1.TournamentService.finishTournament(id, req.body);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.deleteTournament = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const dt = await tournament_service_1.TournamentService.deleteTournament(id);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.resetBracket = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const dt = await tournament_service_1.TournamentService.resetBracket(id);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.reshuffleBracket = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const dt = await tournament_service_1.TournamentService.reshuffleBracket(id);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.removeParticipant = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id, participantId } = req.params;
    const dt = await tournament_service_1.TournamentService.removeParticipant(id, participantId);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
exports.purgeParticipants = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const dt = await tournament_service_1.TournamentService.purgeParticipants(id);
    (0, socket_1.getIO)().emit('tournaments:updated');
    res.json({ success: true, data: dt });
});
