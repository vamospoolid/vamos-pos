"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const tournament_controller_1 = require("./tournament.controller");
const tournament_creative_controller_1 = require("./tournament.creative.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
const upload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
// Public tournament viewing (Read-Only for spectators and live audience)
router.get('/', tournament_controller_1.getTournaments);
router.get('/:id', tournament_controller_1.getTournamentById);
router.use(auth_1.authenticate);
// AI Creative & Content Automation routes
router.post('/creative/generate', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_creative_controller_1.generateTournamentPromo);
router.post('/creative/analyze-image', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), upload.single('image'), tournament_creative_controller_1.analyzePromoImage);
router.post('/', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.createTournament);
router.put('/:id', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.updateTournament);
router.post('/:id/register', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.registerParticipant);
router.put('/:id/participants/:participantId', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.updateParticipant);
router.put('/:id/participants/:participantId/status', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.updateParticipantStatus);
router.post('/:id/generate-bracket', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.generateBracket);
router.post('/:id/reset-bracket', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.resetBracket);
router.post('/:id/reshuffle-bracket', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.reshuffleBracket);
router.put('/matches/:matchId', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.updateMatchResult);
router.put('/matches/:matchId/players', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.updateMatchPlayers);
router.post('/:id/finish', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.finishTournament);
router.delete('/:id/participants/:participantId', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.removeParticipant);
router.delete('/:id/participants', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.purgeParticipants);
router.delete('/:id', (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER'), tournament_controller_1.deleteTournament);
exports.default = router;
