"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyzePromoImage = exports.generateTournamentPromo = void 0;
const tournament_creative_service_1 = require("./tournament.creative.service");
const catchAsync_1 = require("../../utils/catchAsync");
const errors_1 = require("../../utils/errors");
/**
 * Generate tournament prompt and social media copy
 */
exports.generateTournamentPromo = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { name, prizePool, prizes, entryFee, rules, style, date, venue } = req.body;
    if (!name || prizePool === undefined || entryFee === undefined) {
        throw new errors_1.AppError('Data turnamen tidak lengkap. Nama, Total Hadiah, dan Biaya Masuk wajib diisi.', 400);
    }
    const result = await tournament_creative_service_1.TournamentCreativeService.generatePromoPack({
        name,
        prizePool: Number(prizePool),
        prizes: prizes || 'Sesuai regulasi turnamen',
        entryFee: Number(entryFee),
        rules: rules || 'Single Elimination',
        style: style || 'Cyberpunk Neon',
        date: date || 'Segera Diumumkan',
        venue: venue || 'Vamos Pool & Cafe'
    });
    res.status(200).json({
        status: 'success',
        data: result
    });
});
/**
 * Analyze user uploaded image (coffee, venue) to generate copywriting
 */
exports.analyzePromoImage = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const file = req.file;
    const { briefText } = req.body;
    if (!file) {
        throw new errors_1.AppError('Tidak ada file gambar yang diunggah.', 400);
    }
    if (!briefText) {
        throw new errors_1.AppError('Brief teks promosi wajib diisi.', 400);
    }
    const result = await tournament_creative_service_1.TournamentCreativeService.analyzeImagePromo(file.buffer, file.mimetype, briefText);
    res.status(200).json({
        status: 'success',
        data: result
    });
});
