"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = void 0;
const db_1 = require("../../database/db");
const logger_1 = require("../../utils/logger");
class AuditService {
    static async log(userId, action, resource, details) {
        await db_1.prisma.auditLog.create({
            data: {
                userId,
                action,
                resource,
                details: details ? JSON.stringify(details) : undefined,
            }
        });
    }
    /**
     * Hapus AuditLog yang lebih tua dari `retentionDays` hari.
     * Default: 90 hari. Dipanggil otomatis dari server.ts setiap hari.
     */
    static async cleanupOldLogs(retentionDays = 90) {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - retentionDays);
        const result = await db_1.prisma.auditLog.deleteMany({
            where: {
                createdAt: { lt: cutoff }
            }
        });
        if (result.count > 0) {
            logger_1.logger.info(`🧹 AuditLog cleanup: ${result.count} log dihapus (lebih tua dari ${retentionDays} hari).`);
        }
        return result.count;
    }
}
exports.AuditService = AuditService;
