"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const bcrypt_1 = __importDefault(require("bcrypt"));
class UserService {
    static async createUser(data) {
        const existingUser = await db_1.prisma.user.findUnique({ where: { email: data.email } });
        if (existingUser)
            throw new errors_1.AppError('Email already in use', 400);
        const hashedPassword = await bcrypt_1.default.hash(data.password || '12345678', 10);
        return db_1.prisma.user.create({
            data: {
                name: data.name,
                email: data.email,
                password: hashedPassword,
                role: data.role || 'KASIR'
            },
            select: { id: true, name: true, email: true, role: true, createdAt: true }
        });
    }
    static async getUsers() {
        return db_1.prisma.user.findMany({
            where: { deletedAt: null },
            select: { id: true, name: true, email: true, role: true, createdAt: true },
            orderBy: { createdAt: 'desc' }
        });
    }
    static async getUserById(id) {
        const user = await db_1.prisma.user.findFirst({
            where: { id, deletedAt: null },
            select: { id: true, name: true, email: true, role: true, createdAt: true }
        });
        if (!user)
            throw new errors_1.AppError('User not found', 404);
        return user;
    }
    static async updateUser(id, data) {
        const user = await db_1.prisma.user.findFirst({ where: { id, deletedAt: null } });
        if (!user)
            throw new errors_1.AppError('User not found', 404);
        if (data.email && data.email !== user.email) {
            const existingUser = await db_1.prisma.user.findUnique({ where: { email: data.email } });
            if (existingUser)
                throw new errors_1.AppError('Email already in use', 400);
        }
        const updateData = { ...data };
        if (data.password) {
            updateData.password = await bcrypt_1.default.hash(data.password, 10);
        }
        return db_1.prisma.user.update({
            where: { id },
            data: updateData,
            select: { id: true, name: true, email: true, role: true, updatedAt: true }
        });
    }
    static async deleteUser(id) {
        const user = await db_1.prisma.user.findFirst({ where: { id, deletedAt: null } });
        if (!user)
            throw new errors_1.AppError('User not found', 404);
        // Soft delete the user so relations remain intact but they can't login
        return db_1.prisma.user.update({
            where: { id },
            data: {
                deletedAt: new Date(),
                email: `deleted_${Date.now()}_${user.email}` // Allow email reuse
            }
        });
    }
}
exports.UserService = UserService;
