"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseController = void 0;
const license_service_1 = require("./license.service");
const licenseService = new license_service_1.LicenseService();
class LicenseController {
    getActiveHwid = async () => {
        const isVPS = process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON;
        if (isVPS) {
            const { getLatestBridgeStatus } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            const bridgeStatus = getLatestBridgeStatus();
            return bridgeStatus?.hardwareId;
        }
        return undefined;
    };
    getStatus = async (req, res) => {
        try {
            const hwid = await this.getActiveHwid();
            const status = await licenseService.getStatus(hwid);
            res.json({ success: true, data: status });
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    };
    activate = async (req, res) => {
        try {
            const { licenseKey } = req.body;
            if (!licenseKey) {
                return res.status(400).json({ success: false, message: 'License key is required.' });
            }
            const hwid = await this.getActiveHwid();
            const license = await licenseService.activate(licenseKey, hwid);
            res.json({ success: true, message: 'Activation successful.', data: license });
        }
        catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    };
    requestDemo = async (req, res) => {
        try {
            const hwid = await this.getActiveHwid();
            const license = await licenseService.requestDemo(hwid);
            res.json({ success: true, message: 'Trial activated for 24 hours.', data: license });
        }
        catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    };
}
exports.LicenseController = LicenseController;
