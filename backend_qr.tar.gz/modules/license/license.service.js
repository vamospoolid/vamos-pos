"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseService = void 0;
const hardware_utils_1 = require("../../utils/hardware.utils");
const db_1 = require("../../database/db");
const MASTER_KEY = 'Ahmad_dcc07';
class LicenseService {
    async getStatus(providedHwid) {
        const hwid = providedHwid || (0, hardware_utils_1.getHardwareId)();
        let license = null;
        try {
            license = await db_1.prisma.license.findUnique({
                where: { hardwareId: hwid }
            });
        }
        catch (err) { }
        const isLocalBridge = process.env.IS_LOCAL_ELECTRON === 'true';
        const isActivated = isLocalBridge ? true : !!(license && license.isActivated && license.isActive);
        return {
            machineId: hwid,
            isActivated: isActivated,
            license: license ? {
                licenseKey: license.licenseKey,
                activatedAt: license.activatedAt,
                expiresAt: license.expiresAt,
                isActive: license.isActive
            } : (isLocalBridge ? {
                licenseKey: `OFFLINE-HYBRID-${hwid.substring(0, 8)}`,
                activatedAt: new Date(),
                expiresAt: null,
                isActive: true
            } : null)
        };
    }
    async activate(key, providedHwid) {
        const hwid = providedHwid || (0, hardware_utils_1.getHardwareId)();
        const existingMachineLicense = await db_1.prisma.license.findUnique({
            where: { hardwareId: hwid }
        });
        if (existingMachineLicense && existingMachineLicense.isActivated) {
            throw new Error('This machine is already activated.');
        }
        if (key.trim().toUpperCase() === MASTER_KEY.toUpperCase()) {
            return await db_1.prisma.license.upsert({
                where: { hardwareId: hwid },
                update: {
                    licenseKey: `MASTER-${hwid}`,
                    isActivated: true,
                    activatedAt: new Date(),
                    isActive: true
                },
                create: {
                    licenseKey: `MASTER-${hwid}`,
                    hardwareId: hwid,
                    isActivated: true,
                    activatedAt: new Date(),
                    isActive: true
                }
            });
        }
        const license = await db_1.prisma.license.findUnique({
            where: { licenseKey: key }
        });
        if (!license)
            throw new Error('Invalid license key.');
        if (license.isActivated && license.hardwareId !== hwid) {
            throw new Error('This license key is already bound to another machine.');
        }
        return await db_1.prisma.license.update({
            where: { licenseKey: key },
            data: {
                hardwareId: hwid,
                isActivated: true,
                activatedAt: new Date()
            }
        });
    }
    async requestDemo(providedHwid) {
        const hwid = providedHwid || (0, hardware_utils_1.getHardwareId)();
        const existing = await db_1.prisma.license.findUnique({
            where: { hardwareId: hwid }
        });
        if (existing) {
            throw new Error('Trial has already been requested or used on this machine.');
        }
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);
        return await db_1.prisma.license.create({
            data: {
                licenseKey: `DEMO-${hwid.substring(0, 8)}-${Date.now().toString().slice(-4)}`,
                hardwareId: hwid,
                isActivated: true,
                activatedAt: new Date(),
                expiresAt: expiresAt,
                isActive: true
            }
        });
    }
    async verify(providedHwid) {
        const isLocalBridge = process.env.IS_LOCAL_ELECTRON === 'true';
        if (isLocalBridge)
            return true;
        const hwid = providedHwid || (0, hardware_utils_1.getHardwareId)();
        const license = await db_1.prisma.license.findUnique({
            where: { hardwareId: hwid }
        });
        if (!license || !license.isActivated || !license.isActive)
            return false;
        if (license.expiresAt && new Date() > license.expiresAt)
            return false;
        return true;
    }
}
exports.LicenseService = LicenseService;
