"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bulkDeleteExpenses = exports.deleteExpense = exports.payDebt = exports.createExpense = exports.getPendingDebtsCount = exports.getExpenses = void 0;
const db_1 = require("../../database/db");
const catchAsync_1 = require("../../utils/catchAsync");
const errors_1 = require("../../utils/errors");
const socket_1 = require("../../socket");
const loyalty_service_1 = require("../loyalty/loyalty.service");
exports.getExpenses = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId, status, isDebt } = req.query;
    const where = { deletedAt: null };
    if (memberId)
        where.memberId = memberId;
    if (status)
        where.status = status;
    if (isDebt === 'true')
        where.isDebt = true;
    const expenses = await db_1.prisma.expense.findMany({
        where,
        include: { member: { select: { name: true } } },
        orderBy: { date: 'desc' }
    });
    res.json({ success: true, data: expenses });
});
exports.getPendingDebtsCount = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const count = await db_1.prisma.expense.count({
        where: {
            deletedAt: null,
            isDebt: true,
            status: 'PENDING'
        }
    });
    res.json({ success: true, count });
});
exports.createExpense = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { category, amount, description, date, memberId, isDebt } = req.body;
    const userId = req.user.id;
    // Cari shift kasir yang aktif agar pengeluaran memotong cash di shift tersebut
    const activeShift = await db_1.prisma.cashierShift.findFirst({
        where: { userId, status: 'OPEN' }
    });
    const expense = await db_1.prisma.expense.create({
        data: {
            category,
            amount: Number(amount),
            description,
            date: date ? new Date(date) : new Date(),
            shiftId: activeShift ? activeShift.id : null,
            memberId: memberId || null,
            isDebt: isDebt || category === 'DEBT',
            status: (isDebt || category === 'DEBT') ? 'PENDING' : 'PAID'
        }
    });
    (0, socket_1.getIO)().emit('sessions:updated');
    (0, socket_1.getIO)().emit('expenses:updated');
    res.status(201).json({ success: true, data: expense });
});
exports.payDebt = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { method, discount } = req.body;
    const userId = req.user.id;
    const numDiscount = Number(discount) || 0;
    const expense = await db_1.prisma.expense.findUnique({
        where: { id }
    });
    if (!expense || !expense.isDebt || expense.status !== 'PENDING') {
        throw new errors_1.AppError('Data piutang tidak valid!', 400);
    }
    const finalPaymentAmount = Math.max(0, expense.amount - numDiscount);
    const result = await db_1.prisma.$transaction(async (tx) => {
        // Cari shift kasir yang aktif
        const activeShift = await tx.cashierShift.findFirst({
            where: { userId, status: 'OPEN' }
        });
        // Buat record pembayaran agar masuk ke saldo/shift
        await tx.payment.create({
            data: {
                sessionId: expense.sessionId,
                amount: finalPaymentAmount,
                method: method || 'CASH',
                status: 'SUCCESS',
                cashierId: userId,
                shiftId: activeShift ? activeShift.id : undefined
            }
        });
        // Update status expense piutang jadi PAID
        const updatedExpense = await tx.expense.update({
            where: { id },
            data: { status: 'PAID' }
        });
        // ─── AWARD LOYALTY POINTS NOW THAT IT'S PAID ───
        if (expense.memberId && finalPaymentAmount > 0) {
            try {
                if (expense.sessionId) {
                    const session = await tx.session.findUnique({ where: { id: expense.sessionId } });
                    if (session) {
                        // Award points based on session breakdown
                        if (session.tableAmount > 0) {
                            await loyalty_service_1.LoyaltyService.awardGamePoints(session.id, expense.memberId, session.tableAmount);
                        }
                        if (session.fnbAmount > 0) {
                            await loyalty_service_1.LoyaltyService.awardFnbPoints(expense.memberId, session.fnbAmount, session.id);
                        }
                        // Check Streak
                        await loyalty_service_1.LoyaltyService.checkAndUpdateStreak(expense.memberId);
                    }
                }
                else {
                    // Manual debt with no session - award generic fnb points based on amount
                    await loyalty_service_1.LoyaltyService.awardFnbPoints(expense.memberId, finalPaymentAmount);
                }
            }
            catch (e) {
                console.error('[Loyalty] Error during debt payment points:', e);
            }
        }
        return updatedExpense;
    });
    (0, socket_1.getIO)().emit('sessions:updated');
    (0, socket_1.getIO)().emit('expenses:updated');
    res.json({ success: true, data: result });
});
exports.deleteExpense = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    await db_1.prisma.expense.update({
        where: { id },
        data: { deletedAt: new Date() }
    });
    (0, socket_1.getIO)().emit('sessions:updated');
    (0, socket_1.getIO)().emit('expenses:updated');
    res.json({ success: true, message: 'Expense deleted successfully' });
});
exports.bulkDeleteExpenses = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
        throw new errors_1.AppError('No IDs provided', 400);
    }
    await db_1.prisma.expense.updateMany({
        where: { id: { in: ids } },
        data: { deletedAt: new Date() }
    });
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json({ success: true, message: `${ids.length} expenses deleted successfully` });
});
