"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const relay_service_1 = require("../relay/relay.service");
const pricing_service_1 = require("../pricing/pricing.service");
const audit_service_1 = require("../audit/audit.service");
const member_service_1 = require("../members/member.service");
const socket_1 = require("../../socket");
const logger_1 = require("../../utils/logger");
/** Emit socket event secara fire-and-forget — tidak pernah crash main flow */
function emitSocket(event, data) {
    try {
        const io = (0, socket_1.getIO)();
        if (io)
            io.emit(event, data);
    }
    catch (e) {
        logger_1.logger.warn(`[Socket] Gagal emit '${event}': ${e}`);
    }
}
class SessionService {
    static async updateSession(sessionId, data, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId } });
        if (!session)
            throw new errors_1.AppError('Session not found', 404);
        const updatedSession = await db_1.prisma.session.update({
            where: { id: sessionId },
            data: {
                memberId: data.memberId === undefined ? session.memberId : data.memberId,
                customerName: data.customerName === undefined ? session.customerName : data.customerName,
            },
            include: { member: true, table: true }
        });
        audit_service_1.AuditService.log(userId, 'SESSION_UPDATE', 'Session', { sessionId, ...data }).catch(() => { });
        emitSocket('session:updated', { sessionId });
        return updatedSession;
    }
    static async startSession(tableId, userId, packageId, memberId, customDurationOpts, overrideAmount, billingType) {
        // --- TRANSAKSI UNTUK CEGAH RACE CONDITION ---
        const session = await db_1.prisma.$transaction(async (tx) => {
            // 1. Cek status meja terbaru (serializable update)
            const table = await tx.table.findUnique({
                where: { id: tableId },
                select: { id: true, status: true, relayChannel: true, type: true }
            });
            if (!table || table.status !== 'AVAILABLE') {
                throw new errors_1.AppError('Meja sudah terisi atau tidak tersedia!', 400);
            }
            // 2. Hitung durasi & harga
            let durationOpts = null;
            let tableAmount = 0;
            let fnbIncluded = null;
            if (packageId) {
                const pkg = await tx.package.findUnique({ where: { id: packageId } });
                if (!pkg)
                    throw new errors_1.AppError('Paket tidak ditemukan!', 404);
                durationOpts = pkg.duration;
                tableAmount = (memberId && pkg.memberPrice) ? pkg.memberPrice : pkg.price;
                fnbIncluded = pkg.fnbItems;
            }
            else if (customDurationOpts) {
                durationOpts = customDurationOpts;
                const now = new Date();
                const mockEndTime = new Date(now.getTime() + durationOpts * 60000);
                const isMember = !!memberId;
                // Use provided billingType or fallback to table's default type
                const calculationType = billingType || table.type;
                tableAmount = await pricing_service_1.PricingService.calculateTableAmount(calculationType, now, mockEndTime, isMember);
            }
            if (overrideAmount !== undefined) {
                tableAmount = overrideAmount;
            }
            // 3. Buat Sesi & Update Meja serentak
            const newSession = await tx.session.create({
                data: {
                    tableId,
                    packageId,
                    memberId,
                    durationOpts: Number(durationOpts),
                    tableAmount,
                    fnbIncluded,
                    status: 'ACTIVE',
                    cashierId: userId,
                    billingType: billingType || null,
                },
                include: { table: true }
            });
            await tx.table.update({
                where: { id: tableId },
                data: { status: 'PLAYING' }
            });
            return newSession;
        });
        // 4. FIRE-AND-FORGET (Diluar transaksi agar tidak membebani DB)
        if (session.table) {
            relay_service_1.RelayService.sendCommand(session.table.relayChannel, 'on').catch(e => logger_1.logger.error(`[RELAY] Error start: ${e.message}`));
        }
        audit_service_1.AuditService.log(userId, 'SESSION_START', 'Session', { sessionId: session.id, tableId }).catch(() => { });
        // Broadcast ke semua kasir & admin
        emitSocket('session:start', { sessionId: session.id, tableId, status: 'ACTIVE' });
        emitSocket('table:update', { tableId, status: 'PLAYING' });
        return session;
    }
    static async moveSession(sessionId, newTableId, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId }, include: { table: true } });
        if (!session || session.status !== 'ACTIVE')
            throw new errors_1.AppError('Invalid session', 400);
        const newTable = await db_1.prisma.table.findUnique({ where: { id: newTableId } });
        if (!newTable || newTable.status !== 'AVAILABLE')
            throw new errors_1.AppError('New table is not available', 400);
        await db_1.prisma.$transaction(async (tx) => {
            if (session.tableId && session.table) {
                await tx.table.update({ where: { id: session.tableId }, data: { status: 'AVAILABLE' } });
                await relay_service_1.RelayService.sendCommand(session.table.relayChannel, 'off');
            }
            await tx.table.update({ where: { id: newTableId }, data: { status: 'PLAYING' } });
            await tx.session.update({ where: { id: sessionId }, data: { tableId: newTableId } });
        });
        await relay_service_1.RelayService.sendCommand(newTable.relayChannel, 'on');
        await audit_service_1.AuditService.log(userId, 'SESSION_MOVE', 'Session', { sessionId, fromTable: session.tableId, toTable: newTableId });
        emitSocket('session:move', { sessionId, fromTable: session.tableId, toTable: newTableId });
        if (session.tableId)
            emitSocket('table:update', { tableId: session.tableId, status: 'AVAILABLE' });
        emitSocket('table:update', { tableId: newTableId, status: 'PLAYING' });
        return { success: true };
    }
    static async addDuration(sessionId, userId, packageId, customDurationOpts) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId }, include: { table: true } });
        if (!session || session.status !== 'ACTIVE')
            throw new errors_1.AppError('Invalid session', 400);
        let extraDuration = 0;
        let extraAmount = 0;
        if (packageId) {
            const pkg = await db_1.prisma.package.findUnique({ where: { id: packageId } });
            if (!pkg)
                throw new errors_1.AppError('Package not found', 404);
            extraDuration = pkg.duration;
            extraAmount = (session.memberId && pkg.memberPrice) ? pkg.memberPrice : pkg.price;
        }
        else if (customDurationOpts) {
            if (!session.table)
                throw new errors_1.AppError('Session has no table', 400);
            extraDuration = customDurationOpts;
            const now = new Date();
            const mockEndTime = new Date(now.getTime() + extraDuration * 60000);
            const isMember = !!session.memberId;
            extraAmount = await pricing_service_1.PricingService.calculateTableAmount(session.table.type, now, mockEndTime, isMember);
        }
        const pkgData = packageId ? await db_1.prisma.package.findUnique({ where: { id: packageId } }) : null;
        const extraFnb = pkgData?.fnbItems;
        const updatedSession = await db_1.prisma.session.update({
            where: { id: sessionId },
            data: {
                durationOpts: (session.durationOpts || 0) + extraDuration,
                tableAmount: session.tableAmount + extraAmount,
                fnbIncluded: session.fnbIncluded ? (session.fnbIncluded + (extraFnb ? `, ${extraFnb}` : '')) : extraFnb
            }
        });
        await audit_service_1.AuditService.log(userId, 'SESSION_ADD_DURATION', 'Session', { sessionId, extraDuration, extraAmount });
        emitSocket('session:update', { sessionId, type: 'ADD_DURATION', extraDuration });
        return updatedSession;
    }
    static async endSession(sessionId, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId }, include: { table: true } });
        if (!session || session.status !== 'ACTIVE')
            throw new errors_1.AppError('Invalid session', 400);
        const endTime = new Date();
        const isMember = !!session.memberId;
        let tableAmount = session.tableAmount;
        // Calculate Open Time billing ONLY if no package and no custom duration was pre-selected
        if (!session.packageId && !session.durationOpts && session.table) {
            const calculationType = session.billingType || session.table.type;
            tableAmount = await pricing_service_1.PricingService.calculateTableAmount(calculationType, session.startTime, endTime, isMember);
        }
        const updatedSession = await db_1.prisma.session.update({
            where: { id: sessionId },
            data: {
                status: 'FINISHED',
                endTime,
                tableAmount,
                totalAmount: tableAmount + session.fnbAmount,
                taxAmount: 0,
                serviceAmount: 0,
            }
        });
        // Set table status to AVAILABLE
        if (session.tableId) {
            await db_1.prisma.table.update({
                where: { id: session.tableId },
                data: { status: 'AVAILABLE' }
            });
        }
        // Fire-and-forget relay, audit & socket agar response cepat
        if (session.table) {
            relay_service_1.RelayService.sendCommand(session.table.relayChannel, 'off').catch(e => console.error('Relay error:', e));
        }
        audit_service_1.AuditService.log(userId, 'SESSION_END', 'Session', { sessionId, tableAmount }).catch(() => { });
        emitSocket('session:end', { sessionId, tableId: session.tableId, status: 'FINISHED' });
        if (session.tableId)
            emitSocket('table:update', { tableId: session.tableId, status: 'AVAILABLE' });
        if (session.memberId) {
            const playedMs = endTime.getTime() - session.startTime.getTime();
            const hoursPlayed = playedMs / (1000 * 60 * 60);
            await member_service_1.MemberService.updatePlayHours(session.memberId, hoursPlayed);
        }
        return updatedSession;
    }
    static async setPending(sessionId, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId } });
        if (!session || session.status !== 'FINISHED')
            throw new errors_1.AppError('Session must be FINISHED to be set PENDING', 400);
        await db_1.prisma.session.update({
            where: { id: sessionId },
            data: { status: 'PENDING' }
        });
        await audit_service_1.AuditService.log(userId, 'SESSION_PENDING', 'Session', { sessionId });
        return { success: true };
    }
    static async paySession(sessionId, method, userId, discount = 0, receivedAmount = 0, taxAmount = 0, serviceAmount = 0) {
        const session = await db_1.prisma.session.findUnique({
            where: { id: sessionId },
            include: { table: true }
        });
        if (!session || !['FINISHED', 'PENDING'].includes(session.status)) {
            throw new errors_1.AppError('Invalid session for payment', 400);
        }
        const subtotal = session.tableAmount + session.fnbAmount;
        const totalWithCharges = subtotal + (taxAmount || 0) + (serviceAmount || 0);
        const finalAmount = Math.max(0, totalWithCharges - discount);
        const change = receivedAmount > finalAmount ? receivedAmount - finalAmount : 0;
        const memberId = session.memberId;
        const result = await db_1.prisma.$transaction(async (tx) => {
            // Cek shift aktif untuk kasir ini
            const activeShift = await tx.cashierShift.findFirst({
                where: { userId, status: 'OPEN' }
            });
            const payment = await tx.payment.create({
                data: {
                    sessionId,
                    amount: finalAmount,
                    discount: discount,
                    received: receivedAmount,
                    change: change,
                    method,
                    status: 'SUCCESS',
                    cashierId: userId,
                    shiftId: activeShift ? activeShift.id : null
                }
            });
            await tx.session.update({
                where: { id: sessionId },
                data: {
                    status: 'PAID',
                    taxAmount: taxAmount || 0,
                    serviceAmount: serviceAmount || 0,
                    totalAmount: totalWithCharges,
                    paymentMethod: method // store method on session too
                }
            });
            // INTEGRATE NEW LOYALTY SYSTEM
            if (memberId && finalAmount > 0) {
                try {
                    const { LoyaltyService } = await Promise.resolve().then(() => __importStar(require('../loyalty/loyalty.service')));
                    // Award points for Table & FNB
                    if (session.tableAmount > 0 && session.memberId) {
                        await LoyaltyService.awardGamePoints(sessionId, session.memberId, session.tableAmount);
                    }
                    if (session.fnbAmount > 0 && session.memberId) {
                        await LoyaltyService.awardFnbPoints(session.memberId, session.fnbAmount, sessionId);
                    }
                    // Update Total Spend for Tiering
                    await member_service_1.MemberService.updateSpend(memberId, finalAmount);
                    // Update Streak
                    if (session.memberId) {
                        await LoyaltyService.checkAndUpdateStreak(session.memberId);
                    }
                }
                catch (e) {
                    console.error('Loyalty award error:', e);
                    // We don't want to fail the whole payment if loyalty system has an issue
                }
            }
            return payment;
        });
        await audit_service_1.AuditService.log(userId, 'SESSION_PAYMENT', 'Payment', { sessionId, paymentId: result.id });
        emitSocket('session:paid', { sessionId, paymentId: result.id, amount: result.amount });
        // WA NOTIFICATION RECEIPT
        if (memberId) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                const venueName = venue?.name || 'VAMOS';
                const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
                if (member && member.phone) {
                    const { WaTemplateService, WA_TEMPLATE_IDS } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.template.service')));
                    const waTemplate = await WaTemplateService.renderTemplate(WA_TEMPLATE_IDS.PAYMENT_RECEIPT, {
                        name: member.name,
                        venue: venueName,
                        table: session.table?.name || 'VAMOS',
                        amount: finalAmount.toLocaleString('id-ID'),
                    });
                    if (waTemplate) {
                        Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service'))).then(({ waService }) => {
                            waService.sendMessage(member.phone, waTemplate.body, waTemplate.imageUrl || undefined);
                        });
                    }
                }
            }
            catch (error) {
                console.error('Failed to send WA receipt:', error);
            }
        }
        return result;
    }
    static async payAsDebt(sessionId, userId, discount = 0, taxAmount = 0, serviceAmount = 0) {
        const session = await db_1.prisma.session.findUnique({
            where: { id: sessionId },
            include: { table: true, orders: { include: { product: true } }, member: true }
        });
        if (!session || !['FINISHED', 'PENDING'].includes(session.status)) {
            throw new errors_1.AppError('Invalid session for debt payment', 400);
        }
        if (!session.memberId) {
            throw new errors_1.AppError('Hanya member yang bisa melakukan pembayaran piutang (BON)!', 400);
        }
        const subtotal = session.tableAmount + session.fnbAmount;
        const totalWithCharges = subtotal + (taxAmount || 0) + (serviceAmount || 0);
        const finalAmount = Math.max(0, totalWithCharges - discount);
        // Record the debt in Expense table
        const fnbDetails = (session.orders && session.orders.length > 0)
            ? session.orders.map(o => `${o.product.name} x${o.quantity}`).join(', ')
            : 'No FnB';
        const description = `Piutang (BON) - ${session.member?.name}. Sesi: ${session.table?.name || 'FNB Only'}. Detail: ${fnbDetails}`;
        const result = await db_1.prisma.$transaction(async (tx) => {
            await tx.session.update({
                where: { id: sessionId },
                data: {
                    status: 'PAID',
                    taxAmount: taxAmount || 0,
                    serviceAmount: serviceAmount || 0,
                    totalAmount: totalWithCharges,
                    paymentMethod: 'BON'
                }
            });
            const expense = await tx.expense.create({
                data: {
                    category: 'DEBT',
                    amount: finalAmount,
                    description,
                    isDebt: true,
                    status: 'PENDING',
                    memberId: session.memberId,
                    sessionId: session.id,
                    date: new Date()
                }
            });
            // AWARD LOYALTY POINTS MOVED TO DEBT SETTLEMENT INSTEAD
            // We removed the awarding here because the payment is still a debt (BON)
            // Update Total Spend for Tiering (Keep this as spending is recorded)
            if (session.memberId && finalAmount > 0) {
                await member_service_1.MemberService.updateSpend(session.memberId, finalAmount);
            }
            return expense;
        });
        audit_service_1.AuditService.log(userId, 'SESSION_DEBT_PAYMENT', 'Expense', { sessionId, expenseId: result.id });
        emitSocket('session:paid', { sessionId, amount: finalAmount, method: 'BON' });
        return result;
    }
    /**
     * SPLIT BILL: Bayar satu sesi dengan 2 metode berbeda (misal: QRIS + CASH).
     * Membuat 2 record Payment terpisah agar laporan QRIS vs Cash tetap akurat.
     * Session.paymentMethod diset ke 'SPLIT'.
     */
    static async paySessionSplit(sessionId, qrisAmount, cashAmount, cashReceived, userId, discount = 0, taxAmount = 0, serviceAmount = 0) {
        const session = await db_1.prisma.session.findUnique({
            where: { id: sessionId },
            include: { table: true }
        });
        if (!session || !['FINISHED', 'PENDING'].includes(session.status)) {
            throw new errors_1.AppError('Invalid session for payment', 400);
        }
        const subtotal = session.tableAmount + session.fnbAmount;
        const totalWithCharges = subtotal + (taxAmount || 0) + (serviceAmount || 0);
        const finalAmount = Math.max(0, totalWithCharges - discount);
        // Validate split totals match the bill
        const splitTotal = qrisAmount + cashAmount;
        if (Math.abs(splitTotal - finalAmount) > 1) { // allow Rp1 rounding diff
            throw new errors_1.AppError(`Split total (${splitTotal}) tidak sama dengan tagihan (${finalAmount})`, 400);
        }
        const cashChange = cashReceived > cashAmount ? cashReceived - cashAmount : 0;
        const memberId = session.memberId;
        const result = await db_1.prisma.$transaction(async (tx) => {
            const activeShift = await tx.cashierShift.findFirst({
                where: { userId, status: 'OPEN' }
            });
            const shiftId = activeShift ? activeShift.id : null;
            // Create QRIS payment record
            const qrisPayment = await tx.payment.create({
                data: {
                    sessionId,
                    amount: qrisAmount,
                    discount: 0, // discount applied to cash portion
                    received: qrisAmount,
                    change: 0,
                    method: 'QRIS',
                    status: 'SUCCESS',
                    cashierId: userId,
                    shiftId,
                    notes: 'SPLIT_PAYMENT'
                }
            });
            // Create CASH payment record
            const cashPayment = await tx.payment.create({
                data: {
                    sessionId,
                    amount: cashAmount,
                    discount: discount || 0,
                    received: cashReceived,
                    change: cashChange,
                    method: 'CASH',
                    status: 'SUCCESS',
                    cashierId: userId,
                    shiftId,
                    notes: 'SPLIT_PAYMENT'
                }
            });
            // Update session to PAID with method = SPLIT
            await tx.session.update({
                where: { id: sessionId },
                data: {
                    status: 'PAID',
                    taxAmount: taxAmount || 0,
                    serviceAmount: serviceAmount || 0,
                    totalAmount: totalWithCharges,
                    paymentMethod: 'SPLIT'
                }
            });
            // Award loyalty points
            if (memberId && finalAmount > 0) {
                try {
                    const { LoyaltyService } = await Promise.resolve().then(() => __importStar(require('../loyalty/loyalty.service')));
                    if (session.tableAmount > 0 && session.memberId) {
                        await LoyaltyService.awardGamePoints(sessionId, session.memberId, session.tableAmount);
                    }
                    if (session.fnbAmount > 0 && session.memberId) {
                        await LoyaltyService.awardFnbPoints(session.memberId, session.fnbAmount, sessionId);
                    }
                    await member_service_1.MemberService.updateSpend(memberId, finalAmount);
                    if (session.memberId) {
                        await LoyaltyService.checkAndUpdateStreak(session.memberId);
                    }
                }
                catch (e) {
                    console.error('Loyalty award error (split):', e);
                }
            }
            return { qrisPayment, cashPayment };
        });
        await audit_service_1.AuditService.log(userId, 'SESSION_SPLIT_PAYMENT', 'Payment', {
            sessionId,
            qrisAmount,
            cashAmount,
            qrisPaymentId: result.qrisPayment.id,
            cashPaymentId: result.cashPayment.id
        });
        emitSocket('session:paid', { sessionId, amount: finalAmount, method: 'SPLIT' });
        // WA receipt for member
        if (memberId) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                const venueName = venue?.name || 'VAMOS';
                const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
                if (member && member.phone) {
                    const { WaTemplateService, WA_TEMPLATE_IDS } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.template.service')));
                    const waTemplate = await WaTemplateService.renderTemplate(WA_TEMPLATE_IDS.PAYMENT_RECEIPT, {
                        name: member.name,
                        venue: venueName,
                        table: session.table?.name || 'VAMOS',
                        amount: finalAmount.toLocaleString('id-ID'),
                    });
                    if (waTemplate) {
                        Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service'))).then(({ waService }) => {
                            waService.sendMessage(member.phone, waTemplate.body, waTemplate.imageUrl || undefined);
                        });
                    }
                }
            }
            catch (error) {
                console.error('Failed to send WA receipt (split):', error);
            }
        }
        return result;
    }
    static remapSession(s) {
        if (!s)
            return null;
        return {
            ...s,
            startTime: s.startTime || s.starttime,
            endTime: s.endTime || s.endtime,
            durationOpts: s.durationOpts || s.durationopts,
            tableAmount: s.tableAmount || s.tableamount,
            fnbAmount: s.fnbAmount || s.fnbamount,
            taxAmount: s.taxAmount || s.taxamount,
            serviceAmount: s.serviceAmount || s.serviceamount,
            totalAmount: s.totalAmount || s.totalamount,
            memberId: s.memberId || s.memberid,
            customerName: s.customerName || s.customername,
            createdAt: s.createdAt || s.createdat,
            updatedAt: s.updatedAt || s.updatedat,
            deletedAt: s.deletedAt || s.deletedat,
            paymentMethod: s.paymentMethod || s.paymentmethod,
            fnbIncluded: s.fnbIncluded || s.fnbincluded,
            cashierId: s.cashierId || s.cashierid,
            tableId: s.tableId || s.tableid,
        };
    }
    static async getActiveSessions() {
        // === FIX N+1 QUERY: Ambil semua data dalam 2 query, bukan 1+N ===
        // Query 1: Ambil semua sesi aktif beserta tabel, venue, dan member
        const sessions = await db_1.prisma.$queryRawUnsafe(`
            SELECT s.*, 
            t.name as "tableName", t.type as "tableType", t."relayChannel", t."venueId",
            v."taxPercent", v."servicePercent",
            m.name as "memberName"
            FROM "Session" s
            LEFT JOIN "Table" t ON s."tableId" = t.id
            LEFT JOIN "Venue" v ON t."venueId" = v.id
            LEFT JOIN "Member" m ON s."memberId" = m.id
            WHERE s.status = 'ACTIVE'
        `);
        if (sessions.length === 0)
            return [];
        // Query 2: Ambil SEMUA orders sekaligus untuk semua sesi aktif (bukan per sesi)
        const sessionIds = sessions.map(s => s.id);
        const allOrders = await db_1.prisma.order.findMany({
            where: { sessionId: { in: sessionIds } },
            include: { product: true }
        });
        // Group orders by sessionId di memori — O(n) bukan O(n * queries)
        const ordersBySession = new Map();
        for (const order of allOrders) {
            if (!ordersBySession.has(order.sessionId)) {
                ordersBySession.set(order.sessionId, []);
            }
            ordersBySession.get(order.sessionId).push(order);
        }
        return sessions.map(s => {
            const session = this.remapSession(s);
            return {
                ...session,
                memberName: s.memberName || null,
                table: session.tableId ? {
                    id: session.tableId,
                    name: s.tableName,
                    type: s.tableType,
                    relayChannel: s.relayChannel,
                    venue: { id: s.venueId, taxPercent: s.taxPercent, servicePercent: s.servicePercent }
                } : null,
                orders: ordersBySession.get(s.id) || []
            };
        });
    }
    static async getPendingSessions() {
        return db_1.prisma.session.findMany({
            where: { status: { in: ['FINISHED', 'PENDING'] } },
            include: {
                table: { include: { venue: true } },
                member: true,
                orders: { include: { product: true } }
            },
            orderBy: { updatedAt: 'desc' }
        });
    }
    static async createFnbSession(userId, memberId, customerName) {
        const session = await db_1.prisma.session.create({
            data: {
                status: 'PENDING',
                memberId: memberId || null,
                customerName: customerName || null,
            }
        });
        await audit_service_1.AuditService.log(userId, 'SESSION_FNB_START', 'Session', { sessionId: session.id, customerName });
        return session;
    }
    static lastBlinkTimes = new Map();
    /**
     * Otomatis mematikan sesi yang sudah habis durasinya (prepaid/package)
     * DAN memberikan peringatan lampu berkedip (blink).
     */
    static async checkExpiredSessions() {
        const activeSessions = await db_1.prisma.session.findMany({
            where: {
                status: 'ACTIVE',
                OR: [
                    { durationOpts: { gt: 0 } },
                    { packageId: { not: null } }
                ]
            },
            include: {
                table: true,
                package: true
            }
        });
        if (activeSessions.length === 0)
            return 0;
        const now = new Date();
        const venue = await db_1.prisma.venue.findFirst();
        const warningMinutes = venue?.blinkWarningMinutes || 5;
        const warningMs = warningMinutes * 60000;
        let expiredCount = 0;
        for (const s of activeSessions) {
            // Jika durationOpts 0/null, cari di Package
            const effectiveDuration = s.durationOpts || s.package?.duration || 0;
            // Langompati jika Open Billing (0 menit)
            if (effectiveDuration === 0)
                continue;
            const durationMs = effectiveDuration * 60000;
            const limitTime = new Date(s.startTime.getTime() + durationMs);
            const timeLeftMs = limitTime.getTime() - now.getTime();
            // 1. CEK: Sesi Habis (Matikan Meja)
            if (timeLeftMs <= 0) {
                try {
                    await this.endSession(s.id, 'SYSTEM');
                    this.lastBlinkTimes.delete(s.id); // Bersihkan cache
                    expiredCount++;
                }
                catch (err) {
                    logger_1.logger.error(`[Auto-Expire] Gagal mengakhiri sesi ${s.id}: ${err.message}`);
                }
                continue;
            }
            // 2. CEK: Peringatan (Blink)
            const lastBlink = this.lastBlinkTimes.get(s.id) || 0;
            // Jika durasi diperpanjang melebihi batas warning, lupakan (reset) status kedipan sebelumnya.
            if (timeLeftMs > warningMs + 60000 && lastBlink !== 0) {
                this.lastBlinkTimes.delete(s.id);
            }
            // Jika sisa waktu <= warningMinutes DAN belum pernah blink di siklus terdekat ini
            if (timeLeftMs <= warningMs && lastBlink === 0) {
                if (s.table?.relayChannel) {
                    logger_1.logger.info(`🔔 [Auto-Blink] Peringatan Meja ${s.table.name} (${Math.round(timeLeftMs / 60000)} menit sisa)`);
                    relay_service_1.RelayService.blink(s.table.relayChannel).catch(() => { });
                    this.lastBlinkTimes.set(s.id, now.getTime());
                }
            }
        }
        if (activeSessions.length > 0) {
            logger_1.logger.info(`⏲️ [Session-Monitor] Memantau ${activeSessions.length} sesi...`);
        }
        return expiredCount;
    }
}
exports.SessionService = SessionService;
