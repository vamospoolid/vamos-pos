"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reprintReceipt = exports.updateSession = exports.createFnbOnly = exports.getPending = exports.getActive = exports.payAsDebt = exports.paySessionSplit = exports.paySession = exports.pendingSession = exports.addDuration = exports.moveSession = exports.endSession = exports.startSession = void 0;
const session_service_1 = require("./session.service");
const catchAsync_1 = require("../../utils/catchAsync");
const zod_1 = require("zod");
const socket_1 = require("../../socket");
const printer_service_1 = require("../system/printer.service");
const startSessionParams = zod_1.z.object({
    tableId: zod_1.z.string().min(1),
    packageId: zod_1.z.string().min(1).optional(),
    memberId: zod_1.z.string().min(1).optional(),
    durationOpts: zod_1.z.number().int().positive().optional(),
    billingType: zod_1.z.string().min(1).optional(),
});
exports.startSession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { tableId, packageId, memberId, durationOpts, billingType } = startSessionParams.parse(req.body);
    const session = await session_service_1.SessionService.startSession(tableId, req.user.id, packageId, memberId, durationOpts, undefined, billingType);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.status(201).json(session);
});
exports.endSession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const result = await session_service_1.SessionService.endSession(id, req.user.id);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json(result);
});
exports.moveSession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { newTableId } = zod_1.z.object({ newTableId: zod_1.z.string().min(1) }).parse(req.body);
    const result = await session_service_1.SessionService.moveSession(id, newTableId, req.user.id);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json(result);
});
exports.addDuration = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const schema = zod_1.z.object({
        packageId: zod_1.z.string().min(1).optional(),
        durationOpts: zod_1.z.number().int().positive().optional(),
    });
    const { packageId, durationOpts } = schema.parse(req.body);
    const result = await session_service_1.SessionService.addDuration(id, req.user.id, packageId, durationOpts);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json(result);
});
exports.pendingSession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.body;
    const result = await session_service_1.SessionService.setPending(id, req.user.id);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json(result);
});
exports.paySession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { method, discount, receivedAmount, taxAmount, serviceAmount } = req.body;
    const result = await session_service_1.SessionService.paySession(id, method, req.user.id, discount, receivedAmount, taxAmount, serviceAmount);
    (0, socket_1.getIO)().emit('sessions:updated');
    // Auto-print receipt in background
    printer_service_1.PrinterService.printReceipt(id);
    res.json(result);
});
exports.paySessionSplit = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const schema = zod_1.z.object({
        qrisAmount: zod_1.z.number().min(0),
        cashAmount: zod_1.z.number().min(0),
        cashReceived: zod_1.z.number().min(0),
        discount: zod_1.z.number().min(0).optional(),
        taxAmount: zod_1.z.number().min(0).optional(),
        serviceAmount: zod_1.z.number().min(0).optional(),
    });
    const { qrisAmount, cashAmount, cashReceived, discount, taxAmount, serviceAmount } = schema.parse(req.body);
    const result = await session_service_1.SessionService.paySessionSplit(id, qrisAmount, cashAmount, cashReceived, req.user.id, discount ?? 0, taxAmount ?? 0, serviceAmount ?? 0);
    (0, socket_1.getIO)().emit('sessions:updated');
    printer_service_1.PrinterService.printReceipt(id);
    res.json(result);
});
exports.payAsDebt = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { discount, taxAmount, serviceAmount } = req.body;
    const result = await session_service_1.SessionService.payAsDebt(id, req.user.id, discount, taxAmount || 0, serviceAmount || 0);
    (0, socket_1.getIO)().emit('sessions:updated');
    // Auto-print receipt in background
    printer_service_1.PrinterService.printReceipt(id);
    res.json(result);
});
exports.getActive = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const sessions = await session_service_1.SessionService.getActiveSessions();
    res.json(sessions);
});
exports.getPending = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const sessions = await session_service_1.SessionService.getPendingSessions();
    res.json(sessions);
});
exports.createFnbOnly = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId, customerName } = req.body;
    const session = await session_service_1.SessionService.createFnbSession(req.user.id, memberId, customerName);
    (0, socket_1.getIO)().emit('sessions:updated');
    res.status(201).json(session);
});
exports.updateSession = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const result = await session_service_1.SessionService.updateSession(id, req.body, req.user.id);
    res.json(result);
});
exports.reprintReceipt = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    // Trigger real-time print via Smart Bridge
    printer_service_1.PrinterService.printReceipt(id);
    res.json({ success: true, message: 'Print command sent' });
});
