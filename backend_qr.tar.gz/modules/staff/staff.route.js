"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const staff_controller_1 = require("./staff.controller");
const router = (0, express_1.Router)();
// Staff authentication
router.post('/login', staff_controller_1.StaffController.login);
// Venue GPS & Geofencing config
router.get('/venue', staff_controller_1.StaffController.getVenueLocation);
router.put('/venue', staff_controller_1.StaffController.updateVenueLocation);
// Employee Approval & Jobdesk update
router.put('/employee/:employeeId/approval', staff_controller_1.StaffController.updateApprovalStatus);
// Attendance operations (Selfie + GPS)
router.post('/attendance/checkin', staff_controller_1.StaffController.checkIn);
router.post('/attendance/checkout', staff_controller_1.StaffController.checkOut);
router.get('/attendance/history/:employeeId', staff_controller_1.StaffController.getAttendanceHistory);
// KPI & Leaderboard Karyawan Teladan
router.get('/leaderboard', staff_controller_1.StaffController.getLeaderboard);
// Waiter Order Taking Helpers (Tables & Products)
router.get('/tables', staff_controller_1.StaffController.getTables);
router.get('/products', staff_controller_1.StaffController.getProducts);
exports.default = router;
