"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
class StaffService {
    /**
     * Staff Login via Phone & PIN code
     */
    static async login(phone, pinCode) {
        if (!phone || !pinCode) {
            throw new errors_1.AppError('Nomor HP dan PIN wajib diisi', 400);
        }
        const employee = await db_1.prisma.employee.findFirst({
            where: {
                phone: phone.trim(),
                deletedAt: null,
                status: 'ACTIVE'
            },
            include: {
                shift: true
            }
        });
        if (!employee) {
            throw new errors_1.AppError('Karyawan tidak ditemukan atau tidak aktif', 404);
        }
        if (employee.approvalStatus === 'PENDING') {
            throw new errors_1.AppError('Akun Anda masih menunggu konfirmasi & persetujuan dari kasir/manager', 403);
        }
        if (employee.approvalStatus === 'REJECTED') {
            throw new errors_1.AppError('Pendaftaran akun staf ini telah ditolak oleh manajemen', 403);
        }
        if (employee.pinCode && employee.pinCode !== pinCode.trim()) {
            throw new errors_1.AppError('PIN yang Anda masukkan salah', 401);
        }
        return {
            id: employee.id,
            name: employee.name,
            position: employee.position,
            phone: employee.phone,
            avatarUrl: employee.avatarUrl,
            jobdesk: employee.jobdesk || '1. Melayani pelanggan dengan ramah & profesional.\n2. Menjaga kebersihan area kerja & meja biliar.\n3. Memeriksa ketersediaan stok & pesanan FnB.\n4. Mematuhi SOP operasional & jam kerja shift.',
            approvalStatus: employee.approvalStatus,
            shift: employee.shift
        };
    }
    /**
     * Update Approval Status Staf dari POS Kasir
     */
    static async updateApprovalStatus(employeeId, status, jobdesk) {
        return db_1.prisma.employee.update({
            where: { id: employeeId },
            data: {
                approvalStatus: status,
                jobdesk: jobdesk !== undefined ? jobdesk : undefined
            }
        });
    }
    /**
     * Update Venue Coordinates & Geofencing Radius dari POS Kasir
     */
    static async updateVenueLocation(data) {
        const venue = await db_1.prisma.venue.findFirst({ where: { deletedAt: null } });
        if (!venue)
            throw new errors_1.AppError('Venue tidak ditemukan', 404);
        return db_1.prisma.venue.update({
            where: { id: venue.id },
            data: {
                latitude: data.latitude,
                longitude: data.longitude,
                attendanceRadiusMeters: data.radiusMeters || venue.attendanceRadiusMeters
            }
        });
    }
    /**
     * Get Venue info for GPS Geofencing
     */
    static async getVenueLocation() {
        const venue = await db_1.prisma.venue.findFirst({
            where: { deletedAt: null }
        });
        return {
            name: venue?.name || 'Vamos Arena',
            latitude: venue?.latitude || -8.6500,
            longitude: venue?.longitude || 115.2166,
            radiusMeters: venue?.attendanceRadiusMeters || 100
        };
    }
    /**
     * Hitung jarak dua titik GPS (Haversine formula dalam meter)
     */
    static calculateDistanceMeters(lat1, lon1, lat2, lon2) {
        const R = 6371e3; // Earth radius in meters
        const phi1 = (lat1 * Math.PI) / 180;
        const phi2 = (lat2 * Math.PI) / 180;
        const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
        const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;
        const a = Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
            Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return Math.round(R * c);
    }
    /**
     * Check-in Attendance dengan Foto Selfie WebP & Validasi GPS
     */
    static async checkIn(data) {
        const employee = await db_1.prisma.employee.findFirst({
            where: { id: data.employeeId, deletedAt: null },
            include: { shift: true }
        });
        if (!employee)
            throw new errors_1.AppError('Karyawan tidak ditemukan', 404);
        // Verifikasi GPS Radius jika koordinat dikirim
        const venue = await this.getVenueLocation();
        if (data.lat && data.lng && venue.latitude && venue.longitude) {
            const distance = this.calculateDistanceMeters(data.lat, data.lng, venue.latitude, venue.longitude);
            if (distance > venue.radiusMeters) {
                throw new errors_1.AppError(`Anda berada ${distance}m dari venue. Absen hanya diizinkan dalam radius ${venue.radiusMeters}m.`, 403);
            }
        }
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const existing = await db_1.prisma.attendance.findFirst({
            where: {
                employeeId: data.employeeId,
                date: {
                    gte: today,
                    lt: new Date(today.getTime() + 24 * 60 * 60 * 1000)
                }
            }
        });
        if (existing) {
            if (existing.checkIn && !existing.checkOut) {
                return existing;
            }
            throw new errors_1.AppError('Anda sudah melakukan absensi hari ini', 400);
        }
        // Kalkulasi Keterlambatan berdasarkan Shift
        let status = 'PRESENT';
        let lateMinutes = 0;
        if (employee.shift) {
            const [shiftHour, shiftMinute] = employee.shift.startTime.split(':').map(Number);
            const now = new Date();
            const shiftStartTime = new Date();
            shiftStartTime.setHours(shiftHour, shiftMinute, 0, 0);
            const diffMinutes = Math.floor((now.getTime() - shiftStartTime.getTime()) / (1000 * 60));
            if (diffMinutes > employee.shift.graceLateMinutes) {
                status = 'LATE';
                lateMinutes = diffMinutes;
            }
        }
        return db_1.prisma.attendance.create({
            data: {
                employeeId: data.employeeId,
                shiftId: employee.shiftId,
                date: new Date(),
                checkIn: new Date(),
                checkInPhoto: data.photoBase64 || null,
                checkInLat: data.lat || null,
                checkInLng: data.lng || null,
                status,
                lateMinutes,
                notes: data.notes || null
            }
        });
    }
    /**
     * Check-out Attendance
     */
    static async checkOut(data) {
        const existing = await db_1.prisma.attendance.findUnique({ where: { id: data.attendanceId } });
        if (!existing)
            throw new errors_1.AppError('Data absensi tidak ditemukan', 404);
        if (existing.checkOut)
            throw new errors_1.AppError('Anda sudah check-out hari ini', 400);
        return db_1.prisma.attendance.update({
            where: { id: data.attendanceId },
            data: {
                checkOut: new Date(),
                checkOutPhoto: data.photoBase64 || null,
                notes: data.notes ? `${existing.notes ? existing.notes + ' | ' : ''}Out: ${data.notes}` : existing.notes
            }
        });
    }
    /**
     * Riwayat Absensi Bulanan Staf
     */
    static async getAttendanceHistory(employeeId, monthStr) {
        const now = monthStr ? new Date(monthStr + '-01') : new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        return db_1.prisma.attendance.findMany({
            where: {
                employeeId,
                date: {
                    gte: startOfMonth,
                    lte: endOfMonth
                }
            },
            include: {
                shift: true
            },
            orderBy: { date: 'desc' }
        });
    }
    /**
     * Dashboard Leaderboard Karyawan Teladan & KPI
     */
    static async getLeaderboard(periodMonth) {
        const targetMonth = periodMonth || new Date().toISOString().substring(0, 7); // e.g. "2026-09"
        const employees = await db_1.prisma.employee.findMany({
            where: { deletedAt: null, status: 'ACTIVE' },
            include: {
                bonuses: {
                    where: { periodMonth: targetMonth }
                },
                attendances: {
                    where: {
                        date: {
                            gte: new Date(targetMonth + '-01'),
                            lte: new Date(new Date(targetMonth + '-01').getFullYear(), new Date(targetMonth + '-01').getMonth() + 1, 0, 23, 59, 59)
                        }
                    }
                }
            }
        });
        const leaderboard = employees.map(emp => {
            const totalDays = emp.attendances.length;
            const onTimeDays = emp.attendances.filter(a => a.status === 'PRESENT').length;
            const lateDays = emp.attendances.filter(a => a.status === 'LATE').length;
            // Perhitungan Skor Kehadiran (100 - (lateDays * 5))
            const attendanceScore = totalDays > 0 ? Math.max(0, Math.round((onTimeDays / totalDays) * 100)) : 100;
            const bonusRecord = emp.bonuses[0];
            const salesScore = bonusRecord?.salesTargetScore || 0;
            const ratingScore = bonusRecord?.customerRatingScore || 5.0;
            const totalBonus = bonusRecord?.totalBonus || (lateDays === 0 && totalDays >= 20 ? 250000 : 0);
            // Total Skor Prestasi Komprehensif
            const overallScore = Math.round((attendanceScore * 0.5) + (ratingScore * 10 * 0.3) + (salesScore * 0.2));
            return {
                employeeId: emp.id,
                name: emp.name,
                position: emp.position,
                avatarUrl: emp.avatarUrl,
                attendanceScore,
                onTimeDays,
                lateDays,
                totalDays,
                salesScore,
                ratingScore,
                overallScore,
                totalBonus,
                badge: overallScore >= 95 ? 'STAFF_OF_THE_MONTH' : attendanceScore === 100 ? 'PERFECT_ATTENDANCE' : null
            };
        });
        // Urutkan dari skor tertinggi
        leaderboard.sort((a, b) => b.overallScore - a.overallScore);
        return {
            periodMonth: targetMonth,
            rankings: leaderboard
        };
    }
    /**
     * Get Tables for Waiter Order Taking
     */
    static async getWaiterTables() {
        return db_1.prisma.table.findMany({
            where: { deletedAt: null },
            orderBy: { relayChannel: 'asc' }
        });
    }
    /**
     * Get Products / Menu for Waiter Order Taking
     */
    static async getWaiterProducts() {
        return db_1.prisma.product.findMany({
            where: { deletedAt: null },
            orderBy: { category: 'asc' }
        });
    }
}
exports.StaffService = StaffService;
