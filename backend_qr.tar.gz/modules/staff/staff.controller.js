"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffController = void 0;
const staff_service_1 = require("./staff.service");
class StaffController {
    static async login(req, res, next) {
        try {
            const { phone, pinCode } = req.body;
            const result = await staff_service_1.StaffService.login(phone, pinCode);
            res.json({ success: true, data: result });
        }
        catch (error) {
            next(error);
        }
    }
    static async getVenueLocation(req, res, next) {
        try {
            const venue = await staff_service_1.StaffService.getVenueLocation();
            res.json({ success: true, data: venue });
        }
        catch (error) {
            next(error);
        }
    }
    static async checkIn(req, res, next) {
        try {
            const result = await staff_service_1.StaffService.checkIn(req.body);
            res.status(201).json({ success: true, data: result, message: 'Absensi masuk berhasil' });
        }
        catch (error) {
            next(error);
        }
    }
    static async checkOut(req, res, next) {
        try {
            const result = await staff_service_1.StaffService.checkOut(req.body);
            res.json({ success: true, data: result, message: 'Absensi pulang berhasil' });
        }
        catch (error) {
            next(error);
        }
    }
    static async getAttendanceHistory(req, res, next) {
        try {
            const { employeeId } = req.params;
            const { month } = req.query;
            const history = await staff_service_1.StaffService.getAttendanceHistory(employeeId, month);
            res.json({ success: true, data: history });
        }
        catch (error) {
            next(error);
        }
    }
    static async getLeaderboard(req, res, next) {
        try {
            const { month } = req.query;
            const leaderboard = await staff_service_1.StaffService.getLeaderboard(month);
            res.json({ success: true, data: leaderboard });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateVenueLocation(req, res, next) {
        try {
            const result = await staff_service_1.StaffService.updateVenueLocation(req.body);
            res.json({ success: true, data: result, message: 'Koordinat lokasi & radius venue berhasil disimpan' });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateApprovalStatus(req, res, next) {
        try {
            const { employeeId } = req.params;
            const { status, jobdesk } = req.body;
            const result = await staff_service_1.StaffService.updateApprovalStatus(employeeId, status, jobdesk);
            res.json({ success: true, data: result, message: 'Status konfirmasi staf berhasil diperbarui' });
        }
        catch (error) {
            next(error);
        }
    }
    static async getTables(req, res, next) {
        try {
            const tables = await staff_service_1.StaffService.getWaiterTables();
            res.json({ success: true, data: tables });
        }
        catch (error) {
            next(error);
        }
    }
    static async getProducts(req, res, next) {
        try {
            const products = await staff_service_1.StaffService.getWaiterProducts();
            res.json({ success: true, data: products });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.StaffController = StaffController;
