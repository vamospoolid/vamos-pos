"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLeaderboard = exports.recordMatch = void 0;
const match_service_1 = require("./match.service");
const catchAsync_1 = require("../../utils/catchAsync");
const zod_1 = require("zod");
const recordMatchSchema = zod_1.z.object({
    sessionId: zod_1.z.string().min(1),
    memberIds: zod_1.z.array(zod_1.z.string().min(1)),
    winnerId: zod_1.z.string().min(1).nullable().optional()
});
exports.recordMatch = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const parsed = recordMatchSchema.parse(req.body);
    const match = await match_service_1.MatchService.recordMatch(parsed.sessionId, parsed.memberIds, parsed.winnerId || null, req.user.id);
    res.status(201).json(match);
});
exports.getLeaderboard = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const leaderboard = await match_service_1.MatchService.getLeaderboard();
    res.json(leaderboard);
});
