"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const match_controller_1 = require("./match.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
router.post('/', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'KASIR'), match_controller_1.recordMatch);
router.get('/leaderboard', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'KASIR', 'OWNER'), match_controller_1.getLeaderboard);
exports.default = router;
