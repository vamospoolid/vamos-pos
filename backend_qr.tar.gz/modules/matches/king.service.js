"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KingService = void 0;
const db_1 = require("../../database/db");
const socket_1 = require("../../socket");
class KingService {
    /**
     * Updates the King of the Table status after a match.
     * Only applies if the table is designated as a King Table.
     * @param tableId The ID of the table where the match was played
     * @param winnerId The member ID of the winner
     * @param matchId Optional match ID for tracking
     */
    static async handleMatchEnd(tableId, winnerId, matchId) {
        const table = await db_1.prisma.table.findUnique({
            where: { id: tableId },
            include: { kingStatus: true }
        });
        // Only process if it's a King Table
        if (!table || !table.isKingTable)
            return null;
        const currentKing = table.kingStatus;
        const io = (0, socket_1.getIO)();
        if (!currentKing) {
            // No king yet, first king for this table
            const newKing = await db_1.prisma.kingTable.create({
                data: {
                    tableId,
                    kingMemberId: winnerId,
                    streak: 1,
                    sinceMatchId: matchId || null
                },
                include: { king: true }
            });
            await this.updateMemberStreak(winnerId, 1);
            io.emit('arena:news', {
                type: 'KING_ASCENDED',
                message: `👑 ${newKing.king.name} has claimed the Throne at Table ${table.name}!`,
                data: newKing
            });
            return { action: 'NEW_KING', data: newKing };
        }
        if (currentKing.kingMemberId === winnerId) {
            // King defends the title
            const updatedKing = await db_1.prisma.kingTable.update({
                where: { tableId },
                data: {
                    streak: { increment: 1 }
                },
                include: { king: true }
            });
            await this.updateMemberStreak(winnerId, updatedKing.streak);
            if (updatedKing.streak % 3 === 0) { // Only announce high streaks
                io.emit('arena:news', {
                    type: 'KING_STREAK',
                    message: `🔥 ${updatedKing.king.name} is on a ${updatedKing.streak} MATCH STREAK at Table ${table.name}!`,
                    data: updatedKing
                });
            }
            return { action: 'KING_DEFENDED', data: updatedKing };
        }
        else {
            // King is dethroned!
            const newKing = await db_1.prisma.kingTable.update({
                where: { tableId },
                data: {
                    kingMemberId: winnerId,
                    streak: 1,
                    sinceMatchId: matchId || null
                },
                include: { king: true }
            });
            await this.updateMemberStreak(winnerId, 1);
            io.emit('arena:news', {
                type: 'KING_DETHRONED',
                message: `⚡ ${newKing.king.name} has DETHRONED the King at Table ${table.name}!`,
                data: newKing
            });
            return { action: 'KING_DETHRONED', data: newKing };
        }
    }
    static async updateMemberStreak(memberId, currentStreak) {
        const member = await db_1.prisma.member.findUnique({
            where: { id: memberId },
            select: { highestKingStreak: true }
        });
        if (member && currentStreak > member.highestKingStreak) {
            await db_1.prisma.member.update({
                where: { id: memberId },
                data: { highestKingStreak: currentStreak }
            });
        }
    }
    /**
     * Get all active King Tables and their current status
     */
    static async getGlobalKingStatus() {
        return db_1.prisma.kingTable.findMany({
            include: {
                table: { select: { name: true, id: true } },
                king: { select: { name: true, id: true, photo: true, level: true, skillRating: true, streakCount: true } }
            },
            orderBy: { streak: 'desc' }
        });
    }
    /**
     * Mark a table as a King Table
     */
    static async designateKingTable(tableId, isKing = true) {
        return db_1.prisma.table.update({
            where: { id: tableId },
            data: { isKingTable: isKing }
        });
    }
    /**
     * Get top players with highest historical streaks
     */
    static async getHallOfFame(limit = 10) {
        return db_1.prisma.member.findMany({
            where: { highestKingStreak: { gt: 0 }, deletedAt: null },
            select: {
                id: true,
                name: true,
                photo: true,
                level: true,
                highestKingStreak: true,
                skillRating: true
            },
            orderBy: { highestKingStreak: 'desc' },
            take: limit
        });
    }
}
exports.KingService = KingService;
