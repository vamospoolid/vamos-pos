"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MatchService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const audit_service_1 = require("../audit/audit.service");
class MatchService {
    static async recordMatch(sessionId, memberIds, winnerId, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId } });
        if (!session)
            throw new errors_1.AppError('Session not found', 404);
        const result = await db_1.prisma.$transaction(async (tx) => {
            const match = await tx.match.create({
                data: {
                    sessionId,
                    winnerId,
                    members: {
                        create: memberIds.map(memberId => ({ memberId }))
                    }
                }
            });
            for (const memberId of memberIds) {
                const isWinner = memberId === winnerId;
                const member = await tx.member.findUnique({ where: { id: memberId } });
                if (member) {
                    const totalMatches = member.totalMatches + 1;
                    const totalWins = member.totalWins + (isWinner ? 1 : 0);
                    const winRate = (totalWins / totalMatches) * 100;
                    await tx.member.update({
                        where: { id: memberId },
                        data: { totalMatches, totalWins, winRate }
                    });
                }
            }
            return match;
        });
        await audit_service_1.AuditService.log(userId, 'MATCH_RECORDED', 'Match', { matchId: result.id });
        return result;
    }
    static async getLeaderboard() {
        return db_1.prisma.member.findMany({
            orderBy: { winRate: 'desc' },
            take: 10,
            select: {
                id: true,
                name: true,
                totalMatches: true,
                totalWins: true,
                winRate: true
            }
        });
    }
}
exports.MatchService = MatchService;
