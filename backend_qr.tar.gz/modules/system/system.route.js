"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const system_controller_1 = require("./system.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
// Only ADMIN / OWNER can perform system operations
router.get('/export', auth_1.localOrAuthenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.exportBackup);
router.post('/reset', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.resetSystem);
router.post('/seed', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.seedDefaults);
router.post('/fix-tables', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.fixTables);
router.post('/print/test', auth_1.localOrAuthenticate, system_controller_1.SystemController.testPrinter);
// Database backup – allow offline restore on local Electron (IS_LOCAL_ELECTRON=true)
router.post('/backup', auth_1.localOrAuthenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.runBackup);
router.get('/backup/list', auth_1.localOrAuthenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.listBackups);
router.post('/backup/restore', auth_1.localOrAuthenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.restoreBackup);
router.post('/import', auth_1.localOrAuthenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), system_controller_1.SystemController.importDatabase);
// Local-First Sync
router.post('/sync-now', auth_1.authenticate, system_controller_1.SystemController.syncNow);
router.get('/unsynced-count', auth_1.authenticate, system_controller_1.SystemController.getUnsyncedCount);
router.post('/sync/receive', system_controller_1.SystemController.receiveSyncPayload);
exports.default = router;
