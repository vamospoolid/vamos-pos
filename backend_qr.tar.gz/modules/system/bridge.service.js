"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BridgeService = void 0;
const socket_io_client_1 = require("socket.io-client");
const relay_service_1 = require("../relay/relay.service");
const logger_1 = require("../../utils/logger");
class BridgeService {
    static client = null;
    static init() {
        if (this.client)
            return;
        // Bridge mode only if local
        if (process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON) {
            return;
        }
        const serverUrl = process.env.BRIDGE_SERVER_URL || 'https://pos.vamospool.id';
        logger_1.logger.info(`🌉 BRIDGING: Connecting to VPS Socket at ${serverUrl}...`);
        this.client = (0, socket_io_client_1.io)(serverUrl, {
            transports: ['websocket'],
            reconnection: true
        });
        this.client.on('connect', () => {
            logger_1.logger.info('🛰️ BRIDGE CONNECTED: Tuning into cloud signal.');
        });
        this.client.on('disconnect', () => {
            logger_1.logger.warn('🛰️ BRIDGE DISCONNECTED: Cloud signal lost.');
        });
        // Listen for relay commands from the VPS
        this.client.on('relay:command', async (data) => {
            logger_1.logger.info(`📥 BRIDGE RECEIVE: Turning Table ${data.channel} ${data.status.toUpperCase()}`);
            try {
                // Execute on local physical relay
                await relay_service_1.RelayService.sendCommand(data.channel, data.status);
            }
            catch (err) {
                logger_1.logger.error(`🚨 BRIDGE RELAY ERROR: ${err.message}`);
            }
        });
        // Listen for native blink commands
        this.client.on('relay:blink', async (data) => {
            logger_1.logger.info(`📥 BRIDGE RECEIVE: Blinking Table ${data.channel}`);
            try {
                // Let the local relay service handle the exact hardware timing pattern
                await relay_service_1.RelayService.blink(data.channel);
            }
            catch (err) {
                logger_1.logger.error(`🚨 BRIDGE BLINK ERROR: ${err.message}`);
            }
        });
        // Listen for Real-time Port Configuration update
        this.client.on('relay:config:update', async (data) => {
            logger_1.logger.info(`🔄 BRIDGE CONFIG: Switching relay port to ${data.port}...`);
            try {
                // Force re-initialization with the new port from UI
                await relay_service_1.RelayService.init(data.port);
            }
            catch (err) {
                logger_1.logger.error(`🚨 BRIDGE CONFIG ERROR: ${err.message}`);
            }
        });
        // Listen for license sync from Cloud to persist offline
        this.client.on('license:sync', async (data) => {
            if (data.isActivated && data.license) {
                logger_1.logger.info(`📡 BRIDGE LICENSE: Syncing activation to local DB.`);
                try {
                    const { prisma } = await Promise.resolve().then(() => __importStar(require('../../database/db')));
                    await prisma.license.upsert({
                        where: { hardwareId: data.machineId },
                        update: {
                            isActivated: true,
                            activatedAt: data.license.activatedAt,
                            expiresAt: data.license.expiresAt,
                            licenseKey: data.license.licenseKey,
                            isActive: data.license.isActive
                        },
                        create: {
                            hardwareId: data.machineId,
                            isActivated: true,
                            activatedAt: data.license.activatedAt,
                            expiresAt: data.license.expiresAt,
                            licenseKey: data.license.licenseKey,
                            isActive: data.license.isActive
                        }
                    });
                }
                catch (e) {
                    logger_1.logger.error(`🚨 BRIDGE LICENSE ERROR: ${e.message}`);
                }
            }
        });
    }
}
exports.BridgeService = BridgeService;
// Auto-init if enabled
if (process.env.ENABLE_BRIDGE === 'true') {
    BridgeService.init();
}
