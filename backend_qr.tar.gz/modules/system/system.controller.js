"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemController = void 0;
const system_service_1 = require("./system.service");
const backup_service_1 = require("../../utils/backup.service");
const sync_service_1 = require("./sync.service");
const print_service_1 = require("../print/print.service");
const db_1 = require("../../database/db");
class SystemController {
    static async exportBackup(req, res) {
        try {
            const data = await system_service_1.SystemService.exportDatabase();
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Content-Disposition', `attachment; filename=backup-vamos-${new Date().toISOString().slice(0, 10)}.json`);
            return res.json({ success: true, data });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async resetSystem(req, res) {
        try {
            const result = await system_service_1.SystemService.resetData();
            return res.json(result);
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async seedDefaults(req, res) {
        try {
            const result = await system_service_1.SystemService.seedDefaults();
            return res.json(result);
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async fixTables(req, res) {
        try {
            const result = await system_service_1.SystemService.fixStuckTables();
            return res.json(result);
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async testPrinter(req, res) {
        try {
            const venue = await db_1.prisma.venue.findFirst();
            const result = await print_service_1.PrintService.printReceipt({
                id: 'TEST-12345',
                tableAmount: 0,
                totalAmount: 100000,
                finalAmount: 100000,
                discount: 0,
                receivedAmount: 100000,
                method: 'CASH',
                paidAt: new Date(),
                table: { name: 'TEST MEJA' },
                member: { name: 'ADMIN VAMOS' },
                orders: [
                    { product: { name: 'Test Product 1' }, quantity: 1, total: 50000 },
                    { product: { name: 'Test Product 2' }, quantity: 1, total: 50000 }
                ],
                venue: venue
            });
            return res.json({ success: true, message: 'Test print sent' });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    /**
     * POST /api/system/backup
     * Trigger backup pg_dump manual — simpan ke folder backups/
     */
    static async runBackup(req, res) {
        try {
            const result = await backup_service_1.BackupService.runBackup();
            return res.status(result.success ? 200 : 500).json({
                success: result.success,
                file: result.file,
                message: result.message,
            });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    /**
     * GET /api/system/backup/list
     * Daftar semua file backup yang tersimpan di server
     */
    static async listBackups(req, res) {
        try {
            const backups = backup_service_1.BackupService.listBackups();
            return res.json({
                success: true,
                count: backups.length,
                backups,
            });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    /**
     * POST /api/system/backup/restore
     * Restore database dari file .sql
     */
    static async restoreBackup(req, res) {
        try {
            const { fileName } = req.body;
            if (!fileName) {
                return res.status(400).json({ success: false, message: 'fileName is required' });
            }
            const result = await backup_service_1.BackupService.restoreBackup(fileName);
            return res.status(result.success ? 200 : 500).json(result);
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    /**
     * POST /api/system/import
     * Restore database dari backup JSON payload
     */
    static async importDatabase(req, res) {
        try {
            const { backupData } = req.body;
            if (!backupData) {
                return res.status(400).json({ success: false, message: 'backupData is required' });
            }
            const result = await system_service_1.SystemService.importDatabase(backupData);
            return res.json(result);
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async syncNow(req, res) {
        try {
            const syncedCount = await sync_service_1.SyncService.syncPendingData();
            return res.json({ success: true, syncedCount });
        }
        catch (error) {
            const errMsg = error.response?.data?.message || error.message;
            return res.status(500).json({ success: false, message: `Sync Error: ${errMsg}` });
        }
    }
    static async getUnsyncedCount(req, res) {
        try {
            const count = await sync_service_1.SyncService.getUnsyncedCount();
            return res.json({ success: true, count });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
    static async receiveSyncPayload(req, res) {
        try {
            const actualSecret = process.env.SYNC_SECRET || 'sync_secret_key';
            const providedSecret = req.headers['x-sync-secret'];
            if (providedSecret !== actualSecret) {
                return res.status(401).json({ success: false, message: 'Invalid sync secret' });
            }
            const upsertedCount = await sync_service_1.SyncService.receiveSyncPayload(req.body);
            return res.json({ success: true, upsertedCount });
        }
        catch (error) {
            return res.status(500).json({ success: false, message: error.message });
        }
    }
}
exports.SystemController = SystemController;
