"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconnect = exports.blink = exports.scanPorts = exports.getStatus = exports.turnOff = exports.turnOn = void 0;
const relay_service_1 = require("./relay.service");
const audit_service_1 = require("../audit/audit.service");
const catchAsync_1 = require("../../utils/catchAsync");
exports.turnOn = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { channel } = req.body;
    const success = await relay_service_1.RelayService.sendCommand(channel, 'on');
    await audit_service_1.AuditService.log(req.user?.id, 'RELAY_ON', 'Table', { channel, success });
    res.json({ success, channel, command: 'on' });
});
exports.turnOff = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { channel } = req.body;
    const success = await relay_service_1.RelayService.sendCommand(channel, 'off');
    await audit_service_1.AuditService.log(req.user?.id, 'RELAY_OFF', 'Table', { channel, success });
    res.json({ success, channel, command: 'off' });
});
exports.getStatus = (0, catchAsync_1.catchAsync)(async (req, res) => {
    // Jika di VPS, prioritaskan status dari BRIDGE (Laptop/Kasir)
    // yang sudah tersimpan di memori socket.ts
    const isVPS = process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON;
    let status = relay_service_1.RelayService.getStatus();
    if (isVPS) {
        const { getLatestBridgeStatus } = await Promise.resolve().then(() => __importStar(require('../../socket')));
        const bridgeData = getLatestBridgeStatus();
        if (bridgeData) {
            status = { ...bridgeData, isBridge: true, isVPS: true };
        }
        else {
            // Jika belum ada bridge yang lapor, paksa OFFLINE (biar gak nampilin /dev/ttyS)
            status.isConnected = false;
            status.port = null;
        }
    }
    res.json({ success: true, data: status });
});
/**
 * GET /api/relay/scan
 * Daftar semua COM port yang terdeteksi di sistem — tanpa mengubah koneksi.
 */
exports.scanPorts = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const ports = await relay_service_1.RelayService.scanPorts();
    res.json({
        success: true,
        count: ports.length,
        ports,
    });
});
/**
 * POST /api/relay/reconnect
 * Putuskan koneksi lama, lalu jalankan auto-detect ulang ke semua COM port.
 * Hasil port yang berhasil otomatis disimpan ke database.
 */
/**
 * POST /api/relay/blink/:channel
 * Trigger blink mode pada relay tertentu (melalui VPS -> Bridge)
 */
exports.blink = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { channel } = req.params;
    await relay_service_1.RelayService.blink(parseInt(channel));
    res.json({ success: true, channel, command: 'blink' });
});
exports.reconnect = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const result = await relay_service_1.RelayService.reconnect();
    await audit_service_1.AuditService.log(req.user?.id, 'RELAY_RECONNECT', 'System', { result });
    res.json({ success: result.success, port: result.port, message: result.message });
});
