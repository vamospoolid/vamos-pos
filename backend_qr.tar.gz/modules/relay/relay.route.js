"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const relay_controller_1 = require("./relay.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
router.post('/on', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'KASIR', 'OWNER'), relay_controller_1.turnOn);
router.post('/off', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'KASIR', 'OWNER'), relay_controller_1.turnOff);
router.get('/status', auth_1.authenticate, relay_controller_1.getStatus);
// Maintenance endpoints — hanya ADMIN & OWNER
router.get('/scan', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER'), relay_controller_1.scanPorts);
router.post('/reconnect', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER'), relay_controller_1.reconnect);
router.post('/blink/:channel', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER'), relay_controller_1.blink);
router.post('/blink/:channel', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER'), relay_controller_1.blink);
exports.default = router;
