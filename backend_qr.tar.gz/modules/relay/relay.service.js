"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayService = void 0;
const serialport_1 = require("serialport");
const logger_1 = require("../../utils/logger");
const db_1 = require("../../database/db");
const eventBus_1 = require("../../utils/eventBus");
class RelayService {
    static port = null;
    static isConnected = false;
    static mockStates = {};
    static lastKnownPort = null;
    static isScanning = false;
    static lastError = null;
    static lock = false;
    static lockTime = 0;
    static queue = [];
    // ─────────────────────────────────────────────────────────────────────────
    // STATUS
    // ─────────────────────────────────────────────────────────────────────────
    static async notifyConfigUpdate(port) {
        try {
            const { getIO, getCloudSocket } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            const io = getIO();
            const cloudSocket = getCloudSocket();
            const status = this.getStatus();
            // 1. Broadcast to Local UI (Cashier)
            if (io) {
                io.emit('relay:config:update', { port });
                io.emit('bridge:hardware:status', { ...status, isBridge: true });
                logger_1.logger.info(`📡 [BRIDGE_CONFIG] Local broadcast port: ${port}`);
            }
            // 2. Sync to Cloud (VPS)
            if (cloudSocket && cloudSocket.connected) {
                cloudSocket.emit('bridge:status:update', status);
                logger_1.logger.info(`📡 [BRIDGE_CONFIG] Syncing port ${port} to Cloud...`);
            }
        }
        catch (e) { }
    }
    static getStatus() {
        const { getHardwareId } = require('../../utils/hardware.utils');
        return {
            isConnected: this.isConnected,
            port: this.port ? this.port.path : (this.lastKnownPort || null),
            isOpen: this.port ? this.port.isOpen : false,
            lastKnownPort: this.lastKnownPort,
            isScanning: this.isScanning,
            lastError: this.lastError,
            isVPS: process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON,
            hardwareId: getHardwareId() // Get Local HWID
        };
    }
    // ─────────────────────────────────────────────────────────────────────────
    // SCAN & AUTO-DETECT
    // ─────────────────────────────────────────────────────────────────────────
    static async scanPorts() {
        try {
            const scanPromise = serialport_1.SerialPort.list();
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Scan timeout')), 5000));
            const ports = await Promise.race([scanPromise, timeoutPromise]);
            return ports;
        }
        catch (err) {
            logger_1.logger.error(`⚠️ [SERIAL_SCAN] Error or Timeout: ${err.message}`);
            return [];
        }
    }
    static async autoDetectPort(preferredPort) {
        if (this.isScanning)
            return null;
        this.isScanning = true;
        try {
            const allPorts = await this.scanPorts();
            // 1. Filter only CH340-like ports which are common for our relay (VendorId: 1a86, ProductId: 7523)
            // But we keep others as fallback if CH340 filter is too strict.
            const ch340Paths = allPorts
                .filter(p => p.vendorId?.toLowerCase() === '1a86' || p.manufacturer?.toLowerCase().includes('wch'))
                .map(p => p.path);
            const otherPaths = allPorts
                .filter(p => !ch340Paths.includes(p.path))
                .map(p => p.path)
                .filter(p => !['COM1', 'COM2'].includes(p.toUpperCase()));
            const orderedPaths = [];
            // Priority 1: Preferred port (if it exists)
            if (preferredPort && [...ch340Paths, ...otherPaths].includes(preferredPort)) {
                orderedPaths.push(preferredPort);
            }
            // Priority 2: CH340 ports (The most likely ones)
            ch340Paths.forEach(p => { if (!orderedPaths.includes(p))
                orderedPaths.push(p); });
            // Priority 3: COM3/COM4 (Common fallbacks)
            ['COM3', 'COM4'].forEach(p => {
                if (otherPaths.includes(p) && !orderedPaths.includes(p))
                    orderedPaths.push(p);
            });
            // Priority 4: All other available ports
            otherPaths.forEach(p => { if (!orderedPaths.includes(p))
                orderedPaths.push(p); });
            for (const portPath of orderedPaths) {
                const isCH340 = ch340Paths.includes(portPath);
                logger_1.logger.info(`🔍 [AUTO-SCAN] Testing port: ${portPath} ${isCH340 ? '(CH340 Match)' : ''}`);
                const success = await this.tryOpenPort(portPath);
                if (success) {
                    this.lastKnownPort = portPath;
                    this.notifyConfigUpdate(portPath); // Tell Cloud we found a working port!
                    try {
                        await db_1.prisma.venue.updateMany({ data: { relayComPort: portPath } });
                        logger_1.logger.info(`✅ [AUTO-SCAN] Port found and saved: ${portPath}`);
                    }
                    catch (e) { }
                    return portPath;
                }
            }
            return null;
        }
        finally {
            this.isScanning = false;
        }
    }
    static tryOpenPort(portPath) {
        return new Promise((resolve) => {
            let testPort;
            try {
                testPort = new serialport_1.SerialPort({ path: portPath, baudRate: 9600, autoOpen: false });
                const timeout = setTimeout(() => {
                    if (testPort.isOpen)
                        testPort.close();
                    resolve(false);
                }, 1000);
                testPort.open((err) => {
                    clearTimeout(timeout);
                    if (err)
                        resolve(false);
                    else {
                        testPort.close(() => resolve(true));
                    }
                });
            }
            catch (e) {
                resolve(false);
            }
        });
    }
    // ─────────────────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────────────────
    static async init(forceComPort) {
        const self = this;
        if (self.port) {
            if (forceComPort && self.port.path !== forceComPort) {
                await new Promise(res => self.port.close(() => res()));
                self.port = null;
            }
            else
                return;
        }
        if (process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON) {
            logger_1.logger.info('☁️ VPS Mode: Serial port disabled.');
            self.isConnected = false;
            return;
        }
        let comPortPath = forceComPort;
        if (!comPortPath) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                comPortPath = process.env.RELAY_COM_PORT || venue?.relayComPort;
            }
            catch (e) {
                comPortPath = process.env.RELAY_COM_PORT;
            }
        }
        // If explicitly set to AUTO or empty, run auto-detection
        if (!comPortPath || comPortPath.toUpperCase() === 'AUTO') {
            logger_1.logger.info('🔍 [RELAY_INIT] Port set to AUTO. Scanning system...');
            const found = await this.autoDetectPort();
            if (found) {
                this.init(found);
                return;
            }
            else {
                logger_1.logger.error('❌ [RELAY_INIT] Auto-detection found no suitable ports.');
                // Fallback to COM3 if everything fails
                comPortPath = 'COM3';
            }
        }
        try {
            logger_1.logger.info(`🔌 [RELAY_INIT] Attempting to open: ${comPortPath}...`);
            self.port = new serialport_1.SerialPort({
                path: comPortPath,
                baudRate: 9600,
                autoOpen: false,
                lock: false // Allow other processes to potentially see it if needed, though usually true is better.
            });
            self.port.open((err) => {
                if (err) {
                    logger_1.logger.error(`❌ HARDWARE ERROR: ${comPortPath} - ${err.message}`);
                    self.lastError = err.message;
                    self.updateConnectionStatus(false);
                    // If we failed to open the explicitly set port, try AUTO as fallback
                    logger_1.logger.info(`🔍 [RELAY_INIT] Falling back to Auto-Detection...`);
                    this.autoDetectPort(comPortPath).then(found => {
                        if (found && found !== comPortPath) {
                            logger_1.logger.info(`✨ [RELAY_INIT] Auto-detected working port: ${found}`);
                            this.init(found);
                        }
                        else {
                            logger_1.logger.error(`💀 [RELAY_INIT] Auto-detection failed or found same port. No valid relay found.`);
                            // Retry after delay
                            setTimeout(() => this.init(), 10000);
                        }
                    });
                }
                else {
                    logger_1.logger.info(`✅ HARDWARE SUCCESS: ${comPortPath} is now OPEN.`);
                    self.updateConnectionStatus(true);
                    self.lastKnownPort = comPortPath;
                    self.lastError = null;
                }
            });
            self.port.on('close', () => {
                logger_1.logger.warn(`🔌 [RELAY] Port closed unexpectedly: ${comPortPath}`);
                self.updateConnectionStatus(false);
                self.port = null; // Clear reference
                setTimeout(() => this.init(), 5000);
            });
            self.port.on('error', (err) => {
                logger_1.logger.error(`🔌 [RELAY] Port Error: ${err.message}`);
                self.updateConnectionStatus(false);
            });
        }
        catch (e) {
            self.updateConnectionStatus(false);
        }
        for (let i = 1; i <= 20; i++) {
            if (self.mockStates[i] === undefined)
                self.mockStates[i] = false;
        }
        // Sync mockStates with current table status from DB
        try {
            const tables = await db_1.prisma.table.findMany({ where: { status: 'PLAYING' } });
            for (const t of tables) {
                if (t.relayChannel)
                    self.mockStates[t.relayChannel] = true;
            }
        }
        catch (e) { }
    }
    static async reconnect() {
        if (this.port)
            await new Promise(res => this.port.close(() => res()));
        this.port = null;
        const found = await this.autoDetectPort();
        await this.init(found || undefined);
        const status = this.getStatus();
        return { success: status.isConnected, port: status.port, message: status.isConnected ? 'Reconnected' : 'Failed' };
    }
    // ─────────────────────────────────────────────────────────────────────────
    // COMMANDS
    // ─────────────────────────────────────────────────────────────────────────
    static async sendCommand(channel, status) {
        const command = status === 'on' ? 'on' : 'off';
        const self = this;
        // 1. Enforce License for hardware control (Local Bridge only)
        if (process.env.IS_LOCAL_ELECTRON && status === 'on') {
            try {
                const { LicenseService } = await Promise.resolve().then(() => __importStar(require('../license/license.service')));
                const ls = new LicenseService();
                const isActivated = await ls.verify();
                if (!isActivated) {
                    logger_1.logger.error(`🚨 [RELAY] UNAUTHORIZED: License missing or expired. Command ignored.`);
                    return false;
                }
            }
            catch (err) {
                // If license check errors out, default to allowed but log it?
                // Actually, safer to block it if logic fails.
                logger_1.logger.error(`🚨 [RELAY] LICENSE CHECK FAILED: ${err.message}`);
                return false;
            }
        }
        logger_1.logger.info(`📡 RELAY: Meja ${channel} → ${command.toUpperCase()}`);
        this.mockStates[channel] = status === 'on';
        try {
            const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            const io = getIO();
            if (io)
                io.emit('relay:command', { channel, status: command });
        }
        catch (e) { }
        if (!process.env.IS_LOCAL_ELECTRON)
            return true;
        this.burstAsync(channel, status === 'on').catch(() => { });
        return true;
    }
    static async notifyBlink(channel) {
        try {
            const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            const io = getIO();
            if (io)
                io.emit('relay:blink', { channel });
        }
        catch (e) { }
    }
    static async burstAsync(channel, isOn) {
        const self = this;
        if (this.lock) {
            this.queue.push({ channel, command: isOn ? 'on' : 'off' });
            return;
        }
        this.lock = true;
        this.lockTime = Date.now();
        const delay = (ms) => new Promise(r => setTimeout(r, ms));
        const writeRaw = (data) => {
            return new Promise((resolve) => {
                const sendNow = () => {
                    if (!self.port || !self.port.isOpen) {
                        resolve();
                        return;
                    }
                    self.port.write(data, (err) => {
                        if (err)
                            logger_1.logger.error(`[RELAY] Write Error: ${err.message}`);
                        setTimeout(resolve, 50);
                    });
                };
                if (!self.port || !self.port.isOpen) {
                    this.init().then(() => {
                        setTimeout(sendNow, 500); // Tunggu port stabil setelah OPEN
                    });
                    return;
                }
                sendNow();
            });
        };
        try {
            const cmd = `${channel}${isOn ? '1' : '0'}\r\n`;
            await writeRaw(cmd);
            await delay(100);
            await writeRaw(cmd);
            // Extra safety for OFF command
            if (!isOn) {
                await delay(200);
                await writeRaw(cmd);
            }
        }
        catch (e) { }
        finally {
            this.lock = false;
            const next = this.queue.shift();
            if (next)
                setTimeout(() => this.burstAsync(next.channel, next.command === 'on'), 100);
        }
    }
    static async blink(channel) {
        this.notifyBlink(channel); // Broadcast to UI/Cloud
        if (!process.env.IS_LOCAL_ELECTRON)
            return;
        const originalState = this.mockStates[channel];
        try {
            // Blink Cycle 1
            await this.burstAsync(channel, false);
            await new Promise(r => setTimeout(r, 500));
            await this.burstAsync(channel, true);
            await new Promise(r => setTimeout(r, 500));
            // Blink Cycle 2
            await this.burstAsync(channel, false);
            await new Promise(r => setTimeout(r, 500));
            await this.burstAsync(channel, originalState);
        }
        catch (e) { }
    }
    static async updateConnectionStatus(status) {
        if (this.isConnected !== status) {
            this.isConnected = status;
            eventBus_1.eventBus.emit('hardware:status', status);
            logger_1.logger.info(`📡 [RELAY] Status: ${status ? 'ONLINE' : 'OFFLINE'}`);
        }
    }
}
exports.RelayService = RelayService;
RelayService.init();
