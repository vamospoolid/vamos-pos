"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryController = exports.InventoryController = void 0;
const inventory_service_1 = require("./inventory.service");
class InventoryController {
    async getRawMaterials(req, res) {
        try {
            const data = await inventory_service_1.inventoryService.getRawMaterials();
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
    async getRawMaterialById(req, res) {
        try {
            const data = await inventory_service_1.inventoryService.getRawMaterialById(req.params.id);
            if (!data)
                return res.status(404).json({ error: 'Not found' });
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
    async createRawMaterial(req, res) {
        try {
            const { name, unit, currentStock, costPerUnit, minStockAlert } = req.body;
            const data = await inventory_service_1.inventoryService.createRawMaterial({
                name,
                unit: unit,
                currentStock: Number(currentStock),
                costPerUnit: Number(costPerUnit),
                minStockAlert: Number(minStockAlert)
            });
            res.json(data);
        }
        catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
    async updateRawMaterial(req, res) {
        try {
            const { name, unit, costPerUnit, minStockAlert } = req.body;
            const data = await inventory_service_1.inventoryService.updateRawMaterial(req.params.id, {
                name,
                unit: unit,
                costPerUnit: costPerUnit !== undefined ? Number(costPerUnit) : undefined,
                minStockAlert: minStockAlert !== undefined ? Number(minStockAlert) : undefined
            });
            res.json(data);
        }
        catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
    async deleteRawMaterial(req, res) {
        try {
            await inventory_service_1.inventoryService.deleteRawMaterial(req.params.id);
            res.json({ success: true });
        }
        catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
    async adjustStock(req, res) {
        try {
            const { newStock, notes } = req.body;
            const data = await inventory_service_1.inventoryService.adjustStock(req.params.id, Number(newStock), notes);
            res.json(data);
        }
        catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
    async getRecipe(req, res) {
        try {
            const data = await inventory_service_1.inventoryService.getRecipeByProductId(req.params.productId);
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
    async saveRecipe(req, res) {
        try {
            const { ingredients } = req.body;
            const data = await inventory_service_1.inventoryService.saveRecipe(req.params.productId, ingredients);
            res.json(data);
        }
        catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
}
exports.InventoryController = InventoryController;
exports.inventoryController = new InventoryController();
