"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
class AuthService {
    static async login(email, password) {
        const user = await db_1.prisma.user.findUnique({ where: { email } });
        if (!user)
            throw new errors_1.AppError('Invalid credentials', 400);
        const isMatch = await bcrypt_1.default.compare(password, user.password);
        if (!isMatch)
            throw new errors_1.AppError('Invalid credentials', 400);
        const token = jsonwebtoken_1.default.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'secret', { expiresIn: (process.env.JWT_EXPIRES_IN || '1d') });
        return { user, token };
    }
}
exports.AuthService = AuthService;
