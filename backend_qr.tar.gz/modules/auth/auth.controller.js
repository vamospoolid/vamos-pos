"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.login = void 0;
const auth_service_1 = require("./auth.service");
const catchAsync_1 = require("../../utils/catchAsync");
const zod_1 = require("zod");
const loginSchema = zod_1.z.object({
    email: zod_1.z.string().email(),
    password: zod_1.z.string().min(6),
});
exports.login = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { email, password } = loginSchema.parse(req.body);
    const result = await auth_service_1.AuthService.login(email, password);
    res.json(result);
});
