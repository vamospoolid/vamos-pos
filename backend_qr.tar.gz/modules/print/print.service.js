"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintService = void 0;
const node_thermal_printer_1 = require("node-thermal-printer");
const logger_1 = require("../../utils/logger");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
class PrintService {
    static async printReceipt(data) {
        try {
            const printerInterface = data.venue?.printerPath || 'RP58 Printer';
            logger_1.logger.info(`🔍 [PRINT_DEBUG] Menyiapkan printer: ${printerInterface}`);
            const width = data.venue?.printerWidth || 32;
            const printer = new node_thermal_printer_1.ThermalPrinter({
                type: node_thermal_printer_1.PrinterTypes.EPSON,
                interface: printerInterface, // No 'printer:' prefix to avoid driver error
                characterSet: node_thermal_printer_1.CharacterSet.PC437_USA,
                removeSpecialCharacters: false,
                lineCharacter: "=",
                width: width,
            });
            // Note: We skip isPrinterConnected() because we use Windows Shared Printer bypassing driver checks
            // const isConnected = await printer.isPrinterConnected();
            // if (!isConnected) {
            //     logger.error(`❌ [PRINT_DEBUG] Printer "${printerInterface}" TIDAK ditemukan. Silakan cek kabel atau penulisan nama printer di Settings.`);
            //     return { success: false, message: 'Printer not connected' };
            // }
            logger_1.logger.info(`✅ [PRINT_DEBUG] Menyiapkan data struk untuk: ${printerInterface}...`);
            // --- START PRINTING ---
            // Set tighter line spacing (most 58mm thermal printers support this)
            // 30 is usually the tightest readable
            // printer.setLineSpacing(30); 
            printer.alignCenter();
            printer.setTextNormal();
            printer.println(data.venue?.name?.toUpperCase() || 'VAMOS POOL & CAFE');
            printer.println(data.venue?.address || 'Billiard & Cafe');
            printer.println("-".repeat(width));
            printer.alignLeft();
            const dateStr = new Date(data.paidAt || Date.now()).toLocaleString('id-ID', {
                day: '2-digit', month: '2-digit', year: '2-digit',
                hour: '2-digit', minute: '2-digit'
            });
            printer.println(`TGL: ${dateStr}`);
            printer.println(`BIL: #${(data.id || '').substring(0, 6).toUpperCase()} | MEJA: ${data.table?.name || '-'}`);
            if (data.member?.name)
                printer.println(`MEM: ${data.member.name.toUpperCase()}`);
            printer.println("-".repeat(width));
            // Session
            if (data.tableAmount > 0) {
                const mins = data.totalMinutes || 0;
                const hrs = Math.floor(mins / 60);
                const rem = mins % 60;
                printer.println(`Billiard (${hrs}h ${rem}m)`);
                printer.alignRight();
                printer.println(`Rp ${data.tableAmount.toLocaleString()}`);
                printer.alignLeft();
            }
            // Orders
            if (data.orders && data.orders.length > 0) {
                data.orders.forEach((o) => {
                    const name = o.product?.name || 'Item';
                    printer.println(`${name} x${o.quantity}`);
                    printer.alignRight();
                    printer.println(`Rp ${(o.total || 0).toLocaleString()}`);
                    printer.alignLeft();
                });
            }
            printer.println("-".repeat(width));
            // Totals
            printer.tableCustom([
                { text: "SUBTOTAL", align: "LEFT", width: 0.5 },
                { text: `Rp ${(data.totalAmount || data.finalAmount || 0).toLocaleString()}`, align: "RIGHT", width: 0.5 }
            ]);
            if (data.discount > 0) {
                printer.tableCustom([
                    { text: "DISCOUNT", align: "LEFT", width: 0.5 },
                    { text: `-Rp ${data.discount.toLocaleString()}`, align: "RIGHT", width: 0.5 }
                ]);
            }
            printer.drawLine();
            printer.tableCustom([
                { text: "TOTAL", align: "LEFT", width: 0.4 },
                { text: `Rp ${(data.finalAmount || 0).toLocaleString()}`, align: "RIGHT", width: 0.6 }
            ]);
            printer.println("-".repeat(width));
            // Payment Detail
            const change = Math.max(0, (data.receivedAmount || 0) - (data.finalAmount || 0));
            printer.println(`BAYAR  : ${data.method || 'CASH'}`);
            if (data.receivedAmount > 0) {
                printer.println(`TUNAI  : Rp ${data.receivedAmount.toLocaleString()}`);
                printer.println(`KEMBALI: Rp ${change.toLocaleString()}`);
            }
            printer.println("-".repeat(width));
            printer.alignCenter();
            if (data.member && data.member.id) {
                const pts = data.member.loyaltyPoints || 0;
                printer.println(`TOTAL POIN ANDA: ${pts} PTS`);
                printer.println(`Tukarkan poin dengan hadiah!`);
            }
            else {
                printer.println("JUMLAH POIN ANDA: 0");
                printer.println("Daftar Member Vamos (GRATIS)");
                printer.println("untuk kumpulkan poin hadiah!");
            }
            printer.println("-".repeat(width));
            printer.println("TERIMA KASIH!");
            printer.println("app.vamospool.id");
            // Cut and Feed
            printer.cut();
            const buffer = printer.getBuffer();
            const tempFile = path_1.default.join(process.cwd(), 'receipt.bin');
            const { execSync } = await Promise.resolve().then(() => __importStar(require('child_process')));
            fs_1.default.writeFileSync(tempFile, buffer);
            const shareName = data.venue?.printerPath === 'RP58 Printer' ? 'RP58' : data.venue?.printerPath;
            const computerName = process.env.COMPUTERNAME || '127.0.0.1';
            const pathsToTry = [
                `\\\\127.0.0.1\\${shareName}`,
                `\\\\localhost\\${shareName}`,
                `\\\\${computerName}\\${shareName}`
            ];
            let success = false;
            let lastError = '';
            for (const networkPath of pathsToTry) {
                try {
                    logger_1.logger.info(`✅ [PRINT_DEBUG] Mencoba jalur print: ${networkPath}...`);
                    execSync(`copy /b "${tempFile}" "${networkPath}"`, { stdio: 'pipe' });
                    logger_1.logger.info(`✨ [PRINT_DEBUG] Sukses! Kertas keluar via ${networkPath}`);
                    success = true;
                    break;
                }
                catch (cmdErr) {
                    lastError = cmdErr.message || String(cmdErr);
                    logger_1.logger.warn(`⚠️ Gagal mencoba ${networkPath}`);
                }
            }
            if (fs_1.default.existsSync(tempFile))
                fs_1.default.unlinkSync(tempFile);
            if (success) {
                return { success: true };
            }
            else {
                logger_1.logger.error(`❌ [PRINT_DEBUG] Semua jalur print mati. Error terakhir: ${lastError}`);
                throw new Error(`Gagal cetak ke jaringan. Pastikan printer Share Name adalah '${shareName}' dan 'File and Printer Sharing' aktif di Windows.`);
            }
        }
        catch (error) {
            logger_1.logger.error(`❌ [PRINT_DEBUG] Gagal total: ${error.message}`);
            throw error;
        }
    }
}
exports.PrintService = PrintService;
