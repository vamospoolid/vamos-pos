"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscountService = void 0;
const db_1 = require("../../database/db");
class DiscountService {
    static async create(data) {
        return db_1.prisma.discountCategory.create({ data });
    }
    static async getAll() {
        return db_1.prisma.discountCategory.findMany({
            where: { deletedAt: null },
            orderBy: { name: 'asc' }
        });
    }
    static async update(id, data) {
        return db_1.prisma.discountCategory.update({
            where: { id },
            data
        });
    }
    static async delete(id) {
        return db_1.prisma.discountCategory.update({
            where: { id },
            data: { deletedAt: new Date(), isActive: false }
        });
    }
}
exports.DiscountService = DiscountService;
