"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscountController = void 0;
const discount_service_1 = require("./discount.service");
class DiscountController {
    static async create(req, res, next) {
        try {
            const result = await discount_service_1.DiscountService.create(req.body);
            res.status(201).json({ success: true, data: result });
        }
        catch (error) {
            next(error);
        }
    }
    static async getAll(req, res, next) {
        try {
            const results = await discount_service_1.DiscountService.getAll();
            res.json({ success: true, data: results });
        }
        catch (error) {
            next(error);
        }
    }
    static async update(req, res, next) {
        try {
            const result = await discount_service_1.DiscountService.update(req.params.id, req.body);
            res.json({ success: true, data: result });
        }
        catch (error) {
            next(error);
        }
    }
    static async delete(req, res, next) {
        try {
            await discount_service_1.DiscountService.delete(req.params.id);
            res.json({ success: true, message: 'Discount category deleted' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.DiscountController = DiscountController;
