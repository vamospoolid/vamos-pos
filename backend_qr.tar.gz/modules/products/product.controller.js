"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductController = void 0;
const product_service_1 = require("./product.service");
class ProductController {
    static async createProduct(req, res, next) {
        try {
            const product = await product_service_1.ProductService.createProduct(req.body);
            res.status(201).json({ success: true, data: product });
        }
        catch (error) {
            next(error);
        }
    }
    static async getProducts(req, res, next) {
        try {
            const category = req.query.category;
            const products = await product_service_1.ProductService.getProducts(category);
            res.json({ success: true, data: products });
        }
        catch (error) {
            next(error);
        }
    }
    static async getProductById(req, res, next) {
        try {
            const product = await product_service_1.ProductService.getProductById(req.params.id);
            res.json({ success: true, data: product });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateProduct(req, res, next) {
        try {
            const product = await product_service_1.ProductService.updateProduct(req.params.id, req.body);
            res.json({ success: true, data: product });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateStock(req, res, next) {
        try {
            const stockChange = parseInt(req.body.stockChange);
            if (isNaN(stockChange)) {
                return res.status(400).json({ success: false, message: 'Invalid stock change value' });
            }
            const product = await product_service_1.ProductService.updateStock(req.params.id, stockChange);
            res.json({ success: true, data: product });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteProduct(req, res, next) {
        try {
            await product_service_1.ProductService.deleteProduct(req.params.id);
            res.json({ success: true, message: 'Product deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
    static async getStockLogs(req, res, next) {
        try {
            const productId = req.query.productId;
            const logs = await product_service_1.ProductService.getStockLogs(productId);
            res.json({ success: true, data: logs });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.ProductController = ProductController;
