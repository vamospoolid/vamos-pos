"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PricingController = void 0;
const pricing_service_1 = require("./pricing.service");
class PricingController {
    // Pricing Rules
    static async createPricingRule(req, res, next) {
        try {
            const rule = await pricing_service_1.PricingService.createPricingRule(req.body);
            res.status(201).json({ success: true, data: rule });
        }
        catch (error) {
            next(error);
        }
    }
    static async getPricingRules(req, res, next) {
        try {
            const rules = await pricing_service_1.PricingService.getPricingRules();
            res.json({ success: true, data: rules });
        }
        catch (error) {
            next(error);
        }
    }
    static async updatePricingRule(req, res, next) {
        try {
            const rule = await pricing_service_1.PricingService.updatePricingRule(req.params.id, req.body);
            res.json({ success: true, data: rule });
        }
        catch (error) {
            next(error);
        }
    }
    static async deletePricingRule(req, res, next) {
        try {
            await pricing_service_1.PricingService.deletePricingRule(req.params.id);
            res.json({ success: true, message: 'Pricing rule deleted' });
        }
        catch (error) {
            next(error);
        }
    }
    // Packages
    static async createPackage(req, res, next) {
        try {
            const pkg = await pricing_service_1.PricingService.createPackage(req.body);
            res.status(201).json({ success: true, data: pkg });
        }
        catch (error) {
            next(error);
        }
    }
    static async getPackages(req, res, next) {
        try {
            const pkgs = await pricing_service_1.PricingService.getPackages();
            res.json({ success: true, data: pkgs });
        }
        catch (error) {
            next(error);
        }
    }
    static async updatePackage(req, res, next) {
        try {
            const pkg = await pricing_service_1.PricingService.updatePackage(req.params.id, req.body);
            res.json({ success: true, data: pkg });
        }
        catch (error) {
            next(error);
        }
    }
    static async deletePackage(req, res, next) {
        try {
            await pricing_service_1.PricingService.deletePackage(req.params.id);
            res.json({ success: true, message: 'Package deleted' });
        }
        catch (error) {
            next(error);
        }
    }
    static async estimate(req, res, next) {
        try {
            const { tableType, durationMinutes, isMember, startTime } = req.query;
            const estimate = await pricing_service_1.PricingService.estimatePrice(tableType, parseInt(durationMinutes), isMember === 'true', startTime ? new Date(startTime) : new Date());
            res.json({ success: true, data: estimate });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.PricingController = PricingController;
