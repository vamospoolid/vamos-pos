"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const pricing_controller_1 = require("./pricing.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
// Pricing Rules
router.post('/rules', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.createPricingRule);
router.get('/rules', auth_1.authenticate, pricing_controller_1.PricingController.getPricingRules);
router.put('/rules/:id', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.updatePricingRule);
router.delete('/rules/:id', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.deletePricingRule);
// Packages
router.post('/packages', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.createPackage);
router.get('/packages', auth_1.authenticate, pricing_controller_1.PricingController.getPackages);
router.put('/packages/:id', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.updatePackage);
router.delete('/packages/:id', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), pricing_controller_1.PricingController.deletePackage);
// Estimate
router.get('/estimate', auth_1.authenticate, pricing_controller_1.PricingController.estimate);
exports.default = router;
