"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../../middleware/auth");
const loyalty_controller_1 = require("./loyalty.controller");
const router = (0, express_1.Router)();
// ── Public / Member endpoints (authenticated) ─────────────────────
router.use(auth_1.authenticate);
router.get('/rewards', loyalty_controller_1.getRewards); // list active rewards
router.get('/leaderboard', loyalty_controller_1.getLeaderboard); // top 10 members
router.get('/member/:id', loyalty_controller_1.getMemberLoyalty); // full profile + logs
router.get('/member/:id/points', loyalty_controller_1.getMemberPoints); // quick point check
router.post('/redeem', loyalty_controller_1.redeemReward); // redeem a reward
// ── Admin endpoints ────────────────────────────────────────────────
router.use((0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER'));
router.get('/config', loyalty_controller_1.getLoyaltyConfig);
router.patch('/config', loyalty_controller_1.updateLoyaltyConfig);
router.patch('/admin/double-point-toggle', loyalty_controller_1.toggleDoublePoint);
router.post('/admin/award-points', loyalty_controller_1.awardPointsManual);
router.get('/admin/report', loyalty_controller_1.getMonthlyReport);
router.get('/admin/redemptions', loyalty_controller_1.getRedemptions);
router.get('/admin/redemptions/pending-count', loyalty_controller_1.getPendingRedemptionCount);
router.get('/admin/logs', loyalty_controller_1.getPointLogs);
router.post('/admin/run-expiry', loyalty_controller_1.runPointExpiry);
router.patch('/admin/redemptions/:id', loyalty_controller_1.updateRedemptionStatus);
// Reward management
router.post('/rewards', loyalty_controller_1.createReward);
router.patch('/rewards/:id', loyalty_controller_1.updateReward);
router.delete('/rewards/:id', loyalty_controller_1.deleteReward);
exports.default = router;
