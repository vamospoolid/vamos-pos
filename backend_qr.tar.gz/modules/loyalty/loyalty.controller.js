"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.runPointExpiry = exports.getPendingRedemptionCount = exports.updateRedemptionStatus = exports.getPointLogs = exports.getRedemptions = exports.awardPointsManual = exports.getMonthlyReport = exports.getLeaderboard = exports.updateLoyaltyConfig = exports.getLoyaltyConfig = exports.toggleDoublePoint = exports.deleteReward = exports.updateReward = exports.createReward = exports.getRewards = exports.redeemReward = exports.getMemberPoints = exports.getMemberLoyalty = void 0;
const loyalty_service_1 = require("./loyalty.service");
const catchAsync_1 = require("../../utils/catchAsync");
const db_1 = require("../../database/db");
// ── Member ────────────────────────────────────────────────────────
exports.getMemberLoyalty = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const result = await loyalty_service_1.LoyaltyService.getMemberLoyalty(req.params.id);
    res.json({ success: true, data: result });
});
exports.getMemberPoints = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const member = await db_1.prisma.member.findUnique({
        where: { id: req.params.id },
        select: { id: true, name: true, loyaltyPoints: true, tier: true, streakCount: true }
    });
    if (!member)
        return res.status(404).json({ success: false, message: 'Member tidak ditemukan' });
    res.json({ success: true, data: member });
});
// ── Redeem ────────────────────────────────────────────────────────
exports.redeemReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId, rewardId } = req.body;
    if (!memberId || !rewardId)
        return res.status(400).json({ success: false, message: 'memberId dan rewardId wajib diisi' });
    const result = await loyalty_service_1.LoyaltyService.redeem(memberId, rewardId);
    res.json({ success: true, data: result, message: 'Reward berhasil ditukar!' });
});
// ── Rewards CRUD ─────────────────────────────────────────────────
exports.getRewards = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const onlyActive = req.query.active !== 'false';
    const rewards = await db_1.prisma.reward.findMany({
        where: onlyActive ? { isActive: true } : {},
        orderBy: { pointsRequired: 'asc' },
    });
    res.json({ success: true, data: rewards });
});
exports.createReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { title, description, pointsRequired, rewardType, value, stock, imageUrl } = req.body;
    const reward = await db_1.prisma.reward.create({
        data: { title, description, pointsRequired: Number(pointsRequired), rewardType: rewardType || 'DISCOUNT', value: Number(value || 0), stock: Number(stock ?? 999), imageUrl }
    });
    res.status(201).json({ success: true, data: reward });
});
exports.updateReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const reward = await db_1.prisma.reward.update({
        where: { id: req.params.id },
        data: req.body,
    });
    res.json({ success: true, data: reward });
});
exports.deleteReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    await db_1.prisma.reward.update({ where: { id: req.params.id }, data: { isActive: false } });
    res.json({ success: true, message: 'Reward dinonaktifkan' });
});
// ── Admin Panel ───────────────────────────────────────────────────
exports.toggleDoublePoint = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { enabled, expiryHours } = req.body;
    const adminId = req.user?.id;
    const cfg = await loyalty_service_1.LoyaltyService.toggleDoublePoint(!!enabled, expiryHours, adminId);
    res.json({ success: true, data: cfg, message: enabled ? `Double point aktif${expiryHours ? ` selama ${expiryHours} jam` : ''}` : 'Double point dinonaktifkan' });
});
exports.getLoyaltyConfig = (0, catchAsync_1.catchAsync)(async (_req, res) => {
    const cfg = await loyalty_service_1.LoyaltyService.getConfig();
    res.json({ success: true, data: cfg });
});
exports.updateLoyaltyConfig = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const adminId = req.user?.id;
    const cfg = await loyalty_service_1.LoyaltyService.updateConfig(req.body, adminId);
    res.json({ success: true, data: cfg });
});
exports.getLeaderboard = (0, catchAsync_1.catchAsync)(async (_req, res) => {
    const data = await loyalty_service_1.LoyaltyService.getLeaderboard();
    res.json({ success: true, data });
});
exports.getMonthlyReport = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const now = new Date();
    const year = parseInt(req.query.year) || now.getFullYear();
    const month = parseInt(req.query.month) || (now.getMonth() + 1);
    const data = await loyalty_service_1.LoyaltyService.getMonthlyReport(year, month);
    res.json({ success: true, data });
});
// ── Manual point adjustment (admin) ──────────────────────────────
exports.awardPointsManual = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId, points, description } = req.body;
    if (!memberId || !points)
        return res.status(400).json({ success: false, message: 'memberId dan points wajib diisi' });
    // Use internal method via a thin re-export
    const { prisma: db } = await Promise.resolve().then(() => __importStar(require('../../database/db')));
    const member = await db.member.findUnique({ where: { id: memberId } });
    if (!member)
        return res.status(404).json({ success: false, message: 'Member tidak ditemukan' });
    const newPoints = Math.max(0, member.loyaltyPoints + Number(points));
    const tier = newPoints >= 1500 ? 'PLATINUM' : newPoints >= 500 ? 'GOLD' : 'SILVER';
    await db.$transaction([
        db.member.update({ where: { id: memberId }, data: { loyaltyPoints: newPoints, tier } }),
        db.pointLog.create({ data: { memberId, type: 'ADJUSTMENT', points: Number(points), description: description || 'Penyesuaian poin oleh admin' } }),
    ]);
    res.json({ success: true, message: `Poin ${points > 0 ? 'ditambah' : 'dikurangi'} ${Math.abs(points)}`, data: { loyaltyPoints: newPoints, tier } });
});
// ── Get redemption list (admin) ────────────────────────────────────
exports.getRedemptions = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const status = req.query.status;
    const redemptions = await db_1.prisma.redemption.findMany({
        where: status ? { status } : {},
        include: { member: { select: { id: true, name: true, phone: true } }, reward: true },
        orderBy: { claimedAt: 'desc' },
        take: 50,
    });
    res.json({ success: true, data: redemptions });
});
exports.getPointLogs = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const logs = await db_1.prisma.pointLog.findMany({
        include: { member: { select: { id: true, name: true, tier: true } } },
        orderBy: { createdAt: 'desc' },
        take: 100,
    });
    res.json({ success: true, data: logs });
});
exports.updateRedemptionStatus = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const redemption = await db_1.prisma.redemption.update({
        where: { id: req.params.id },
        data: { status: req.body.status, notes: req.body.notes },
    });
    const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
    const io = getIO();
    if (io) {
        io.emit('redemptions:updated');
    }
    res.json({ success: true, data: redemption });
});
exports.getPendingRedemptionCount = (0, catchAsync_1.catchAsync)(async (_req, res) => {
    const count = await db_1.prisma.redemption.count({
        where: { status: 'PENDING' }
    });
    res.json({ success: true, count });
});
exports.runPointExpiry = (0, catchAsync_1.catchAsync)(async (_req, res) => {
    const count = await loyalty_service_1.LoyaltyService.processAllExpiry();
    res.json({ success: true, message: `Berhasil memproses kadaluarsa poin untuk ${count} member.` });
});
