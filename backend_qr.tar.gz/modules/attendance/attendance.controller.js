"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttendanceController = void 0;
const attendance_service_1 = require("./attendance.service");
class AttendanceController {
    static async checkIn(req, res, next) {
        try {
            const attendance = await attendance_service_1.AttendanceService.recordCheckIn(req.body);
            res.status(201).json({ success: true, data: attendance });
        }
        catch (error) {
            next(error);
        }
    }
    static async checkOut(req, res, next) {
        try {
            const attendance = await attendance_service_1.AttendanceService.recordCheckOut(req.params.id, req.body.notes);
            res.json({ success: true, data: attendance });
        }
        catch (error) {
            next(error);
        }
    }
    static async getDaily(req, res, next) {
        try {
            const date = req.query.date || new Date().toISOString();
            const attendances = await attendance_service_1.AttendanceService.getDailyAttendance(date);
            // Wrap in consistent DTO format
            const formatted = attendances.map((a) => ({
                id: a.id,
                employeeId: a.employeeId,
                employeeName: a.employee.name,
                position: a.employee.position,
                date: a.date,
                checkIn: a.checkIn,
                checkOut: a.checkOut,
                status: a.status,
                notes: a.notes
            }));
            res.json({ success: true, data: formatted });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.AttendanceController = AttendanceController;
