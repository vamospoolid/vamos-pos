"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const attendance_controller_1 = require("./attendance.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.use((0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'KASIR', 'OWNER')); // Kasir can record attendance
router.post('/checkin', attendance_controller_1.AttendanceController.checkIn);
router.put('/checkout/:id', attendance_controller_1.AttendanceController.checkOut);
router.get('/daily', attendance_controller_1.AttendanceController.getDaily);
exports.default = router;
