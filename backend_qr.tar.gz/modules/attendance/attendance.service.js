"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttendanceService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
class AttendanceService {
    static async recordCheckIn(data) {
        const today = data.date ? new Date(data.date) : new Date();
        today.setHours(0, 0, 0, 0);
        const activeEmployee = await db_1.prisma.employee.findFirst({
            where: { id: data.employeeId, deletedAt: null }
        });
        if (!activeEmployee)
            throw new errors_1.AppError('Employee not found or inactive', 404);
        const existing = await db_1.prisma.attendance.findFirst({
            where: {
                employeeId: data.employeeId,
                date: {
                    gte: today,
                    lt: new Date(today.getTime() + 24 * 60 * 60 * 1000)
                }
            }
        });
        if (existing) {
            if (existing.checkIn && !existing.checkOut) {
                // Return existing to let user checkout
                return existing;
            }
            throw new errors_1.AppError('Attendance record already exists for today', 400);
        }
        return db_1.prisma.attendance.create({
            data: {
                employeeId: data.employeeId,
                date: new Date(),
                checkIn: new Date(),
                status: 'PRESENT',
                notes: data.notes
            }
        });
    }
    static async recordCheckOut(id, notes) {
        const existing = await db_1.prisma.attendance.findUnique({ where: { id } });
        if (!existing)
            throw new errors_1.AppError('Attendance record not found', 404);
        if (existing.checkOut)
            throw new errors_1.AppError('Already checked out', 400);
        return db_1.prisma.attendance.update({
            where: { id },
            data: {
                checkOut: new Date(),
                notes: notes ? `${existing.notes ? existing.notes + ' | ' : ''}Out: ${notes}` : existing.notes
            }
        });
    }
    static async getDailyAttendance(date) {
        let targetDate = new Date(date);
        if (isNaN(targetDate.getTime())) {
            targetDate = new Date(); // fallback today
        }
        targetDate.setHours(0, 0, 0, 0);
        const nextDay = new Date(targetDate.getTime() + 24 * 60 * 60 * 1000);
        return db_1.prisma.attendance.findMany({
            where: {
                date: {
                    gte: targetDate,
                    lt: nextDay
                }
            },
            include: {
                employee: {
                    select: { name: true, position: true }
                }
            },
            orderBy: { checkIn: 'asc' }
        });
    }
}
exports.AttendanceService = AttendanceService;
