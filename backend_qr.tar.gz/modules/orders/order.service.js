"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const audit_service_1 = require("../audit/audit.service");
const product_service_1 = require("../products/product.service");
class OrderService {
    static async addOrder(sessionId, productId, quantity, userId) {
        const session = await db_1.prisma.session.findUnique({ where: { id: sessionId }, include: { table: true } });
        if (!session || !['ACTIVE', 'PENDING', 'FINISHED'].includes(session.status)) {
            throw new errors_1.AppError('Cannot add orders to this session', 400);
        }
        const product = await db_1.prisma.product.findUnique({ where: { id: productId } });
        if (!product)
            throw new errors_1.AppError('Product not found', 404);
        await product_service_1.ProductService.validateStock(productId, quantity);
        const checkExisting = await db_1.prisma.order.findFirst({
            where: { sessionId, productId }
        });
        let order;
        if (checkExisting) {
            order = await db_1.prisma.order.update({
                where: { id: checkExisting.id },
                data: {
                    quantity: checkExisting.quantity + quantity,
                    total: (checkExisting.quantity + quantity) * product.price
                }
            });
        }
        else {
            order = await db_1.prisma.order.create({
                data: {
                    sessionId,
                    productId,
                    quantity,
                    price: product.price,
                    total: product.price * quantity,
                }
            });
        }
        const sessionDesc = session.customerName ? session.customerName : (session.table ? `Meja ${session.table.name}` : `Walk-In (${session.id.substring(0, 6)})`);
        await product_service_1.ProductService.updateStock(productId, -quantity, 'SALE', `Penjualan - ${sessionDesc}`);
        const fnbTotal = await db_1.prisma.order.aggregate({
            where: { sessionId },
            _sum: { total: true }
        });
        await db_1.prisma.session.update({
            where: { id: sessionId },
            data: {
                fnbAmount: fnbTotal._sum.total || 0,
                totalAmount: (fnbTotal._sum.total || 0) + (session.tableAmount || 0)
            }
        });
        await audit_service_1.AuditService.log(userId, 'ORDER_CREATE', 'Order', { sessionId, orderId: order.id });
        return order;
    }
    static async removeOrder(orderId, userId) {
        const order = await db_1.prisma.order.findUnique({ where: { id: orderId }, include: { session: { include: { table: true } } } });
        if (!order)
            throw new errors_1.AppError('Order not found', 404);
        if (!['ACTIVE', 'PENDING', 'FINISHED'].includes(order.session.status)) {
            throw new errors_1.AppError('Cannot modify orders for this session', 400);
        }
        await db_1.prisma.order.delete({ where: { id: orderId } });
        const sessionDesc = order.session.customerName ? order.session.customerName : (order.session.table ? `Meja ${order.session.table.name}` : `Walk-In (${order.session.id.substring(0, 6)})`);
        await product_service_1.ProductService.updateStock(order.productId, order.quantity, 'RETURN', `Batal Penjualan - ${sessionDesc}`);
        const fnbTotal = await db_1.prisma.order.aggregate({
            where: { sessionId: order.sessionId },
            _sum: { total: true }
        });
        const currentSession = await db_1.prisma.session.findUnique({ where: { id: order.sessionId } });
        await db_1.prisma.session.update({
            where: { id: order.sessionId },
            data: {
                fnbAmount: fnbTotal._sum.total || 0,
                totalAmount: (fnbTotal._sum.total || 0) + (currentSession?.tableAmount || 0)
            }
        });
        await audit_service_1.AuditService.log(userId, 'ORDER_DELETE', 'Order', { orderId });
        return { success: true };
    }
    static async getKDSOrders() {
        return await db_1.prisma.order.findMany({
            where: {
                kdsStatus: {
                    not: 'SERVED'
                }
            },
            include: {
                product: true,
                session: {
                    include: {
                        table: true
                    }
                }
            },
            orderBy: {
                createdAt: 'asc'
            }
        });
    }
    static async updateKDSStatus(orderId, status) {
        if (!['PENDING', 'PROCESSING', 'READY', 'SERVED'].includes(status)) {
            throw new errors_1.AppError('Invalid KDS status', 400);
        }
        return await db_1.prisma.order.update({
            where: { id: orderId },
            data: { kdsStatus: status }
        });
    }
}
exports.OrderService = OrderService;
