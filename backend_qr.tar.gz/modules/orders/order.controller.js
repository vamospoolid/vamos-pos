"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateKDSStatus = exports.getKDSOrders = exports.removeOrder = exports.addOrder = void 0;
const order_service_1 = require("./order.service");
const catchAsync_1 = require("../../utils/catchAsync");
const zod_1 = require("zod");
const socket_1 = require("../../socket");
const addOrderSchema = zod_1.z.object({
    productId: zod_1.z.string().min(1),
    quantity: zod_1.z.number().int().positive(),
});
exports.addOrder = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id: sessionId } = req.params;
    const { productId, quantity } = addOrderSchema.parse(req.body);
    const result = await order_service_1.OrderService.addOrder(sessionId, productId, quantity, req.user.id);
    (0, socket_1.getIO)().emit('orders:updated');
    (0, socket_1.getIO)().emit('sessions:updated');
    (0, socket_1.getIO)().emit('kds:updated');
    res.status(201).json(result);
});
exports.removeOrder = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const result = await order_service_1.OrderService.removeOrder(id, req.user.id);
    (0, socket_1.getIO)().emit('orders:updated');
    (0, socket_1.getIO)().emit('sessions:updated');
    (0, socket_1.getIO)().emit('kds:updated');
    res.json(result);
});
exports.getKDSOrders = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const result = await order_service_1.OrderService.getKDSOrders();
    res.json({ success: true, data: result });
});
exports.updateKDSStatus = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const result = await order_service_1.OrderService.updateKDSStatus(id, status);
    (0, socket_1.getIO)().emit('kds:updated');
    res.json({ success: true, data: result });
});
