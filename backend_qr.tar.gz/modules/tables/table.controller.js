"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TableController = void 0;
const table_service_1 = require("./table.service");
const socket_1 = require("../../socket");
class TableController {
    static async createTable(req, res, next) {
        try {
            console.log('CREATE TABLE BODY:', JSON.stringify(req.body));
            const table = await table_service_1.TableService.createTable(req.body);
            res.status(201).json({ success: true, data: table });
        }
        catch (error) {
            console.error('CREATE TABLE ERROR:', error);
            next(error);
        }
    }
    static async getTables(req, res, next) {
        try {
            const venueId = req.query.venueId;
            const tables = await table_service_1.TableService.getTables(venueId);
            res.json({ success: true, data: tables });
        }
        catch (error) {
            next(error);
        }
    }
    static async getTableById(req, res, next) {
        try {
            const table = await table_service_1.TableService.getTableById(req.params.id);
            res.json({ success: true, data: table });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateTable(req, res, next) {
        try {
            const table = await table_service_1.TableService.updateTable(req.params.id, req.body);
            (0, socket_1.getIO)().emit('tables:updated');
            res.json({ success: true, data: table });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteTable(req, res, next) {
        try {
            await table_service_1.TableService.deleteTable(req.params.id);
            res.json({ success: true, message: 'Table deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
    static async fixStuckTables(req, res, next) {
        try {
            const result = await table_service_1.TableService.fixStuckTables();
            (0, socket_1.getIO)().emit('tables:updated');
            res.json({
                success: true,
                message: result.fixed > 0
                    ? `Fixed ${result.fixed} stuck table(s): ${result.tableNames.join(', ')}`
                    : 'No stuck tables found. All tables are clean.',
                data: result
            });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.TableController = TableController;
