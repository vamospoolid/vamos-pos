"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TableService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const logger_1 = require("../../utils/logger");
class TableService {
    static async createTable(data) {
        console.log('Validating table create data:', JSON.stringify(data));
        const { venueId, name, type, area, relayChannel } = data;
        const cleanData = {
            venueId,
            name,
            type,
            area: area || null,
            relayChannel: Number(relayChannel),
            isKingTable: Boolean(data.isKingTable)
        };
        if (isNaN(cleanData.relayChannel)) {
            throw new errors_1.AppError('Relay channel must be a valid number', 400);
        }
        const venue = await db_1.prisma.venue.findFirst({ where: { id: cleanData.venueId, deletedAt: null } });
        if (!venue) {
            console.error('Venue not found for ID:', cleanData.venueId);
            throw new errors_1.AppError('Venue not found with ID: ' + cleanData.venueId, 404);
        }
        const existingTable = await db_1.prisma.table.findFirst({
            where: { venueId: cleanData.venueId, relayChannel: cleanData.relayChannel, deletedAt: null }
        });
        if (existingTable) {
            throw new errors_1.AppError(`Relay channel ${cleanData.relayChannel} is already used by ${existingTable.name}`, 400);
        }
        try {
            return await db_1.prisma.table.create({ data: cleanData });
        }
        catch (dbError) {
            console.error('Prisma Create Table Error:', dbError);
            throw dbError;
        }
    }
    static async getTables(venueId) {
        const whereClause = { deletedAt: null };
        if (venueId)
            whereClause.venueId = venueId;
        return db_1.prisma.table.findMany({
            where: whereClause,
            include: {
                venue: true,
                kingStatus: {
                    include: {
                        king: true
                    }
                }
            },
            orderBy: { name: 'asc' }
        });
    }
    static async getTableById(id) {
        const table = await db_1.prisma.table.findFirst({
            where: { id, deletedAt: null },
            include: {
                venue: true,
                kingStatus: {
                    include: {
                        king: true
                    }
                }
            }
        });
        if (!table)
            throw new errors_1.AppError('Table not found', 404);
        return table;
    }
    static async updateTable(id, data) {
        const table = await db_1.prisma.table.findFirst({ where: { id, deletedAt: null } });
        if (!table)
            throw new errors_1.AppError('Table not found', 404);
        if (data.relayChannel && data.relayChannel !== table.relayChannel) {
            const existingTable = await db_1.prisma.table.findFirst({
                where: { venueId: table.venueId, relayChannel: data.relayChannel, deletedAt: null }
            });
            if (existingTable)
                throw new errors_1.AppError('Relay channel is already in use at this venue', 400);
        }
        return db_1.prisma.table.update({ where: { id }, data });
    }
    static async deleteTable(id) {
        const table = await db_1.prisma.table.findFirst({ where: { id, deletedAt: null } });
        if (!table)
            throw new errors_1.AppError('Table not found', 404);
        return db_1.prisma.table.update({ where: { id }, data: { deletedAt: new Date() } });
    }
    /**
     * Reset meja yang stuck di status PLAYING padahal tidak ada sesi aktif.
     *
     * Langkah:
     *   1. Update status DB → AVAILABLE
     *   2. Kirim perintah relay OFF per channel → lampu fisik benar-benar mati
     *
     * Return value mencakup berapa relay berhasil dimatikan dan
     * channel mana yang gagal (jika relay tidak terhubung, tetap tidak crash).
     */
    static async fixStuckTables() {
        // Cari semua meja berstatus PLAYING
        const playingTables = await db_1.prisma.table.findMany({
            where: { status: 'PLAYING', deletedAt: null },
            include: {
                sessions: {
                    where: { status: 'ACTIVE' },
                    take: 1
                }
            }
        });
        // Yang tidak punya sesi aktif = stuck
        const stuckTables = playingTables.filter(t => t.sessions.length === 0);
        if (stuckTables.length === 0) {
            return { fixed: 0, tableNames: [], relayOff: [], relayErrors: [] };
        }
        logger_1.logger.warn(`🔧 fixStuckTables: ditemukan ${stuckTables.length} meja stuck → ` +
            `[${stuckTables.map(t => `${t.name}(ch${t.relayChannel})`).join(', ')}]`);
        // ── LANGKAH 1: Reset status DB ──────────────────────────────────
        await db_1.prisma.table.updateMany({
            where: { id: { in: stuckTables.map(t => t.id) } },
            data: { status: 'AVAILABLE' }
        });
        logger_1.logger.info(`✅ fixStuckTables: Status DB ${stuckTables.length} meja → AVAILABLE`);
        // ── LANGKAH 2: Matikan relay per channel (DIPERINTAHKAN USER UNTUK DIHAPUS) ──────
        // User ingin meja direset di DB tapi lampu tetap menyala (mungkin untuk manual check)
        /*
        const { RelayService } = await import('../relay/relay.service');
        for (const table of stuckTables) {
            try {
                await RelayService.sendCommand(table.relayChannel, 'off');
                relayOff.push(table.relayChannel);
            } catch (err: any) { ... }
        }
        */
        // ── LANGKAH 3: Sinyal Realtime ──────────────────────────────────
        try {
            const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            const io = getIO();
            if (io) {
                io.emit('tables:updated');
                io.emit('sessions:updated');
                logger_1.logger.info('📡 fixStuckTables: Sinyal realtime dikirim ke Frontend');
            }
        }
        catch (socketErr) {
            logger_1.logger.error(`❌ fixStuckTables Gagal mengirim socket: ${socketErr.message}`);
        }
        return {
            fixed: stuckTables.length,
            tableNames: stuckTables.map(t => t.name),
            relayOff: [],
            relayErrors: [],
        };
    }
}
exports.TableService = TableService;
