"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeeService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
class EmployeeService {
    static async createEmployee(data) {
        return db_1.prisma.employee.create({ data });
    }
    static async getEmployees() {
        return db_1.prisma.employee.findMany({
            where: { deletedAt: null },
            orderBy: { createdAt: 'desc' }
        });
    }
    static async getEmployeeById(id) {
        const employee = await db_1.prisma.employee.findFirst({
            where: { id, deletedAt: null }
        });
        if (!employee)
            throw new errors_1.AppError('Employee not found', 404);
        return employee;
    }
    static async updateEmployee(id, data) {
        const employee = await db_1.prisma.employee.findFirst({ where: { id, deletedAt: null } });
        if (!employee)
            throw new errors_1.AppError('Employee not found', 404);
        return db_1.prisma.employee.update({
            where: { id },
            data
        });
    }
    static async deleteEmployee(id) {
        const employee = await db_1.prisma.employee.findFirst({ where: { id, deletedAt: null } });
        if (!employee)
            throw new errors_1.AppError('Employee not found', 404);
        return db_1.prisma.employee.update({
            where: { id },
            data: { deletedAt: new Date(), status: 'TERMINATED' }
        });
    }
}
exports.EmployeeService = EmployeeService;
