"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeeController = void 0;
const employee_service_1 = require("./employee.service");
class EmployeeController {
    static async createEmployee(req, res, next) {
        try {
            const employee = await employee_service_1.EmployeeService.createEmployee(req.body);
            res.status(201).json({ success: true, data: employee });
        }
        catch (error) {
            next(error);
        }
    }
    static async getEmployees(req, res, next) {
        try {
            const employees = await employee_service_1.EmployeeService.getEmployees();
            res.json({ success: true, data: employees });
        }
        catch (error) {
            next(error);
        }
    }
    static async getEmployeeById(req, res, next) {
        try {
            const employee = await employee_service_1.EmployeeService.getEmployeeById(req.params.id);
            res.json({ success: true, data: employee });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateEmployee(req, res, next) {
        try {
            const employee = await employee_service_1.EmployeeService.updateEmployee(req.params.id, req.body);
            res.json({ success: true, data: employee });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteEmployee(req, res, next) {
        try {
            await employee_service_1.EmployeeService.deleteEmployee(req.params.id);
            res.json({ success: true, message: 'Employee terminated successfully' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.EmployeeController = EmployeeController;
