"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteWaitlist = exports.updateStatus = exports.getWaitlist = exports.addToWaitlist = void 0;
const waitlist_service_1 = require("./waitlist.service");
const catchAsync_1 = require("../../utils/catchAsync");
const socket_1 = require("../../socket");
const zod_1 = require("zod");
const waitlistSchema = zod_1.z.object({
    customerName: zod_1.z.string().min(1),
    phone: zod_1.z.string().optional(),
    partySize: zod_1.z.number().int().positive().optional(),
    tableType: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    reservedTime: zod_1.z.string().optional(),
    tableId: zod_1.z.string().optional(),
});
exports.addToWaitlist = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const data = waitlistSchema.parse(req.body);
    const result = await waitlist_service_1.WaitlistService.addToWaitlist(data, req.user.id);
    (0, socket_1.getIO)().emit('waitlist:updated');
    res.status(201).json(result);
});
exports.getWaitlist = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const result = await waitlist_service_1.WaitlistService.getWaitlist();
    res.json(result);
});
exports.updateStatus = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { status, tableId } = zod_1.z.object({ status: zod_1.z.string(), tableId: zod_1.z.string().optional() }).parse(req.body);
    const result = await waitlist_service_1.WaitlistService.updateStatus(id, status, req.user.id, tableId);
    (0, socket_1.getIO)().emit('waitlist:updated');
    (0, socket_1.getIO)().emit('sessions:updated');
    res.json(result);
});
exports.deleteWaitlist = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const result = await waitlist_service_1.WaitlistService.deleteWaitlist(id, req.user.id);
    (0, socket_1.getIO)().emit('waitlist:updated');
    res.json(result);
});
