"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.WaitlistService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const audit_service_1 = require("../audit/audit.service");
const session_service_1 = require("../sessions/session.service");
class WaitlistService {
    static async addToWaitlist(data, userId) {
        const waitlist = await db_1.prisma.waitlist.create({
            data: {
                customerName: data.customerName,
                phone: data.phone,
                partySize: data.partySize || 1,
                tableType: data.tableType,
                notes: data.notes,
                reservedTime: data.reservedTime ? new Date(data.reservedTime) : null,
                tableId: data.tableId || null,
                status: 'WAITING'
            }
        });
        if (data.phone) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                const venueName = venue?.name || 'VAMOS';
                const { WaTemplateService, WA_TEMPLATE_IDS } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.template.service')));
                const waTemplate = await WaTemplateService.renderTemplate(WA_TEMPLATE_IDS.WAITLIST_CONFIRM, {
                    name: data.customerName,
                    venue: venueName,
                    table: data.tableType || 'Any',
                    time: data.reservedTime ? new Date(data.reservedTime).toLocaleString('id-ID') : 'Sekarang',
                });
                if (waTemplate) {
                    Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service'))).then(({ waService }) => {
                        waService.sendMessage(data.phone, waTemplate.body, waTemplate.imageUrl || undefined);
                    });
                }
            }
            catch (error) {
                console.error('Failed to send waitlist confirm WA:', error);
            }
        }
        await audit_service_1.AuditService.log(userId, 'WAITLIST_ADD', 'Waitlist', { waitlistId: waitlist.id });
        return waitlist;
    }
    static async getWaitlist() {
        return db_1.prisma.waitlist.findMany({
            where: {
                status: { in: ['WAITING', 'CALLED'] },
                deletedAt: null
            },
            include: {
                table: true
            },
            orderBy: [
                { reservedTime: 'asc' },
                { createdAt: 'asc' }
            ]
        });
    }
    static async updateStatus(id, status, userId, tableId) {
        let waitlist = await db_1.prisma.waitlist.findUnique({ where: { id } });
        if (!waitlist)
            throw new errors_1.AppError('Waitlist entry not found', 404);
        if (status === 'CALLED' && waitlist.phone) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                const venueName = venue?.name || 'VAMOS';
                const { WaTemplateService, WA_TEMPLATE_IDS } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.template.service')));
                const waTemplate = await WaTemplateService.renderTemplate(WA_TEMPLATE_IDS.WAITLIST_READY, {
                    name: waitlist.customerName,
                    venue: venueName,
                });
                if (waTemplate) {
                    Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service'))).then(({ waService }) => {
                        waService.sendMessage(waitlist.phone, waTemplate.body, waTemplate.imageUrl || undefined);
                    });
                }
            }
            catch (error) {
                console.error('Failed to send waitlist ready WA:', error);
            }
        }
        if (status === 'SEATED') {
            const finalTableId = tableId || waitlist.tableId;
            if (!finalTableId) {
                throw new errors_1.AppError('Silakan pilih meja terlebih dahulu untuk menidurkan (SEATED) tamu ini.', 400);
            }
            // Update tableId if changed/assigned
            if (tableId && tableId !== waitlist.tableId) {
                waitlist = await db_1.prisma.waitlist.update({
                    where: { id },
                    data: { tableId }
                });
            }
            // Start Session
            await session_service_1.SessionService.startSession(finalTableId, userId, waitlist.packageId || undefined, waitlist.memberId || undefined, waitlist.durationMinutes || 60, waitlist.price || undefined);
            // APP BOOKING INCENTIVE (+20 Points)
            if (waitlist.memberId) {
                try {
                    const { LoyaltyService } = await Promise.resolve().then(() => __importStar(require('../loyalty/loyalty.service')));
                    await LoyaltyService.addPoints(waitlist.memberId, 20, 'EARN_BONUS', '🎁 Bonus: Booking via Player App');
                    if (waitlist.phone) {
                        const { waService } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service')));
                        await waService.sendMessage(waitlist.phone, `*TABLE READY!* 🎱\n\nHalo ${waitlist.customerName}, meja Anda sudah siap. \n\nTerima kasih telah booking via Player App! Anda mendapatkan *Bonus 20 Poin Loyalty*. Selamat bermain! 🔥`);
                    }
                }
                catch (e) {
                    console.error('Failed to award app booking bonus:', e);
                }
            }
        }
        const updated = await db_1.prisma.waitlist.update({
            where: { id },
            data: { status }
        });
        await audit_service_1.AuditService.log(userId, 'WAITLIST_UPDATE_STATUS', 'Waitlist', { waitlistId: id, status });
        return updated;
    }
    static async deleteWaitlist(id, userId) {
        await db_1.prisma.waitlist.update({
            where: { id },
            data: { deletedAt: new Date() }
        });
        await audit_service_1.AuditService.log(userId, 'WAITLIST_DELETE', 'Waitlist', { waitlistId: id });
        return { success: true };
    }
    static async checkExpiredWaitlist() {
        const threshold = new Date(Date.now() - 30 * 60 * 1000);
        const expiredEntries = await db_1.prisma.waitlist.findMany({
            where: {
                status: 'WAITING',
                reservedTime: { lt: threshold },
                deletedAt: null
            },
            include: { member: true }
        });
        if (expiredEntries.length === 0)
            return;
        for (const entry of expiredEntries) {
            try {
                await db_1.prisma.$transaction(async (tx) => {
                    await tx.waitlist.update({
                        where: { id: entry.id },
                        data: { status: 'EXPIRED' }
                    });
                    if (entry.memberId) {
                        const { LoyaltyService } = await Promise.resolve().then(() => __importStar(require('../loyalty/loyalty.service')));
                        await LoyaltyService.addPoints(entry.memberId, -50, 'ADJUSTMENT', '💀 Penalty: No-show booking (Antrian Hangus)');
                        if (entry.member?.phone) {
                            const { waService } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service')));
                            await waService.sendMessage(entry.member.phone, `*BOOKING EXPIRED* 💀\n\nHalo ${entry.member.name}, antrian Anda di VAMOS telah hangus karena melewati batas waktu 30 menit. \n\nSesuai ketentuan, poin Anda dipotong *50 Poin* sebagai kompensasi. Mohon hadir tepat waktu di booking berikutnya ya! 🙏`);
                        }
                    }
                });
            }
            catch (err) {
                console.error(`Error processing expired waitlist ${entry.id}:`, err.message);
            }
        }
        try {
            const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
            getIO().emit('waitlist:updated');
        }
        catch (e) { }
    }
}
exports.WaitlistService = WaitlistService;
