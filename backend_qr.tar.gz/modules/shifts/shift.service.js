"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const audit_service_1 = require("../audit/audit.service");
class ShiftService {
    static async startShift(userId, startingCash, notes) {
        // Cek apakah kasir ini sudah punya shift yang masih OPEN
        const existingShift = await db_1.prisma.cashierShift.findFirst({
            where: { userId, status: 'OPEN' }
        });
        if (existingShift) {
            throw new errors_1.AppError('Anda sudah memiliki shift yang masih terbuka. Silakan tutup shift Anda sebelum membuka yang baru.', 400);
        }
        const shift = await db_1.prisma.cashierShift.create({
            data: {
                userId,
                startingCash,
                notes,
                status: 'OPEN',
            }
        });
        await audit_service_1.AuditService.log(userId, 'SHIFT_START', 'CashierShift', { shiftId: shift.id, startingCash });
        return shift;
    }
    static async getActiveShift(userId) {
        return db_1.prisma.cashierShift.findFirst({
            where: { userId, status: 'OPEN' },
            include: { payments: true }
        });
    }
    static async closeShift(userId, endingCashActual, notes) {
        const shift = await db_1.prisma.cashierShift.findFirst({
            where: { userId, status: 'OPEN' },
            include: { payments: true }
        });
        if (!shift) {
            throw new errors_1.AppError('Anda tidak mempunyai shift yang sedang aktif.', 400);
        }
        const endTime = new Date();
        // Hitung ekspektasi cash dari pembayaran (misal ada cash in / dll di payment method CASH)
        const expectedCashPayments = shift.payments
            .filter((p) => p.method === 'CASH' && p.status === 'SUCCESS')
            .reduce((sum, p) => sum + p.amount, 0);
        const expectedQris = shift.payments
            .filter((p) => p.method === 'QRIS' && p.status === 'SUCCESS')
            .reduce((sum, p) => sum + p.amount, 0);
        const expectedCard = shift.payments
            .filter((p) => p.method === 'CARD' && p.status === 'SUCCESS')
            .reduce((sum, p) => sum + p.amount, 0);
        // Hitung total pengeluaran tunai (Expense) selama shift ini
        const totalExpenses = await db_1.prisma.expense.aggregate({
            where: { shiftId: shift.id, deletedAt: null },
            _sum: { amount: true }
        });
        const totalExpenseAmount = totalExpenses?._sum?.amount || 0;
        const expectedCash = shift.startingCash + expectedCashPayments - totalExpenseAmount;
        const updatedShift = await db_1.prisma.cashierShift.update({
            where: { id: shift.id },
            data: {
                status: 'CLOSED',
                endTime,
                endingCashActual,
                expectedCash,
                expectedQris,
                expectedCard,
                notes: notes || shift.notes
            }
        });
        await audit_service_1.AuditService.log(userId, 'SHIFT_CLOSE', 'CashierShift', { shiftId: shift.id, expectedCash, endingCashActual });
        return updatedShift;
    }
    static async getAllShifts() {
        return db_1.prisma.cashierShift.findMany({
            orderBy: { createdAt: 'desc' },
            include: { user: { select: { name: true, role: true } }, payments: true }
        });
    }
    // Mendapatkan laporan setoran harian untuk Admin
    static async getShiftReport(dateStr) {
        // Default today
        const targetDate = dateStr ? new Date(dateStr) : new Date();
        const startOfDay = new Date(targetDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(targetDate);
        endOfDay.setHours(23, 59, 59, 999);
        return db_1.prisma.cashierShift.findMany({
            where: {
                createdAt: {
                    gte: startOfDay,
                    lte: endOfDay
                }
            },
            include: { user: { select: { name: true } }, payments: true },
            orderBy: { createdAt: 'desc' }
        });
    }
}
exports.ShiftService = ShiftService;
