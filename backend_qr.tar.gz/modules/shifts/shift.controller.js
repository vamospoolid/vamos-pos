"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getShiftReport = exports.getAllShifts = exports.getActiveShift = exports.closeShift = exports.startShift = void 0;
const shift_service_1 = require("./shift.service");
const catchAsync_1 = require("../../utils/catchAsync");
exports.startShift = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { startingCash, notes } = req.body;
    const shift = await shift_service_1.ShiftService.startShift(req.user.id, startingCash || 0, notes);
    res.status(201).json({ success: true, data: shift });
});
exports.closeShift = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { endingCashActual, notes } = req.body;
    const shift = await shift_service_1.ShiftService.closeShift(req.user.id, endingCashActual, notes);
    res.json({ success: true, data: shift });
});
exports.getActiveShift = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const shift = await shift_service_1.ShiftService.getActiveShift(req.user.id);
    res.json({ success: true, data: shift || null });
});
exports.getAllShifts = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const shifts = await shift_service_1.ShiftService.getAllShifts();
    res.json({ success: true, data: shifts });
});
exports.getShiftReport = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const shifts = await shift_service_1.ShiftService.getShiftReport(req.query.date);
    res.json({ success: true, data: shifts });
});
