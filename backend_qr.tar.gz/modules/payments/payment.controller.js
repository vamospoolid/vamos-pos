"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getManualIncomes = exports.createManualIncome = void 0;
const db_1 = require("../../database/db");
const catchAsync_1 = require("../../utils/catchAsync");
const errors_1 = require("../../utils/errors");
const socket_1 = require("../../socket");
exports.createManualIncome = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { amount, method, notes } = req.body;
    const userId = req.user.id;
    if (!amount || amount <= 0) {
        throw new errors_1.AppError('Jumlah pemasukan tidak valid', 400);
    }
    // Cari shift kasir yang aktif agar pemasukan masuk ke cash shift tersebut
    const activeShift = await db_1.prisma.cashierShift.findFirst({
        where: { userId, status: 'OPEN' }
    });
    const payment = await db_1.prisma.payment.create({
        data: {
            amount: Number(amount),
            method: method || 'CASH',
            notes: notes || 'Pemasukan Lain-Lain',
            status: 'SUCCESS',
            cashierId: userId,
            shiftId: activeShift ? activeShift.id : null,
            // sessionId omitted implies null for manual income
        }
    });
    // Notify connected clients that financial data is updated
    (0, socket_1.getIO)().emit('sessions:updated');
    res.status(201).json({ success: true, data: payment });
});
exports.getManualIncomes = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const payments = await db_1.prisma.payment.findMany({
        where: {
            sessionId: null,
            status: 'SUCCESS'
        },
        orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data: payments });
});
