"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const reward_controller_1 = require("./reward.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
// Public (authenticated) — member-facing
router.get('/', reward_controller_1.getRewards); // GET  /rewards
router.post('/redeem', reward_controller_1.redeemReward); // POST /rewards/redeem  { memberId, rewardId }
router.get('/redemptions/member/:memberId', reward_controller_1.getMemberRedemptions); // GET  /rewards/redemptions/member/:memberId
// Admin/Owner/Manager only
router.post('/', (0, auth_1.authorizeRoles)('ADMIN', 'OWNER', 'MANAGER'), reward_controller_1.createReward); // POST /rewards
router.get('/redemptions', (0, auth_1.authorizeRoles)('ADMIN', 'OWNER', 'MANAGER', 'KASIR'), reward_controller_1.getRedemptions); // GET  /rewards/redemptions
router.put('/redemptions/:id/fulfill', (0, auth_1.authorizeRoles)('ADMIN', 'OWNER', 'MANAGER', 'KASIR'), reward_controller_1.fulfillRedemption); // PUT /rewards/redemptions/:id/fulfill
router.put('/:id', (0, auth_1.authorizeRoles)('ADMIN', 'OWNER', 'MANAGER'), reward_controller_1.updateReward); // PUT  /rewards/:id
router.delete('/:id', (0, auth_1.authorizeRoles)('ADMIN', 'OWNER', 'MANAGER'), reward_controller_1.deleteReward); // DEL  /rewards/:id
exports.default = router;
