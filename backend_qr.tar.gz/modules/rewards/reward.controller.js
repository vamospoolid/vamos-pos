"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMemberRedemptions = exports.fulfillRedemption = exports.getRedemptions = exports.redeemReward = exports.deleteReward = exports.updateReward = exports.createReward = exports.getRewards = void 0;
const db_1 = require("../../database/db");
const catchAsync_1 = require("../../utils/catchAsync");
const errors_1 = require("../../utils/errors");
// ─── Admin: Get all rewards ───────────────────────────────────────────────────
exports.getRewards = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const rewards = await db_1.prisma.reward.findMany({
        where: { isActive: true },
        include: { _count: { select: { redemptions: true } } },
        orderBy: { pointsRequired: 'asc' }
    });
    res.json({ success: true, data: rewards });
});
// ─── Admin: Create reward ─────────────────────────────────────────────────────
exports.createReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { title, description, pointsRequired, stock, imageUrl } = req.body;
    if (!title || !pointsRequired)
        throw new errors_1.AppError('title and pointsRequired are required', 400);
    const reward = await db_1.prisma.reward.create({
        data: {
            title,
            description: description || '',
            pointsRequired: Number(pointsRequired),
            stock: stock !== undefined ? Number(stock) : 999,
            imageUrl: imageUrl || null,
        }
    });
    res.status(201).json({ success: true, data: reward });
});
// ─── Admin: Update reward ─────────────────────────────────────────────────────
exports.updateReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const { title, description, pointsRequired, stock, imageUrl, isActive } = req.body;
    const reward = await db_1.prisma.reward.update({
        where: { id },
        data: {
            ...(title !== undefined && { title }),
            ...(description !== undefined && { description }),
            ...(pointsRequired !== undefined && { pointsRequired: Number(pointsRequired) }),
            ...(stock !== undefined && { stock: Number(stock) }),
            ...(imageUrl !== undefined && { imageUrl }),
            ...(isActive !== undefined && { isActive }),
        }
    });
    res.json({ success: true, data: reward });
});
// ─── Admin: Delete reward ─────────────────────────────────────────────────────
exports.deleteReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    await db_1.prisma.reward.update({ where: { id }, data: { isActive: false } });
    res.json({ success: true, message: 'Reward deactivated' });
});
// ─── Member: Redeem a reward ──────────────────────────────────────────────────
exports.redeemReward = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId, rewardId } = req.body;
    if (!memberId || !rewardId)
        throw new errors_1.AppError('memberId and rewardId are required', 400);
    const [member, reward] = await Promise.all([
        db_1.prisma.member.findUnique({ where: { id: memberId } }),
        db_1.prisma.reward.findUnique({ where: { id: rewardId } }),
    ]);
    if (!member)
        throw new errors_1.AppError('Member not found', 404);
    if (!reward || !reward.isActive)
        throw new errors_1.AppError('Reward not found or inactive', 404);
    if (reward.stock <= 0)
        throw new errors_1.AppError('Reward is out of stock', 400);
    if (member.loyaltyPoints < reward.pointsRequired) {
        throw new errors_1.AppError(`Insufficient points. Need ${reward.pointsRequired}, have ${member.loyaltyPoints}`, 400);
    }
    // Atomic transaction: deduct points, decrement stock, create redemption
    const result = await db_1.prisma.$transaction(async (tx) => {
        const newPoints = member.loyaltyPoints - reward.pointsRequired;
        const updatedMember = await tx.member.update({
            where: { id: memberId },
            data: { loyaltyPoints: newPoints }
        });
        await tx.reward.update({
            where: { id: rewardId },
            data: { stock: reward.stock - 1 }
        });
        const redemption = await tx.redemption.create({
            data: { memberId, rewardId, status: 'PENDING' },
            include: { reward: true, member: { select: { name: true, loyaltyPoints: true } } }
        });
        return { redemption, remainingPoints: newPoints };
    });
    res.status(201).json({ success: true, data: result });
});
// ─── POS: Get all redemptions (to fulfill) ────────────────────────────────────
exports.getRedemptions = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { status } = req.query;
    const redemptions = await db_1.prisma.redemption.findMany({
        where: status ? { status: String(status) } : {},
        include: {
            member: { select: { id: true, name: true, phone: true, tier: true } },
            reward: true,
        },
        orderBy: { claimedAt: 'desc' }
    });
    res.json({ success: true, data: redemptions });
});
// ─── POS: Fulfill a redemption (mark as DELIVERED) ───────────────────────────
exports.fulfillRedemption = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { id } = req.params;
    const redemption = await db_1.prisma.redemption.update({
        where: { id },
        data: { status: 'DELIVERED' },
        include: { member: true, reward: true }
    });
    res.json({ success: true, data: redemption });
});
// ─── Player: Get redemption history for a member ─────────────────────────────
exports.getMemberRedemptions = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const { memberId } = req.params;
    const redemptions = await db_1.prisma.redemption.findMany({
        where: { memberId },
        include: { reward: true },
        orderBy: { claimedAt: 'desc' }
    });
    res.json({ success: true, data: redemptions });
});
