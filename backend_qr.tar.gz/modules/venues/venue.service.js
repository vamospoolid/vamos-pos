"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VenueService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const relay_service_1 = require("../relay/relay.service");
const timezone_utils_1 = require("../../utils/timezone.utils");
class VenueService {
    static async createVenue(data) {
        const venue = await db_1.prisma.venue.create({
            data
        });
        await (0, timezone_utils_1.refreshTimezoneCache)();
        return venue;
    }
    static async getVenues() {
        return db_1.prisma.venue.findMany({
            where: { deletedAt: null },
            include: {
                tables: {
                    where: { deletedAt: null }
                }
            }
        });
    }
    static async getVenueById(id) {
        const venue = await db_1.prisma.venue.findFirst({
            where: { id, deletedAt: null },
            include: {
                tables: {
                    where: { deletedAt: null }
                }
            }
        });
        if (!venue) {
            throw new errors_1.AppError('Venue not found', 404);
        }
        return venue;
    }
    static async updateVenue(id, data) {
        const venue = await db_1.prisma.venue.findFirst({ where: { id, deletedAt: null } });
        if (!venue) {
            throw new errors_1.AppError('Venue not found', 404);
        }
        const updateData = { ...data };
        // Anti-blank protection for critical core fields
        if (updateData.name === '')
            delete updateData.name;
        if (updateData.relayComPort === '')
            delete updateData.relayComPort;
        const updated = await db_1.prisma.venue.update({
            where: { id },
            data: updateData
        });
        if (data.relayComPort) {
            // TERIAKKAN KE BRIDGE (LAPTOP) AGAR GANTI PORT REAL-TIME
            relay_service_1.RelayService.notifyConfigUpdate(data.relayComPort);
            // JUGA UPDATE LOKAL (JIKA SEDANG RUN DI MODE LOKAL)
            relay_service_1.RelayService.init(data.relayComPort);
        }
        await (0, timezone_utils_1.refreshTimezoneCache)();
        return updated;
    }
    static async deleteVenue(id) {
        const venue = await db_1.prisma.venue.findFirst({ where: { id, deletedAt: null } });
        if (!venue) {
            throw new errors_1.AppError('Venue not found', 404);
        }
        return db_1.prisma.venue.update({
            where: { id },
            data: { deletedAt: new Date() }
        });
    }
}
exports.VenueService = VenueService;
