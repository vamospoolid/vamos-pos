"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VenueController = void 0;
const venue_service_1 = require("./venue.service");
class VenueController {
    static async createVenue(req, res, next) {
        try {
            const venue = await venue_service_1.VenueService.createVenue(req.body);
            res.status(201).json({ success: true, data: venue });
        }
        catch (error) {
            next(error);
        }
    }
    static async getVenues(req, res, next) {
        try {
            const venues = await venue_service_1.VenueService.getVenues();
            res.json({ success: true, data: venues });
        }
        catch (error) {
            next(error);
        }
    }
    static async getVenueById(req, res, next) {
        try {
            const venue = await venue_service_1.VenueService.getVenueById(req.params.id);
            res.json({ success: true, data: venue });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateVenue(req, res, next) {
        try {
            const venue = await venue_service_1.VenueService.updateVenue(req.params.id, req.body);
            res.json({ success: true, data: venue });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteVenue(req, res, next) {
        try {
            await venue_service_1.VenueService.deleteVenue(req.params.id);
            res.json({ success: true, message: 'Venue deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.VenueController = VenueController;
