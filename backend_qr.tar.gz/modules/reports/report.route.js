"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const report_controller_1 = require("./report.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.use((0, auth_1.authorizeRoles)('ADMIN', 'MANAGER', 'OWNER', 'KASIR'));
router.get('/daily-revenue', report_controller_1.getDailyRevenue);
router.get('/operational-day', report_controller_1.getOperationalDayRevenue); // ← current business day (10 AM cycle)
router.get('/today-utilization-split', report_controller_1.getTodayUtilizationSplit);
router.get('/table-utilization', report_controller_1.getTableUtilization);
router.get('/top-players', report_controller_1.getTopPlayers);
router.get('/top-products', report_controller_1.getTopProducts);
router.get('/fnb-history', report_controller_1.getFnbHistory);
router.get('/transactions', report_controller_1.getTransactionList);
exports.default = router;
