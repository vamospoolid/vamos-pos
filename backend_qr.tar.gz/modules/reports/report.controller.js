"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTransactionList = exports.getFnbHistory = exports.getTopProducts = exports.getTopPlayers = exports.getTableUtilization = exports.getTodayUtilizationSplit = exports.getOperationalDayRevenue = exports.getDailyRevenue = void 0;
const report_service_1 = require("./report.service");
const catchAsync_1 = require("../../utils/catchAsync");
exports.getDailyRevenue = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 7;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getDailyRevenue(days, startDate, endDate);
    res.json({ success: true, data: result });
});
/** Current operational day revenue — uses OPEN_HOUR cycle, not midnight */
exports.getOperationalDayRevenue = (0, catchAsync_1.catchAsync)(async (_req, res) => {
    const result = await report_service_1.ReportService.getCurrentOperationalDayRevenue();
    res.json({ success: true, data: result });
});
exports.getTodayUtilizationSplit = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const result = await report_service_1.ReportService.getTodayUtilizationSplit();
    res.json({ success: true, data: result });
});
exports.getTableUtilization = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getTableUtilization(days, startDate, endDate);
    res.json({ success: true, data: result });
});
exports.getTopPlayers = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getTopPlayers(days, startDate, endDate);
    res.json({ success: true, data: result });
});
exports.getTopProducts = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getTopProducts(days, startDate, endDate);
    res.json({ success: true, data: result });
});
exports.getFnbHistory = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getFnbHistory(days, startDate, endDate);
    res.json({ success: true, data: result });
});
exports.getTransactionList = (0, catchAsync_1.catchAsync)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 1;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const result = await report_service_1.ReportService.getTransactionList(days, startDate, endDate);
    res.json({ success: true, data: result });
});
