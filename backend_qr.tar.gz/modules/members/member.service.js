"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemberService = void 0;
const db_1 = require("../../database/db");
const errors_1 = require("../../utils/errors");
const loyalty_service_1 = require("../loyalty/loyalty.service");
const logger_1 = require("../../utils/logger");
class MemberService {
    static async createMember(data) {
        const existingMember = await db_1.prisma.member.findUnique({
            where: { phone: data.phone }
        });
        if (existingMember) {
            throw new errors_1.AppError('Phone number already registered to another member', 400);
        }
        const newMember = await db_1.prisma.member.create({
            data: {
                ...data,
                handicap: data.handicap || "3",
                handicapLabel: data.handicapLabel || "PROVISIONAL",
                skillRating: 150, // Initial rating for new players
            }
        });
        // Log initial rank info
        try {
            await db_1.prisma.rankHistory.create({
                data: {
                    memberId: newMember.id,
                    oldHandicap: "0",
                    newHandicap: newMember.handicap || "3",
                    oldRating: 0,
                    newRating: 150,
                    reason: 'INITIAL_REGISTRATION',
                    notes: 'Pendaftaran member baru (HC 3 Provisional)'
                }
            });
        }
        catch (error) {
            console.error('Failed to log initial rank history:', error);
        }
        // Award 50 bonus points for registration
        try {
            await loyalty_service_1.LoyaltyService.addPoints(newMember.id, 50, 'EARN_BONUS', '🎁 Bonus Pendaftaran Member Baru');
        }
        catch (error) {
            console.error('Failed to award registration points:', error);
        }
        // WhatsApp Welcome Message
        if (newMember.phone) {
            try {
                const venue = await db_1.prisma.venue.findFirst();
                const venueName = venue?.name || 'VAMOS';
                const { WaTemplateService, WA_TEMPLATE_IDS } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.template.service')));
                const waTemplate = await WaTemplateService.renderTemplate(WA_TEMPLATE_IDS.WELCOME_MEMBER, {
                    name: newMember.name,
                    venue: venueName,
                });
                if (waTemplate) {
                    const { waService } = await Promise.resolve().then(() => __importStar(require('../whatsapp/wa.service')));
                    if (waService.isReady) {
                        await waService.sendMessage(newMember.phone, waTemplate.body, waTemplate.imageUrl || undefined);
                        logger_1.logger.info(`✅ [WA_WELCOME] Member ${newMember.name} (Phone: ${newMember.phone}) notified!`);
                    }
                    else {
                        logger_1.logger.warn(`⚠️ [WA_WELCOME] Skip notification for ${newMember.name}: WhatsApp client NOT ready.`);
                    }
                }
            }
            catch (error) {
                logger_1.logger.error(`❌ [WA_WELCOME] Failed to send welcome WA to ${newMember.phone}: ${error.message}`);
            }
        }
        return newMember;
    }
    static async getMembers() {
        const members = await db_1.prisma.member.findMany({
            where: { deletedAt: null },
            include: {
                expenses: {
                    where: {
                        isDebt: true,
                        status: 'PENDING',
                        deletedAt: null
                    },
                    select: {
                        amount: true
                    }
                }
            },
            orderBy: {
                loyaltyPoints: 'desc'
            }
        });
        return members.map(m => {
            const totalDebt = m.expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
            const { expenses, ...memberData } = m;
            return {
                ...memberData,
                totalDebt
            };
        });
    }
    static async getMemberById(id) {
        const member = await db_1.prisma.member.findFirst({
            where: { id, deletedAt: null },
            include: {
                matches: {
                    include: {
                        match: true
                    },
                    orderBy: {
                        match: {
                            createdAt: 'desc'
                        }
                    },
                    take: 10
                },
                challengesSent: {
                    include: {
                        opponent: true
                    },
                    orderBy: {
                        createdAt: 'desc'
                    },
                    take: 20
                },
                challengesReceived: {
                    include: {
                        challenger: true
                    },
                    orderBy: {
                        createdAt: 'desc'
                    },
                    take: 20
                },
                pointLogs: {
                    orderBy: {
                        createdAt: 'desc'
                    },
                    take: 50
                }
            }
        });
        if (!member) {
            throw new errors_1.AppError('Member not found', 404);
        }
        return member;
    }
    static async getMemberByPhone(phone) {
        const member = await db_1.prisma.member.findFirst({
            where: { phone, deletedAt: null }
        });
        if (!member) {
            throw new errors_1.AppError('Member not found', 404);
        }
        return member;
    }
    static async updateMember(id, data) {
        const member = await db_1.prisma.member.findFirst({ where: { id, deletedAt: null } });
        if (!member) {
            throw new errors_1.AppError('Member not found', 404);
        }
        if (data.phone && data.phone !== member.phone) {
            const existingMember = await db_1.prisma.member.findFirst({
                where: { phone: data.phone, id: { not: id }, deletedAt: null }
            });
            if (existingMember) {
                throw new errors_1.AppError('Phone number already registered to another member', 400);
            }
        }
        return db_1.prisma.member.update({
            where: { id },
            data
        });
    }
    static async addLoyaltyPoints(id, points) {
        const member = await db_1.prisma.member.findFirst({ where: { id, deletedAt: null } });
        if (!member) {
            throw new errors_1.AppError('Member not found', 404);
        }
        return db_1.prisma.member.update({
            where: { id },
            data: {
                loyaltyPoints: {
                    increment: points
                }
            }
        });
    }
    static async deleteMember(id) {
        const member = await db_1.prisma.member.findFirst({ where: { id, deletedAt: null } });
        if (!member) {
            throw new errors_1.AppError('Member not found', 404);
        }
        // We could also anonymize the phone number or name, but soft delete is what we usually do.
        return db_1.prisma.member.update({
            where: { id },
            data: {
                deletedAt: new Date(),
                // Prepend random string so the number can be reused if the member returns
                phone: `deleted_${Date.now()}_${member.phone}`
            }
        });
    }
    // Example of an internal service function (could be called when a Match concludes)
    static async updateMatchStats(memberId, isWinner) {
        const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
        if (!member)
            return;
        const newTotalMatches = member.totalMatches + 1;
        const newTotalWins = member.totalWins + (isWinner ? 1 : 0);
        const newWinRate = (newTotalWins / newTotalMatches) * 100;
        await db_1.prisma.member.update({
            where: { id: memberId },
            data: {
                totalMatches: newTotalMatches,
                totalWins: newTotalWins,
                winRate: newWinRate
            }
        });
    }
    static async updatePlayHours(memberId, hoursPlayed) {
        const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
        if (!member)
            return;
        const m = member;
        const now = new Date();
        // Month transition check
        const lastUpdated = member.updatedAt ? new Date(member.updatedAt) : new Date();
        const isNewMonth = now.getMonth() !== lastUpdated.getMonth() || now.getFullYear() !== lastUpdated.getFullYear();
        let currentHours = m.currentMonthPlayHours || 0;
        let lastHours = m.lastMonthPlayHours || 0;
        if (isNewMonth) {
            lastHours = currentHours;
            currentHours = 0;
        }
        await db_1.prisma.member.update({
            where: { id: memberId },
            data: {
                totalPlayHours: member.totalPlayHours + hoursPlayed,
                currentMonthPlayHours: currentHours + hoursPlayed,
                lastMonthPlayHours: lastHours
            }
        });
    }
    static async updateSpend(memberId, amount) {
        const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
        if (!member)
            return;
        await db_1.prisma.member.update({
            where: { id: memberId },
            data: {
                totalSpend: (member.totalSpend || 0) + amount
            }
        });
    }
    static async updatePrizeWon(memberId, prizeAmount) {
        const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
        if (!member)
            return;
        await db_1.prisma.member.update({
            where: { id: memberId },
            data: {
                totalPrizeWon: member.totalPrizeWon + prizeAmount
            }
        });
    }
    static async verifyWa(id) {
        const member = await db_1.prisma.member.update({
            where: { id },
            data: {
                isWaVerified: true,
                waVerifiedAt: new Date()
            }
        });
        await MemberService.checkAndAwardVerificationReward(id);
        return member;
    }
    static async updateVerificationStatus(id, status) {
        const data = { identityStatus: status };
        if (status === 'VERIFIED') {
            data.isPhotoVerified = true;
            data.photoVerifiedAt = new Date();
        }
        else if (status === 'REJECTED' || status === 'UNVERIFIED') {
            data.isPhotoVerified = false;
        }
        const member = await db_1.prisma.member.update({
            where: { id },
            data
        });
        if (status === 'VERIFIED') {
            await MemberService.checkAndAwardVerificationReward(id);
        }
        return member;
    }
    static async checkAndAwardVerificationReward(memberId) {
        const member = await db_1.prisma.member.findUnique({
            where: { id: memberId }
        });
        if (!member)
            return;
        if (member.isWaVerified && (member.isPhotoVerified || member.photo) && !member.isVerificationRewardClaimed) {
            // Award 50 points (Adjusted from 35,000 to be more realistic)
            await loyalty_service_1.LoyaltyService.addPoints(memberId, 50, 'EARN_BONUS', '🎁 Reward Verifikasi WhatsApp & Foto');
            await db_1.prisma.member.update({
                where: { id: memberId },
                data: {
                    isVerificationRewardClaimed: true
                }
            });
        }
    }
}
exports.MemberService = MemberService;
