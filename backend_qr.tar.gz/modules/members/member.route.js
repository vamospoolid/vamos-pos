"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const member_controller_1 = require("./member.controller");
const router = (0, express_1.Router)();
router.post('/', member_controller_1.MemberController.createMember);
router.get('/', member_controller_1.MemberController.getMembers);
router.get('/phone/:phone', member_controller_1.MemberController.getMemberByPhone); // Find by phone (useful for cashier checking)
router.get('/:id', member_controller_1.MemberController.getMemberById);
router.put('/:id', member_controller_1.MemberController.updateMember);
router.patch('/:id/points', member_controller_1.MemberController.addLoyaltyPoints); // Manual or system points adjustment
router.patch('/:id/verify/wa', member_controller_1.MemberController.verifyWa); // Confirm WhatsApp verification
router.patch('/:id/verify/status', member_controller_1.MemberController.updateVerificationStatus); // Admin verification status
router.delete('/:id', member_controller_1.MemberController.deleteMember);
exports.default = router;
