"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemberController = void 0;
const member_service_1 = require("./member.service");
const socket_1 = require("../../socket");
class MemberController {
    static async createMember(req, res, next) {
        try {
            const member = await member_service_1.MemberService.createMember(req.body);
            console.log('[Socket] Emitting members:updated');
            (0, socket_1.getIO)().emit('members:updated');
            res.status(201).json({ success: true, data: member });
        }
        catch (error) {
            next(error);
        }
    }
    static async getMembers(req, res, next) {
        try {
            const members = await member_service_1.MemberService.getMembers();
            res.json({ success: true, data: members });
        }
        catch (error) {
            next(error);
        }
    }
    static async getMemberById(req, res, next) {
        try {
            const member = await member_service_1.MemberService.getMemberById(req.params.id);
            res.json({ success: true, data: member });
        }
        catch (error) {
            next(error);
        }
    }
    static async getMemberByPhone(req, res, next) {
        try {
            const member = await member_service_1.MemberService.getMemberByPhone(req.params.phone);
            res.json({ success: true, data: member });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateMember(req, res, next) {
        try {
            const member = await member_service_1.MemberService.updateMember(req.params.id, req.body);
            (0, socket_1.getIO)().emit('members:updated');
            res.json({ success: true, data: member });
        }
        catch (error) {
            next(error);
        }
    }
    static async addLoyaltyPoints(req, res, next) {
        try {
            const points = parseInt(req.body.points);
            if (isNaN(points)) {
                return res.status(400).json({ success: false, message: 'Invalid points value' });
            }
            const member = await member_service_1.MemberService.addLoyaltyPoints(req.params.id, points);
            res.json({ success: true, message: `Added ${points} pts`, data: member });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteMember(req, res, next) {
        try {
            await member_service_1.MemberService.deleteMember(req.params.id);
            (0, socket_1.getIO)().emit('members:updated');
            res.json({ success: true, message: 'Member deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
    static async verifyWa(req, res, next) {
        try {
            const result = await member_service_1.MemberService.verifyWa(req.params.id);
            res.json({ success: true, data: result });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateVerificationStatus(req, res, next) {
        try {
            const { status } = req.body;
            const result = await member_service_1.MemberService.updateVerificationStatus(req.params.id, status);
            res.json({ success: true, data: result });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.MemberController = MemberController;
