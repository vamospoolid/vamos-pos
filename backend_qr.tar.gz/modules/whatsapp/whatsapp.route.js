"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const whatsapp_controller_1 = require("./whatsapp.controller");
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
// Public (internal)
router.get('/status', whatsapp_controller_1.getStatus);
router.get('/qr', whatsapp_controller_1.getQr);
router.post('/reset', whatsapp_controller_1.reset);
// WA Template management — admin only
router.get('/templates', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), whatsapp_controller_1.getTemplates);
router.put('/templates/:id', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), whatsapp_controller_1.updateTemplate);
router.post('/templates/:id/reset', auth_1.authenticate, (0, auth_1.authorizeRoles)('ADMIN', 'OWNER'), whatsapp_controller_1.resetTemplate);
exports.default = router;
