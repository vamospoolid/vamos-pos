"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.waService = void 0;
const whatsapp_web_js_1 = require("whatsapp-web.js");
const qrcode_terminal_1 = __importDefault(require("qrcode-terminal"));
const logger_1 = require("../../utils/logger");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
class WhatsAppService {
    client;
    isReady = false;
    latestQr = '';
    isInitializing = false;
    reconnectAttempts = 0;
    maxReconnectAttempts = 10;
    reconnectTimer = null;
    constructor() {
        this.initializeClient();
    }
    initializeClient() {
        if (this.client) {
            try {
                this.client.destroy();
            }
            catch (e) { }
        }
        this.client = new whatsapp_web_js_1.Client({
            authStrategy: new whatsapp_web_js_1.LocalAuth(),
            webVersionCache: {
                type: 'none'
            },
            puppeteer: {
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-extensions',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--single-process',
                    '--disable-gpu'
                ]
            }
        });
        this.setupListeners();
    }
    setupListeners() {
        const emitStatus = async () => {
            try {
                const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
                const io = getIO();
                if (io) {
                    io.emit('whatsapp:status', {
                        isReady: this.isReady,
                        isInitializing: this.isInitializing,
                        hasQr: !!this.latestQr
                    });
                }
            }
            catch (e) { }
        };
        this.client.on('qr', async (qr) => {
            this.latestQr = qr;
            this.isInitializing = false;
            logger_1.logger.info('📱 [WHATSAPP] New QR Code generated. Silakan scan melalui Admin Settings.');
            try {
                const { getIO } = await Promise.resolve().then(() => __importStar(require('../../socket')));
                const io = getIO();
                if (io)
                    io.emit('whatsapp:qr', { qr });
            }
            catch (e) { }
            emitStatus();
            qrcode_terminal_1.default.generate(qr, { small: true });
        });
        this.client.on('ready', () => {
            this.isReady = true;
            this.isInitializing = false;
            this.latestQr = '';
            this.reconnectAttempts = 0;
            logger_1.logger.info('✅ [WHATSAPP] Client is READY! Koneksi aktif.');
            emitStatus();
        });
        this.client.on('authenticated', () => {
            logger_1.logger.info('✅ [WHATSAPP] Berhasil terautentikasi.');
            emitStatus();
        });
        this.client.on('auth_failure', msg => {
            logger_1.logger.error(`❌ [WHATSAPP] Autentikasi gagal: ${msg}`);
            this.isInitializing = false;
            this.isReady = false;
            emitStatus();
        });
        this.client.on('disconnected', (reason) => {
            logger_1.logger.error(`❌ [WHATSAPP] Terputus: ${reason}`);
            this.isReady = false;
            this.latestQr = '';
            emitStatus();
            this.handleReconnect();
        });
    }
    handleReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            logger_1.logger.error('🚨 [WHATSAPP] Maksimal percobaan koneksi ulang tercapai. Mohon reset session manual.');
            return;
        }
        const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000); // Exponential backoff max 30s
        this.reconnectAttempts++;
        logger_1.logger.warn(`♻️ [WHATSAPP] Mencoba koneksi ulang ke-${this.reconnectAttempts} dalam ${delay / 1000} detik...`);
        if (this.reconnectTimer)
            clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
            this.initialize();
        }, delay);
    }
    async resetSession() {
        logger_1.logger.warn('♻️ [WHATSAPP] Melakukan reset session manual...');
        try {
            if (this.reconnectTimer)
                clearTimeout(this.reconnectTimer);
            await this.client.destroy();
        }
        catch (e) { }
        this.isReady = false;
        this.reconnectAttempts = 0;
        this.latestQr = '';
        const authPath = path_1.default.join(process.cwd(), '.wwebjs_auth');
        if (fs_1.default.existsSync(authPath)) {
            try {
                fs_1.default.rmSync(authPath, { recursive: true, force: true });
                logger_1.logger.info('🗑️ [WHATSAPP] Sesi lama dihapus (.wwebjs_auth)');
            }
            catch (e) {
                logger_1.logger.error('❌ [WHATSAPP] Gagal menghapus folder sesi:', e);
            }
        }
        this.initializeClient();
        return this.initialize();
    }
    async initialize() {
        if (this.isInitializing)
            return;
        this.isInitializing = true;
        logger_1.logger.info('⏳ [WHATSAPP] Menginisialisasi engine...');
        try {
            await this.client.initialize();
            this.isInitializing = false;
        }
        catch (err) {
            this.isInitializing = false;
            logger_1.logger.error(`❌ [WHATSAPP] Inisialisasi gagal: ${err.message}`);
            this.handleReconnect();
        }
    }
    async sendMessage(phoneNumber, message, imageUrl) {
        if (!this.isReady) {
            logger_1.logger.warn(`⚠️ [WHATSAPP] Gagal kirim ke ${phoneNumber}: Client belum Ready.`);
            return false;
        }
        try {
            const { MessageMedia } = await Promise.resolve().then(() => __importStar(require('whatsapp-web.js')));
            let formattedNumber = phoneNumber.replace(/\D/g, '');
            if (formattedNumber.startsWith('0')) {
                formattedNumber = '62' + formattedNumber.slice(1);
            }
            else if (formattedNumber.startsWith('8')) {
                formattedNumber = '62' + formattedNumber;
            }
            if (!formattedNumber.endsWith('@c.us')) {
                formattedNumber += '@c.us';
            }
            if (imageUrl) {
                try {
                    const media = await MessageMedia.fromUrl(imageUrl);
                    await this.client.sendMessage(formattedNumber, media, { caption: message });
                    logger_1.logger.info(`✅ [WHATSAPP] Pesan + Gambar terkirim ke ${phoneNumber}`);
                }
                catch (mediaError) {
                    logger_1.logger.error(`❌ [WHATSAPP] Gambar gagal dimuat (${imageUrl}), kirim teks saja.`);
                    await this.client.sendMessage(formattedNumber, message);
                    logger_1.logger.info(`✅ [WHATSAPP] Pesan teks terkirim ke ${phoneNumber}`);
                }
            }
            else {
                await this.client.sendMessage(formattedNumber, message);
                logger_1.logger.info(`✅ [WHATSAPP] Pesan terkirim ke ${phoneNumber}`);
            }
            return true;
        }
        catch (error) {
            logger_1.logger.error(`❌ [WHATSAPP] Gagal kirim pesan ke ${phoneNumber}: ${error.message}`);
            return false;
        }
    }
    getStatus() {
        return {
            isReady: this.isReady,
            isInitializing: this.isInitializing,
            hasQr: !!this.latestQr
        };
    }
}
exports.waService = new WhatsAppService();
