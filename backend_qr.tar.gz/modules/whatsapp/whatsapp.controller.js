"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetTemplate = exports.updateTemplate = exports.getTemplates = exports.reset = exports.getQr = exports.getStatus = void 0;
const wa_service_1 = require("./wa.service");
const wa_template_service_1 = require("./wa.template.service");
const getStatus = (req, res) => {
    try {
        res.status(200).json({
            success: true,
            data: {
                isReady: wa_service_1.waService.isReady,
                hasQr: !!wa_service_1.waService.latestQr,
                isInitializing: wa_service_1.waService.isInitializing
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.getStatus = getStatus;
const getQr = (req, res) => {
    try {
        if (wa_service_1.waService.isReady) {
            return res.status(200).json({ success: true, data: { qr: null, message: 'WhatsApp already connected' } });
        }
        res.status(200).json({ success: true, data: { qr: wa_service_1.waService.latestQr || null } });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.getQr = getQr;
const reset = async (req, res) => {
    try {
        await wa_service_1.waService.resetSession();
        res.status(200).json({ success: true, message: 'WhatsApp session reset initiated' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.reset = reset;
// ── Template endpoints ─────────────────────────────────────────────────────
const getTemplates = async (req, res) => {
    try {
        const templates = await wa_template_service_1.WaTemplateService.getAll();
        res.json({ success: true, data: templates });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.getTemplates = getTemplates;
const updateTemplate = async (req, res) => {
    try {
        const { id } = req.params;
        const { body, imageUrl, isActive } = req.body;
        const updated = await wa_template_service_1.WaTemplateService.update(id, body, imageUrl, isActive ?? true);
        res.json({ success: true, data: updated });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.updateTemplate = updateTemplate;
const resetTemplate = async (req, res) => {
    try {
        const { id } = req.params;
        const reset = await wa_template_service_1.WaTemplateService.resetToDefault(id);
        res.json({ success: true, data: reset });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
exports.resetTemplate = resetTemplate;
