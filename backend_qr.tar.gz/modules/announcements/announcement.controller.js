"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnnouncementController = void 0;
const db_1 = require("../../database/db");
class AnnouncementController {
    static async getActive(req, res, next) {
        try {
            const announcements = await db_1.prisma.announcement.findMany({
                where: { isActive: true },
                orderBy: { priority: 'desc' },
                take: 5
            });
            res.json({ success: true, data: announcements });
        }
        catch (error) {
            next(error);
        }
    }
    static async getAll(req, res, next) {
        try {
            const announcements = await db_1.prisma.announcement.findMany({
                orderBy: { createdAt: 'desc' }
            });
            res.json({ success: true, data: announcements });
        }
        catch (error) {
            next(error);
        }
    }
    static async create(req, res, next) {
        try {
            const { title, content, imageUrl, targetUrl, priority } = req.body;
            const announcement = await db_1.prisma.announcement.create({
                data: { title, content, imageUrl, targetUrl, priority: priority || 0 }
            });
            res.json({ success: true, data: announcement });
        }
        catch (error) {
            next(error);
        }
    }
    static async update(req, res, next) {
        try {
            const { id } = req.params;
            const announcement = await db_1.prisma.announcement.update({
                where: { id },
                data: req.body
            });
            res.json({ success: true, data: announcement });
        }
        catch (error) {
            next(error);
        }
    }
    static async delete(req, res, next) {
        try {
            const { id } = req.params;
            await db_1.prisma.announcement.delete({ where: { id } });
            res.json({ success: true, message: 'Announcement deleted' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.AnnouncementController = AnnouncementController;
