"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const player_controller_1 = require("./player.controller");
const playerAuth_1 = require("../../middleware/playerAuth");
const auth_1 = require("../../middleware/auth");
const uploadMiddleware_1 = require("../../middleware/uploadMiddleware");
const router = (0, express_1.Router)();
// Publicly accessible for the player app
router.post('/register', player_controller_1.PlayerController.register);
router.get('/avatar-view/:filename', player_controller_1.PlayerController.viewAvatarByFilename);
router.post('/login', player_controller_1.PlayerController.login);
router.post('/:id/notify-verify', player_controller_1.PlayerController.notifyVerification);
router.get('/tournaments', player_controller_1.PlayerController.getTournaments);
router.get('/leaderboard', player_controller_1.PlayerController.getLeaderboard);
router.get('/kings', player_controller_1.PlayerController.getKings);
router.get('/hall-of-fame', player_controller_1.PlayerController.getHallOfFame);
router.get('/venues', player_controller_1.PlayerController.getVenues);
// Arena Management for Kasir/Admin
router.get('/challenges/pending-verification', auth_1.authenticate, player_controller_1.PlayerController.getPendingVerifications);
router.post('/challenges/admin-create', auth_1.authenticate, player_controller_1.PlayerController.adminCreateChallenge);
router.put('/challenge/:id/complete', auth_1.authenticate, player_controller_1.PlayerController.completeChallenge);
router.delete('/challenge/:id', auth_1.authenticate, player_controller_1.PlayerController.deleteChallenge);
// --- PROTECTED ROUTES FOR PLAYERS (1-Device-1-ID) ---
router.use(playerAuth_1.playerAuth);
// Profile and History (Specifics first)
router.put('/profile', player_controller_1.PlayerController.updateProfile);
router.post('/:id/avatar', uploadMiddleware_1.uploadAvatar.single('photo'), player_controller_1.PlayerController.uploadAvatar);
// Match Challenges
router.get('/lobby-challenges', player_controller_1.PlayerController.getLobbyChallenges);
router.post('/challenge', player_controller_1.PlayerController.createChallenge);
router.put('/challenge/:id/accept-lobby', player_controller_1.PlayerController.acceptLobbyChallenge);
router.put('/challenge/:id/respond', player_controller_1.PlayerController.respondToChallenge);
router.post('/challenge/:id/respond', player_controller_1.PlayerController.respondToChallenge);
router.put('/challenge/:id/link-session', player_controller_1.PlayerController.linkSession);
router.put('/challenge/:id/claim-victory', player_controller_1.PlayerController.claimVictory);
router.post('/training/submit', player_controller_1.PlayerController.submitTraining);
// Rewards
router.get('/rewards', player_controller_1.PlayerController.getRewards);
// router.post('/loyalty/mystery-box', PlayerController.openMysteryBox);
router.post('/rewards/redeem', player_controller_1.PlayerController.redeemReward);
router.get('/rewards/redemptions/member/:memberId', player_controller_1.PlayerController.getRedemptions);
// Table & Booking
router.get('/tables', player_controller_1.PlayerController.getTables);
router.get('/availability', player_controller_1.PlayerController.getAvailability);
router.post('/booking', player_controller_1.PlayerController.createBooking);
// Direct FNB Order
router.get('/menu', player_controller_1.PlayerController.getMenu);
router.get('/store-products', player_controller_1.PlayerController.getStoreProducts);
router.post('/order', player_controller_1.PlayerController.placeOrder);
// Parameterized routes (Catch-alls for /:id, must be at the bottom)
router.get('/:id', player_controller_1.PlayerController.getProfile);
router.get('/:id/dashboard', player_controller_1.PlayerController.getDashboard);
router.get('/:id/history', player_controller_1.PlayerController.getMatchHistory);
router.get('/:id/h2h', player_controller_1.PlayerController.getH2H);
router.get('/:id/h2h-detail', player_controller_1.PlayerController.getSpecificH2H);
router.get('/:id/quests', player_controller_1.PlayerController.getQuests);
router.post('/:id/quests/:questId/claim', player_controller_1.PlayerController.claimQuest);
router.post('/tournaments/:id/register', player_controller_1.PlayerController.registerTournament);
router.get('/:id/transactions', player_controller_1.PlayerController.getTransactions);
router.get('/:id/unpaid-bills', player_controller_1.PlayerController.getUnpaidBills);
router.get('/:id/challenges', player_controller_1.PlayerController.getChallenges);
router.get('/:id/rank-history', player_controller_1.PlayerController.getRankHistory);
exports.default = router;
