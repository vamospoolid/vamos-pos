"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCloudSocket = exports.getIO = exports.getLastCloudError = exports.initSocket = exports.getLatestBridgeStatus = void 0;
const socket_io_1 = require("socket.io");
const socket_io_client_1 = require("socket.io-client");
const logger_1 = require("./utils/logger");
const db_1 = require("./database/db");
const eventBus_1 = require("./utils/eventBus");
let io;
let latestBridgeStatus = null;
const getLatestBridgeStatus = () => latestBridgeStatus;
exports.getLatestBridgeStatus = getLatestBridgeStatus;
let lastCloudError = null;
/**
 * Inisialisasi Socket Server lokal (untuk UI kasir dan printer)
 */
const initSocket = (server) => {
    io = new socket_io_1.Server(server, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
        }
    });
    io.on('connection', (socket) => {
        logger_1.logger.info(`[Socket.IO Local] Terhubung: ${socket.id}`);
        // Jika ada status bridge yang tersimpan, kirim ke client yang baru konek (UI)
        if (latestBridgeStatus) {
            socket.emit('bridge:hardware:status', { ...latestBridgeStatus, isBridge: true, isCached: true });
        }
        else {
            // Jika belum ada di cache, coba ambil langsung dari RelayService
            Promise.resolve().then(() => __importStar(require('./modules/relay/relay.service'))).then(({ RelayService }) => {
                const status = RelayService.getStatus();
                socket.emit('bridge:hardware:status', { ...status, isBridge: true, isCached: false });
            });
        }
        // Kirim status WhatsApp saat ini
        Promise.resolve().then(() => __importStar(require('./modules/whatsapp/wa.service'))).then(({ waService }) => {
            socket.emit('whatsapp:status', waService.getStatus());
        });
        socket.on('disconnect', () => {
            logger_1.logger.info(`[Socket.IO Local] Terputus: ${socket.id}`);
        });
        // VPS Broadcaster: Menerima status dari Bridge dan meneruskan ke UI
        socket.on('bridge:status:update', async (data) => {
            // Simpan ke memori VPS agar client baru bisa dapat status lama
            const previousStatus = latestBridgeStatus;
            latestBridgeStatus = data;
            // Jika port berubah, update Database VPS agar tetap konsisten (menghilangkan /dev/ttyS0)
            if (data.port && data.port !== previousStatus?.port) {
                try {
                    await db_1.prisma.venue.updateMany({
                        data: { relayComPort: data.port }
                    });
                    logger_1.logger.info(`🔄 [VPS_SYNC] Venue port updated to: ${data.port}`);
                }
                catch (e) {
                    logger_1.logger.error(`❌ [VPS_SYNC] Failed to update Venue port: ${e}`);
                }
            }
            // Sync License HWID to memory if available
            if (data.hardwareId) {
                logger_1.logger.debug(`🔑 [VPS_SYNC] Bridge Hardware ID reported: ${data.hardwareId}`);
                // PUSH License Status back to Bridge for Offline Persistence
                try {
                    const { LicenseService } = await Promise.resolve().then(() => __importStar(require('./modules/license/license.service')));
                    const ls = new LicenseService();
                    const status = await ls.getStatus(data.hardwareId);
                    socket.emit('license:sync', status);
                }
                catch (e) { }
            }
            // Teruskan ke semua UI
            io.emit('bridge:hardware:status', { ...data, isBridge: true });
        });
    });
    // Jalankan Jembatan Cloud jika berjalan di mode Lokal (ada Cloud URL di ENV)
    initCloudBridge();
    return io;
};
exports.initSocket = initSocket;
let cloudSocketInstance = null;
/**
 * JEMBATAN CLOUD (Socket Bridge) + LOCAL SYNC
 */
const initCloudBridge = () => {
    // Singleton check: Jangan buat koneksi baru jika sudah ada
    if (cloudSocketInstance)
        return;
    const cloudUrl = process.env.CLOUD_BASE_URL || 'https://pos.vamospool.id';
    // Jangan connect ke diri sendiri jika sedang berjalan di VPS
    if (process.env.NODE_ENV === 'production' && !process.env.IS_LOCAL_ELECTRON) {
        return;
    }
    logger_1.logger.info(`🌐 Membangun Jembatan Realtime ke Cloud: ${cloudUrl}`);
    cloudSocketInstance = (0, socket_io_client_1.io)(cloudUrl, {
        reconnectionAttempts: Infinity,
        reconnectionDelay: 5000,
        reconnectionDelayMax: 30000,
        timeout: 20000,
        transports: ['websocket']
    });
    const cloudSocket = cloudSocketInstance;
    cloudSocket.on('connect', () => {
        logger_1.logger.info('✅ Jembatan Cloud TERHUBUNG! Booking & Tantangan kini Realtime.');
        // Laporkan status hardware awal saat terhubung
        Promise.resolve().then(() => __importStar(require('./modules/relay/relay.service'))).then(({ RelayService }) => {
            const status = RelayService.getStatus();
            cloudSocket.emit('hardware:status', { isConnected: status.isConnected });
            cloudSocket.emit('bridge:status:update', status);
        });
        // Setup Heartbeat: Kirim status lengkap ke Cloud
        // Gunakan interval yang lebih efisien (30 detik) agar tidak membebani performa
        const heartbeat = setInterval(async () => {
            try {
                if (!cloudSocket.connected)
                    return;
                const { RelayService } = await Promise.resolve().then(() => __importStar(require('./modules/relay/relay.service')));
                const status = RelayService.getStatus();
                cloudSocket.emit('bridge:status:update', status);
            }
            catch (e) {
                // Ignore silent
            }
        }, 30000);
        cloudSocket.once('disconnect', () => clearInterval(heartbeat));
    });
    // Dengarkan perubahan status hardware dari RelayService (via Event Bus)
    eventBus_1.eventBus.on('hardware:status', (isConnected) => {
        const status = { isConnected, timestamp: new Date() };
        latestBridgeStatus = status;
        // 1. Kirim ke Lokal UI (KASIR)
        if (io) {
            io.emit('bridge:hardware:status', { ...status, isBridge: true });
        }
        // 2. Kirim ke Cloud Socket (VPS)
        if (cloudSocketInstance && cloudSocketInstance.connected) {
            logger_1.logger.info(`📡 [BRIDGE] Meneruskan Status Hardware ke Cloud: ${isConnected ? 'ONLINE' : 'OFFLINE'}`);
            cloudSocketInstance.emit('hardware:status', { isConnected });
        }
    });
    // Memory untuk debounce (menyimpan waktu terakhir event diterima)
    const eventDebounce = new Map();
    const isSpam = (key, limit = 1000) => {
        const now = Date.now();
        if (eventDebounce.has(key) && (now - eventDebounce.get(key) < limit))
            return true;
        eventDebounce.set(key, now);
        return false;
    };
    // ── SYNC: Booking baru dari Player App ────────────────────────────────
    cloudSocket.on('booking:new', async (data) => {
        if (isSpam(`booking:new-${data?.id}`))
            return;
        logger_1.logger.info(`🔔 [SYNC] booking:new diterima dari VPS → menyimpan ke Local DB...`);
        try {
            if (!data || !data.id)
                return;
            if (data.memberId)
                await upsertMember(data);
            await db_1.prisma.waitlist.upsert({
                where: { id: data.id },
                update: {
                    status: data.status || 'WAITING',
                    reservedTime: data.reservedTime ? new Date(data.reservedTime) : null,
                    updatedAt: new Date(),
                    syncStatus: 'SYNCED',
                },
                create: {
                    id: data.id,
                    customerName: data.customerName || data.memberName || 'Guest',
                    phone: data.phone || data.memberPhone || null,
                    memberId: data.memberId || null,
                    tableId: data.tableId || null,
                    tableType: data.tableType || 'REGULAR',
                    packageId: data.packageId || null,
                    reservedTime: data.reservedTime ? new Date(data.reservedTime) : new Date(),
                    durationMinutes: data.durationMinutes || 60,
                    partySize: data.partySize || 1,
                    notes: data.notes || 'Booked via Player App [SYNCED]',
                    price: data.price || 0,
                    pointsCost: data.pointsCost || 0,
                    status: data.status || 'WAITING',
                    createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
                    updatedAt: new Date(),
                    syncStatus: 'SYNCED',
                }
            });
            logger_1.logger.info(`✅ [SYNC] Booking ${data.id} tersimpan di Local DB.`);
        }
        catch (err) {
            logger_1.logger.error(`❌ [SYNC] Gagal simpan booking: ${err.message}`);
        }
        if (io) {
            io.emit('booking:new', data);
            io.emit('waitlist:updated');
        }
    });
    // ── SYNC: Member baru registrasi dari Player App ──────────────────────
    cloudSocket.on('member:new', async (data) => {
        if (isSpam(`member:new-${data?.id}`))
            return;
        logger_1.logger.info(`🔔 [SYNC] member:new → menyimpan ke Local DB...`);
        try {
            if (data?.id)
                await upsertMember(data);
        }
        catch (err) {
            logger_1.logger.error(`❌ [SYNC] Gagal sync member baru: ${err.message}`);
        }
        if (io)
            io.emit('member:new', data);
    });
    // ── SYNC: Update profil member ────────────────────────────────────────
    cloudSocket.on('member:updated', async (data) => {
        if (isSpam(`member:updated-${data?.id}`))
            return;
        logger_1.logger.info(`🔔 [SYNC] member:updated → update Local DB...`);
        try {
            if (data?.id) {
                await db_1.prisma.member.updateMany({
                    where: { id: data.id },
                    data: {
                        photo: data.photo ?? undefined,
                        loyaltyPoints: data.loyaltyPoints ?? undefined,
                        tier: data.tier ?? undefined,
                        totalWins: data.totalWins ?? undefined,
                        totalMatches: data.totalMatches ?? undefined,
                        experience: data.experience ?? undefined,
                        level: data.level ?? undefined,
                        skillRating: data.skillRating ?? undefined,
                        updatedAt: new Date(),
                        syncStatus: 'SYNCED',
                    }
                });
                logger_1.logger.info(`✅ [SYNC] Member ${data.id} diupdate di Local DB.`);
            }
        }
        catch (err) {
            logger_1.logger.error(`❌ [SYNC] Gagal update member: ${err.message}`);
        }
        if (io)
            io.emit('member:updated', data);
    });
    // ── MIRROR ONLY ───────────────────────────────────────────────────────
    const eventsToMirror = [
        'booking:updated',
        'challenge:new',
        'king:updated',
        'tournament:update',
        'system:message',
        'waitlist:updated',
    ];
    eventsToMirror.forEach(event => {
        cloudSocket.on(event, (data) => {
            // Anti-Spam Global: Jeda 5 detik untuk tipe event yang sama (Waitlist, Tournament, dll)
            if (isSpam(`mirror-${event}`, 5000))
                return;
            logger_1.logger.info(`🔔 Cloud Event [${event}] → Teruskan ke UI Lokal...`);
            if (io)
                io.emit(event, data);
        });
    });
    // ── BRIDGE: Tangkap perintah Relay dari Cloud ─────────────────────────
    cloudSocket.on('relay:command', async (data) => {
        // Anti-Spam Khusus Relay: 2 detik
        if (isSpam(`relay-${data.channel}-${data.status}`, 2000))
            return;
        logger_1.logger.info(`🔌 [BRIDGE] relay:command diterima dari VPS: Meja ${data.channel} -> ${data.status}`);
        try {
            const { RelayService } = await Promise.resolve().then(() => __importStar(require('./modules/relay/relay.service')));
            await RelayService.sendCommand(data.channel, data.status);
        }
        catch (err) {
            logger_1.logger.error(`❌ [BRIDGE] Gagal eksekusi relay hardware: ${err.message}`);
        }
    });
    cloudSocket.on('relay:blink', async (data) => {
        // Anti-Spam Blink: 2 detik
        if (isSpam(`relay-blink-${data.channel}`, 2000))
            return;
        logger_1.logger.info(`🔌 [BRIDGE] relay:blink diterima dari VPS: Meja ${data.channel}`);
        try {
            const { RelayService } = await Promise.resolve().then(() => __importStar(require('./modules/relay/relay.service')));
            await RelayService.blink(data.channel);
        }
        catch (err) {
            logger_1.logger.error(`❌ [BRIDGE] Gagal eksekusi blink hardware: ${err.message}`);
        }
    });
    cloudSocket.on('print:receipt', async (data) => {
        logger_1.logger.info(`🖨️ [BRIDGE] print:receipt diterima dari VPS! Meluncur ke RP58 Printer...`);
        try {
            const { PrintService } = await Promise.resolve().then(() => __importStar(require('./modules/print/print.service')));
            await PrintService.printReceipt(data);
        }
        catch (err) {
            logger_1.logger.error(`❌ [BRIDGE] Gagal eksekusi cetak struk: ${err.message}`);
        }
    });
    cloudSocket.on('disconnect', () => {
        logger_1.logger.warn('⚠️ Jembatan Cloud TERPUTUS. Menunggu koneksi kembali...');
    });
    cloudSocket.on('connect_error', (err) => {
        logger_1.logger.error(`❌ Gagal terhubung ke Jembatan Cloud: ${err.message}`);
        lastCloudError = err.message;
    });
};
/**
 * Helper: Ambil Error Cloud Terakhir
 */
const getLastCloudError = () => lastCloudError;
exports.getLastCloudError = getLastCloudError;
/**
 * Helper: Upsert member ke Local DB (skip jika phone conflict dengan member berbeda)
 */
async function upsertMember(data) {
    if (!data?.id)
        return;
    // Cek apakah sudah ada member dengan phone yang sama tapi ID berbeda
    if (data.phone) {
        const existing = await db_1.prisma.member.findFirst({
            where: { phone: data.phone, NOT: { id: data.id } }
        });
        if (existing) {
            // Phone sudah dipakai member lain — jangan timpa, hanya update yang relevan
            logger_1.logger.warn(`[SYNC] Phone ${data.phone} sudah ada (member lain). Skip upsert.`);
            return;
        }
    }
    await db_1.prisma.member.upsert({
        where: { id: data.id },
        update: {
            name: data.name || data.memberName,
            photo: data.photo || data.memberPhoto || undefined,
            tier: data.tier || data.memberTier || undefined,
            loyaltyPoints: data.loyaltyPoints ?? undefined,
            updatedAt: new Date(),
            syncStatus: 'SYNCED',
        },
        create: {
            id: data.id,
            name: data.name || data.memberName || 'Player',
            phone: data.phone || data.memberPhone || `player_${data.id.slice(0, 8)}`,
            email: data.email || null,
            tier: data.tier || data.memberTier || 'BRONZE',
            loyaltyPoints: data.loyaltyPoints || 0,
            photo: data.photo || data.memberPhoto || null,
            handicap: data.handicap || '4',
            handicapLabel: data.handicapLabel || 'Entry Fragger',
            skillRating: data.skillRating || 200,
            createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
            updatedAt: new Date(),
            syncStatus: 'SYNCED',
        }
    });
    logger_1.logger.info(`✅ [SYNC] Member ${data.id} di-upsert ke Local DB.`);
}
const getIO = () => {
    if (!io) {
        console.warn('Socket.io is not initialized yet!');
    }
    return io;
};
exports.getIO = getIO;
const getCloudSocket = () => cloudSocketInstance;
exports.getCloudSocket = getCloudSocket;
