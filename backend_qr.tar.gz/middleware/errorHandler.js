"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = void 0;
const errors_1 = require("../utils/errors");
const logger_1 = require("../utils/logger");
const zod_1 = require("zod");
const errorHandler = (err, req, res, next) => {
    if (err instanceof zod_1.ZodError) {
        return res.status(400).json({ success: false, message: 'Validation Error', details: err.errors });
    }
    if (err instanceof errors_1.AppError) {
        return res.status(err.statusCode).json({ success: false, message: err.message });
    }
    const statusCode = err.status || err.statusCode || 500;
    const message = err.message || 'Internal Server Error';
    logger_1.logger.error(err);
    return res.status(statusCode).json({
        success: false,
        message: message,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
};
exports.errorHandler = errorHandler;
