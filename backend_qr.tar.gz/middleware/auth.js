"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizeRoles = exports.authenticate = exports.localOrAuthenticate = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const errors_1 = require("../utils/errors");
const db_1 = require("../database/db");
/**
 * On local Electron (cashier PC), some destructive operations like DB restore
 * must still work even when the JWT is expired / the VPS is offline.
 * This middleware allows the request through without a token when
 * IS_LOCAL_ELECTRON=true, otherwise falls back to normal authenticate.
 */
const localOrAuthenticate = async (req, res, next) => {
    if (process.env.IS_LOCAL_ELECTRON === 'true') {
        // Attach a synthetic admin identity so downstream authorizeRoles passes
        req.user = { id: 'local-electron', role: 'ADMIN' };
        return next();
    }
    return (0, exports.authenticate)(req, res, next);
};
exports.localOrAuthenticate = localOrAuthenticate;
const authenticate = async (req, res, next) => {
    try {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        if (!token) {
            next(new errors_1.AppError('Unauthorized', 401));
            return;
        }
        // --- SOLUSI BUG LOGOUT PLAYER APP ---
        // Player App mengirim token 'player_...' yang BUKAN jwt, sehingga jwt.verify() sebelumnya akan melempar error dan men-tendang user.
        if (token.startsWith('player_')) {
            const memberId = token.replace('player_', '');
            const member = await db_1.prisma.member.findUnique({ where: { id: memberId } });
            if (!member) {
                next(new errors_1.AppError('Unauthorized: Player token invalid', 401));
                return;
            }
            req.user = { id: member.id, role: 'MEMBER' };
            return next();
        }
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET || 'secret');
        const user = await db_1.prisma.user.findUnique({ where: { id: decoded.id } });
        if (!user) {
            next(new errors_1.AppError('Unauthorized: User token invalid or expired', 401));
            return;
        }
        req.user = decoded;
        next();
    }
    catch (err) {
        next(new errors_1.AppError('Unauthorized', 401));
    }
};
exports.authenticate = authenticate;
const authorizeRoles = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            throw new errors_1.AppError('Forbidden', 403);
        }
        const userRole = req.user.role;
        // HIERARCHY: ADMIN and OWNER can do anything each other can
        const allowedRoles = [...roles];
        if (allowedRoles.includes('OWNER') && !allowedRoles.includes('ADMIN')) {
            allowedRoles.push('ADMIN');
        }
        if (allowedRoles.includes('ADMIN') && !allowedRoles.includes('OWNER')) {
            allowedRoles.push('OWNER');
        }
        if (!allowedRoles.includes(userRole)) {
            throw new errors_1.AppError('Forbidden', 403);
        }
        next();
    };
};
exports.authorizeRoles = authorizeRoles;
