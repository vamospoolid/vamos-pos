"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// db.ts sudah menangani dotenv dan Prisma engine config saat pertama diimpor
require("./database/db"); // Pastikan db init berjalan sebelum routes
const path_1 = __importDefault(require("path"));
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const errorHandler_1 = require("./middleware/errorHandler");
const routes_1 = __importDefault(require("./routes"));
const logger_1 = require("./utils/logger");
const relay_service_1 = require("./modules/relay/relay.service");
const socket_1 = require("./socket");
const timezone_utils_1 = require("./utils/timezone.utils");
// Initialize timezone offset from DB
(0, timezone_utils_1.initializeTimezoneFromVenue)();
// ── DIAGNOSTIC MODE ──────────────────────────────────────────────────────
if (process.argv.includes('--diagnose')) {
    const { SerialPort } = require('serialport');
    console.log('\n======================================================');
    console.log('VAMOS POS - HARDWARE DIAGNOSTIC MODE');
    console.log('======================================================');
    async function runDiag() {
        try {
            const ports = await SerialPort.list();
            console.log(`\nTerdeteksi ${ports.length} port serial:\n`);
            for (const port of ports) {
                const isCH340 = port.vendorId?.toLowerCase() === '1a86' || port.manufacturer?.toLowerCase().includes('wch');
                console.log(`${isCH340 ? '[RELAY]' : '[PORT]'} ${port.path}`);
                console.log(`   - Manufacturer: ${port.manufacturer || 'Unknown'}`);
                console.log(`   - Vendor ID:    ${port.vendorId || 'N/A'}`);
                try {
                    const testPort = new SerialPort({ path: port.path, baudRate: 9600, autoOpen: false });
                    await new Promise((res) => {
                        testPort.open((err) => {
                            if (err)
                                console.log(`   - Status:       ❌ SIBUK (${err.message})`);
                            else {
                                console.log(`   - Status:       ✅ TERSEDIA`);
                                testPort.close(() => res());
                            }
                        });
                    });
                }
                catch (e) { }
                console.log('');
            }
            console.log('======================================================');
            console.log('Saran: Gunakan port [RELAY] di .env (RELAY_COM_PORT)');
            console.log('Atau set RELAY_COM_PORT=AUTO agar otomatis.');
            console.log('======================================================\n');
        }
        catch (err) {
            console.error('Diagnostic error:', err.message);
        }
        process.exit(0);
    }
    runDiag();
}
// ─────────────────────────────────────────────────────────────────────────
// --- PKG NATIVE MODULES WORKAROUND ---
// Memaksa pkg untuk membundel dan men-extract file .node yang dibutuhkan serialport
// Ini memperbaiki bug CRASH saat app portable (vamous-pos.exe) dijalankan.
if (process.pkg) {
    try {
        require('@serialport/bindings-cpp/prebuilds/win32-x64/@serialport+bindings-cpp.node');
        console.log('✅ SerialPort native binding loaded OK (SNAPSHOT)');
    }
    catch (e) {
        try {
            const path = require('path');
            const externalDir = path.dirname(process.execPath);
            const externalPath = path.join(externalDir, '@serialport+bindings-cpp.node');
            require(externalPath);
            console.log('✅ SerialPort native binding loaded OK (EXTERNAL):', externalPath);
        }
        catch (e2) {
            console.error('❌ ALL FAILED: SerialPort native binding missing!', e2.message);
        }
    }
}
const isLocalBridge = !!process.env.IS_LOCAL_ELECTRON;
if (isLocalBridge) {
    // Non-blocking initialization to ensure UI is never blocked by hardware
    Promise.resolve().then(() => __importStar(require('./modules/system/bridge.service'))).then(({ BridgeService }) => {
        try {
            BridgeService.init();
        }
        catch (e) {
            logger_1.logger.error('⚠️ BRIDGE INIT ERROR (Non-blocking):', e.message);
        }
    });
}
logger_1.logger.info('🚀 SYSTEM STARTING: Access First mode active. Hardware scanning in background.');
const app = (0, express_1.default)();
app.use((0, helmet_1.default)({
    crossOriginOpenerPolicy: false,
    crossOriginResourcePolicy: false, // MATIKAN pemblokiran lintas domain secara total
}));
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-device-id');
    next();
});
// Improved CORS for Local Bridge & Cloud UI Synergy
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        const allowedOrigins = [
            'http://localhost:3000',
            'http://localhost:5173',
            'https://pos.vamospool.id',
            'https://app.vamospool.id',
            'http://pos.local'
        ];
        if (!origin || allowedOrigins.includes(origin) || allowedOrigins.some(ao => origin.includes(ao.replace('https://', '').replace('http://', '')))) {
            callback(null, true);
        }
        else {
            callback(null, true); // Permissive for local hardware synergy
        }
    },
    credentials: true,
    methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'x-device-id']
}));
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ limit: '10mb', extended: true }));
// Format 'combined' terlalu verbose di production — pakai 'tiny' agar overhead minimal
const morganFormat = process.env.NODE_ENV === 'production' ? 'tiny' : 'combined';
app.use((0, morgan_1.default)(morganFormat, { stream: { write: message => logger_1.logger.info(message.trim()) } }));
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: 10000,
    skip: (req) => req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1'
});
app.use(limiter);
// Dynamic imports for heavy services
// import { waService } from './modules/whatsapp/wa.service';
// import { WaTemplateService } from './modules/whatsapp/wa.template.service';
// API Routes
app.use('/api', routes_1.default);
// Diagnostic Route for Hardware Bridge
app.get('/api/system/bridge-status', (req, res) => {
    const cloudSocket = (0, socket_1.getCloudSocket)();
    res.json({
        success: true,
        timestamp: new Date().toISOString(),
        relay: relay_service_1.RelayService.getStatus(),
        vps: {
            url: process.env.CLOUD_BASE_URL || 'https://pos.vamospool.id',
            isConnected: cloudSocket?.connected || false,
            socketId: cloudSocket?.id || null,
            lastError: (0, socket_1.getLastCloudError)()
        },
        env: {
            IS_LOCAL_ELECTRON: process.env.IS_LOCAL_ELECTRON,
            NODE_ENV: process.env.NODE_ENV
        }
    });
});
// Serve Frontend Static Files (Unified Build)
const publicPath = path_1.default.join(process.cwd(), 'public');
app.use(express_1.default.static(publicPath));
app.use('/uploads', express_1.default.static(path_1.default.join(publicPath, 'uploads')));
// Handle SPA routing (redirect all non-api to index.html)
app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api'))
        return next();
    res.sendFile(path_1.default.join(publicPath, 'index.html'));
});
app.use(errorHandler_1.errorHandler);
// Initialize WA Service (VPS ONLY)
if (!isLocalBridge) {
    try {
        // Gunakan eval-require agar pkg tidak melacak dependensi ini di lokal
        const waMod = eval('require("./modules/whatsapp/wa.service")');
        const templateMod = eval('require("./modules/whatsapp/wa.template.service")');
        waMod.waService.initialize();
        templateMod.WaTemplateService.ensureDefaults().catch((e) => logger_1.logger.error('WaTemplate seed error:', e));
    }
    catch (e) {
        logger_1.logger.error('❌ Terjadi kesalahan saat memuat layanan WhatsApp (VPS ONLY):', e.message);
    }
}
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    logger_1.logger.info(`Server running on port ${PORT} [HEARTBEAT-${Date.now()}]`);
});
const socket_2 = require("./socket");
(0, socket_2.initSocket)(server);
// Tuning untuk performa lebih baik
server.keepAliveTimeout = 5000;
server.headersTimeout = 6000;
// ── AUTO FIX STUCK TABLES ────────────────────────────────────────────────
// PENTING: Jangan jalankan di Smart Bridge (IS_LOCAL_ELECTRON) karena DB lokal
// tidak menyimpan data sesi — semua sesi ada di VPS. Jika dijalankan, ia akan
// melihat semua meja PLAYING sebagai "stuck" (tidak ada sesi lokal) dan mereset
// seluruh meja ke AVAILABLE, membatalkan semua transaksi yang sedang berjalan!
const runFixStuckTables = async () => {
    // Guard: HANYA jalankan di VPS, TIDAK di mesin kasir lokal
    if (isLocalBridge) {
        logger_1.logger.info('⏭️ fixStuckTables: Dilewati (Smart Bridge mode — sesi ada di VPS).');
        return;
    }
    try {
        const { TableService } = await Promise.resolve().then(() => __importStar(require('./modules/tables/table.service')));
        const result = await TableService.fixStuckTables();
        if (result.fixed > 0) {
            logger_1.logger.warn(`🔧 Auto-fix: ${result.fixed} meja stuck direset → [${result.tableNames.join(', ')}] | ` +
                `Relay OFF: ch[${result.relayOff.join(', ')}]` +
                (result.relayErrors.length > 0 ? ` | ⚠️ Relay errors: ${result.relayErrors.length}` : ''));
        }
    }
    catch (err) {
        logger_1.logger.error(`❌ runFixStuckTables gagal: ${err.message}`);
    }
};
// Jalankan sekali saat start (delay 3 detik agar DB & relay siap)
// Di Smart Bridge mode, fungsi akan langsung return tanpa efek
setTimeout(runFixStuckTables, 3000);
// ── BACKGROUND SERVICES (DI VPS SAJA) ────────────────────────────────────
if (!isLocalBridge || process.env.NODE_ENV === 'development') {
    logger_1.logger.info('⚙️ Starting Background Services (Local Dev/VPS)...');
    // 1. Auto-fix stuck tables (setiap 5 menit)
    setInterval(runFixStuckTables, 5 * 60 * 1000);
    // 2. Auto end expired sessions (setiap 1 menit)
    const runAutoExpireSessions = async () => {
        try {
            const { SessionService } = await Promise.resolve().then(() => __importStar(require('./modules/sessions/session.service')));
            await SessionService.checkExpiredSessions();
        }
        catch (err) {
            logger_1.logger.error(`❌ runAutoExpireSessions gagal: ${err.message}`);
        }
    };
    setTimeout(runAutoExpireSessions, 5000);
    setInterval(runAutoExpireSessions, 15 * 1000);
    // 3. Auto expire waitlist (setiap 10 menit)
    const runWaitlistCheck = async () => {
        try {
            const { WaitlistService } = await Promise.resolve().then(() => __importStar(require('./modules/waitlist/waitlist.service')));
            await WaitlistService.checkExpiredWaitlist();
        }
        catch (err) {
            logger_1.logger.error(`❌ runWaitlistCheck gagal: ${err.message}`);
        }
    };
    setTimeout(runWaitlistCheck, 15000);
    setInterval(runWaitlistCheck, 10 * 60 * 1000);
    // 4. Audit Log Cleanup (setiap 24 jam)
    const runAuditCleanup = async () => {
        try {
            const { AuditService } = await Promise.resolve().then(() => __importStar(require('./modules/audit/audit.service')));
            await AuditService.cleanupOldLogs(90);
        }
        catch (err) {
            logger_1.logger.error(`❌ AuditLog cleanup gagal: ${err.message}`);
        }
    };
    setTimeout(runAuditCleanup, 10000);
    setInterval(runAuditCleanup, 24 * 60 * 60 * 1000);
    // 5. Monthly Database Backup (setiap jam 2 pagi tgl 1)
    const runMonthlyBackup = async () => {
        try {
            const now = new Date();
            if (now.getDate() !== 1 || now.getHours() !== 2)
                return;
            const { BackupService } = await Promise.resolve().then(() => __importStar(require('./utils/backup.service')));
            const existing = BackupService.listBackups();
            const todayStr = now.toISOString().slice(0, 10);
            const alreadyDone = existing.some(b => b.name.includes(todayStr));
            if (alreadyDone)
                return;
            const result = await BackupService.runBackup();
            if (result.success)
                logger_1.logger.info(`✅ Monthly backup selesai: ${result.file}`);
        }
        catch (err) {
            logger_1.logger.error(`❌ Monthly backup error: ${err.message}`);
        }
    };
    setInterval(runMonthlyBackup, 60 * 60 * 1000);
    // 6. Local-First Sync Worker (ambil data dari POS lokal)
    Promise.resolve().then(() => __importStar(require('./modules/system/sync.service'))).then(({ SyncService }) => {
        SyncService.startBackgroundSync();
    });
}
else {
    logger_1.logger.info('⚡ BRIDGE MODE: Socket listener enabled for cloud commands.');
    // Start Sync Worker even in bridge mode to push local transactions to VPS
    Promise.resolve().then(() => __importStar(require('./modules/system/sync.service'))).then(({ SyncService }) => {
        SyncService.startBackgroundSync();
    });
}
// ─────────────────────────────────────────────────────────────────────────
const shutdown = (signal) => {
    logger_1.logger.info(`${signal} received: closing HTTP server`);
    server.close(() => {
        logger_1.logger.info('HTTP server closed');
        process.exit(0);
    });
    // Force exit jika tidak close dalam 3 detik
    setTimeout(() => process.exit(0), 3000);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
