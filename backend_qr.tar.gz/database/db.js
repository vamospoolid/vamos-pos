"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.prisma = void 0;
const client_1 = require("@prisma/client");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const dotenv_1 = __importDefault(require("dotenv"));
// --- PKG / BUNDLE INITIALIZATION ---
// Detect if running as a pkg bundle to handle external files correctly
const isPkg = process.pkg;
const execDir = isPkg ? path_1.default.dirname(process.execPath) : process.cwd();
// When running as a bundled EXE (cashier machine), always enforce Smart Bridge mode.
// This disables SyncWorker, SessionService, etc. regardless of how the EXE is launched.
if (isPkg && !process.env.IS_LOCAL_ELECTRON) {
    process.env.IS_LOCAL_ELECTRON = 'true';
}
// Load .env from the physical directory where the EXE is located
const envPath = path_1.default.join(execDir, '.env');
if (fs_1.default.existsSync(envPath)) {
    dotenv_1.default.config({ path: envPath });
}
else {
    dotenv_1.default.config(); // Fallback to current working directory
}
// Set Prisma Engine path if it exists locally as a child of the EXE
if (isPkg) {
    const enginePath = path_1.default.join(execDir, 'query_engine-windows.dll.node');
    if (fs_1.default.existsSync(enginePath)) {
        process.env.PRISMA_QUERY_ENGINE_LIBRARY = enginePath;
    }
}
// --- END PKG INITIALIZATION ---
exports.prisma = new client_1.PrismaClient({
    datasources: {
        db: { url: process.env.DATABASE_URL },
    },
    log: process.env.NODE_ENV === 'development'
        ? ['warn', 'error']
        : ['error'],
});
