"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    const venue = await prisma.venue.findFirst();
    console.log('--- VENUE INFO ---');
    console.log(JSON.stringify(venue, null, 2));
    process.exit(0);
}
main();
